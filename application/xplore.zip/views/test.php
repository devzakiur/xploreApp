<div class="content">
    <div class="container">

        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="pull-left page-title">Welcome To Dashboard !</h4>
                <?php echo breadcrumbs(); ?>
            </div>
        </div>

        <!-- Start Widget -->
            <div class="row">
            </div>
        </div> <!-- container -->
    </div>
