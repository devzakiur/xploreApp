<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-12 05:49:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 05:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 10:49:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 10:49:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-12 10:49:23 --> Severity: Notice --> Undefined property: ContentController::$user D:\shipan7.2\htdocs\xplore\application\controllers\api\ContentController.php 66
ERROR - 2020-03-12 10:49:23 --> Severity: error --> Exception: Call to a member function insert() on null D:\shipan7.2\htdocs\xplore\application\controllers\api\ContentController.php 66
DEBUG - 2020-03-12 05:49:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 05:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 10:49:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 10:49:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-12 10:49:34 --> Query error: Unknown column 'question_id' in 'field list' - Invalid query: INSERT INTO `question_reports` (`question_id`, `type`, `details`) VALUES ('58', '1', 'Some Error')
DEBUG - 2020-03-12 05:50:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 05:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 10:50:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 10:50:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 10:50:28 --> Total execution time: 0.1399
DEBUG - 2020-03-12 05:50:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 05:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 10:50:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 10:50:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 10:50:55 --> Total execution time: 0.0926
DEBUG - 2020-03-12 06:00:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:00:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:00:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:00:06 --> Total execution time: 0.1305
DEBUG - 2020-03-12 06:00:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:00:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:00:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:00:13 --> Total execution time: 0.1455
DEBUG - 2020-03-12 06:01:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:01:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:01:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-12 11:01:38 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\system\database\DB_query_builder.php 2442
ERROR - 2020-03-12 11:01:38 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `question_bookmark`
WHERE 0 = Array
DEBUG - 2020-03-12 06:02:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:02:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:02:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:02:04 --> Total execution time: 0.0509
DEBUG - 2020-03-12 06:02:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:02:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:02:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:02:16 --> Total execution time: 0.1664
DEBUG - 2020-03-12 06:02:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:02:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:02:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:02:36 --> Total execution time: 0.0604
DEBUG - 2020-03-12 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:40:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:40:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:40:24 --> Total execution time: 0.2499
DEBUG - 2020-03-12 06:43:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:43:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:43:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:43:03 --> Total execution time: 0.0940
DEBUG - 2020-03-12 06:43:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:43:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:43:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:43:42 --> Total execution time: 0.0666
DEBUG - 2020-03-12 06:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:44:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:44:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:44:24 --> Total execution time: 0.0765
DEBUG - 2020-03-12 06:44:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:44:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:44:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:44:29 --> Total execution time: 0.0774
DEBUG - 2020-03-12 06:44:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:44:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:44:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:44:30 --> Total execution time: 0.0948
DEBUG - 2020-03-12 06:44:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:44:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:44:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:44:32 --> Total execution time: 0.1234
DEBUG - 2020-03-12 06:44:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:44:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:44:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:44:33 --> Total execution time: 0.0739
DEBUG - 2020-03-12 06:44:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:44:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:44:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:44:50 --> Total execution time: 0.1008
DEBUG - 2020-03-12 06:44:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:44:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:44:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:44:56 --> Total execution time: 0.0665
DEBUG - 2020-03-12 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:44:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:44:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:44:57 --> Total execution time: 0.0722
DEBUG - 2020-03-12 06:45:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:45:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:45:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:45:02 --> Total execution time: 0.0798
DEBUG - 2020-03-12 06:45:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:45:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:45:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:45:08 --> Total execution time: 0.0643
DEBUG - 2020-03-12 06:45:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:45:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:45:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:45:10 --> Total execution time: 0.2576
DEBUG - 2020-03-12 06:45:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:45:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:45:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:45:11 --> Total execution time: 0.0755
DEBUG - 2020-03-12 06:45:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:45:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:45:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:45:12 --> Total execution time: 0.0768
DEBUG - 2020-03-12 06:45:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:45:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:45:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:45:13 --> Total execution time: 0.0948
DEBUG - 2020-03-12 06:45:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:45:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:45:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:45:14 --> Total execution time: 0.0695
DEBUG - 2020-03-12 06:46:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:32 --> No URI present. Default controller set.
DEBUG - 2020-03-12 06:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-12 06:46:32 --> Total execution time: 0.0742
DEBUG - 2020-03-12 06:46:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-12 06:46:32 --> Total execution time: 0.0607
DEBUG - 2020-03-12 06:46:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:32 --> No URI present. Default controller set.
DEBUG - 2020-03-12 06:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-12 06:46:32 --> Total execution time: 0.0518
DEBUG - 2020-03-12 06:46:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-12 06:46:32 --> Total execution time: 0.0488
DEBUG - 2020-03-12 06:46:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-12 06:46:33 --> Total execution time: 0.0426
DEBUG - 2020-03-12 06:46:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:46:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-12 11:46:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-12 11:46:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-12 11:46:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-12 11:46:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-12 11:46:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-12 11:46:36 --> Total execution time: 0.1554
DEBUG - 2020-03-12 06:46:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-12 06:46:36 --> Total execution time: 0.0384
DEBUG - 2020-03-12 06:46:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:46:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-12 11:46:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-12 11:46:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-12 11:46:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-12 11:46:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-12 11:46:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-12 11:46:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-12 11:46:40 --> Total execution time: 0.1430
DEBUG - 2020-03-12 06:46:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-12 06:46:40 --> Total execution time: 0.0553
DEBUG - 2020-03-12 06:46:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:46:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-12 11:46:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-12 06:46:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 06:46:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 06:46:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-12 06:46:48 --> Total execution time: 0.0523
DEBUG - 2020-03-12 06:47:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:47:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:47:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:47:39 --> Total execution time: 0.1412
DEBUG - 2020-03-12 06:47:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:47:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:47:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:47:43 --> Total execution time: 0.0602
DEBUG - 2020-03-12 06:47:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:47:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:47:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:47:44 --> Total execution time: 0.0748
DEBUG - 2020-03-12 06:47:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:47:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:47:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:47:45 --> Total execution time: 0.0956
DEBUG - 2020-03-12 06:47:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:47:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:47:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:47:47 --> Total execution time: 0.1846
DEBUG - 2020-03-12 06:47:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 06:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 11:47:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 11:47:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 11:47:58 --> Total execution time: 0.0781
DEBUG - 2020-03-12 07:02:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 12:02:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:02:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 12:02:03 --> Total execution time: 0.1168
DEBUG - 2020-03-12 07:02:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 12:02:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:02:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 12:02:05 --> Total execution time: 0.0773
DEBUG - 2020-03-12 07:02:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 12:02:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:02:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 12:02:06 --> Total execution time: 0.0744
DEBUG - 2020-03-12 07:02:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 12:02:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:02:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 12:02:07 --> Total execution time: 0.0701
DEBUG - 2020-03-12 07:02:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 12:02:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:02:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 12:02:11 --> Total execution time: 0.0720
DEBUG - 2020-03-12 07:02:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 12:02:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:02:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 12:02:13 --> Total execution time: 0.1254
DEBUG - 2020-03-12 07:02:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 12:02:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:02:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 12:02:15 --> Total execution time: 0.0763
DEBUG - 2020-03-12 07:02:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 12:02:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:02:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-12 12:02:16 --> Total execution time: 0.0697
DEBUG - 2020-03-12 07:37:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:37:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-12 12:37:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-12 12:37:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-12 12:37:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-12 12:37:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-12 12:37:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-12 12:37:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-12 12:37:01 --> Total execution time: 0.2003
DEBUG - 2020-03-12 07:37:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 07:37:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-12 07:37:01 --> Total execution time: 0.0393
DEBUG - 2020-03-12 07:37:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 07:37:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:37:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-12 12:37:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-12 07:37:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:37:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-12 12:37:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-12 12:37:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-12 12:37:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-12 12:37:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-12 12:37:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-12 12:37:40 --> Total execution time: 0.0622
DEBUG - 2020-03-12 07:37:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 07:37:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-12 07:37:40 --> Total execution time: 0.0498
DEBUG - 2020-03-12 07:37:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:37:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-03-12 12:37:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-12 12:37:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-12 12:37:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-12 12:37:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-12 12:37:42 --> Total execution time: 0.0918
DEBUG - 2020-03-12 07:37:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 07:37:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-12 07:37:42 --> Total execution time: 0.0449
DEBUG - 2020-03-12 07:37:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-12 12:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-12 12:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-12 12:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-12 12:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-12 12:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-12 12:37:44 --> Total execution time: 0.0861
DEBUG - 2020-03-12 07:37:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 07:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-12 07:37:44 --> Total execution time: 0.0427
DEBUG - 2020-03-12 07:37:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 07:37:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-12 12:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-12 07:37:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:37:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-12 12:37:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/topic-relation.php
DEBUG - 2020-03-12 07:37:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-12 07:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-12 07:37:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-12 12:37:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-12 12:37:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/topic-relation.php
