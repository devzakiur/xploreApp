 <footer class="footer text-right">
    2018-<?php echo date("Y"); ?> © Wan It Ltd.
</footer>