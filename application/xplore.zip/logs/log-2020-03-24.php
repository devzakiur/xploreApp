<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-24 04:37:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 09:37:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:37:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 09:37:16 --> Total execution time: 0.1956
DEBUG - 2020-03-24 04:37:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:39 --> No URI present. Default controller set.
DEBUG - 2020-03-24 04:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:37:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-24 04:37:39 --> Total execution time: 0.1313
DEBUG - 2020-03-24 04:37:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:37:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 04:37:39 --> Total execution time: 0.0455
DEBUG - 2020-03-24 04:37:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:37:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 04:37:40 --> Total execution time: 0.0381
DEBUG - 2020-03-24 04:37:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:37:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-24 09:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-24 09:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 09:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 09:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 09:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 09:37:44 --> Total execution time: 0.1348
DEBUG - 2020-03-24 04:37:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:37:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 04:37:45 --> Total execution time: 0.0438
DEBUG - 2020-03-24 04:37:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:37:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 09:37:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-24 09:37:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 09:37:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 09:37:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 09:37:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 09:37:52 --> Total execution time: 0.0648
DEBUG - 2020-03-24 04:37:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:37:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 04:37:52 --> Total execution time: 0.0436
DEBUG - 2020-03-24 04:37:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:37:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 09:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 04:37:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:37:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:37:57 --> Total execution time: 0.0418
DEBUG - 2020-03-24 09:37:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 09:37:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 04:37:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:37:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:37:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:37:59 --> Total execution time: 0.0417
DEBUG - 2020-03-24 09:37:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 09:37:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 04:38:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:38:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:38:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 09:38:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 09:38:02 --> Total execution time: 0.1243
DEBUG - 2020-03-24 04:38:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:38:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:38:03 --> Total execution time: 0.0412
DEBUG - 2020-03-24 09:38:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 09:38:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 04:38:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:38:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:38:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 09:38:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 09:38:06 --> Total execution time: 0.1214
DEBUG - 2020-03-24 04:38:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:38:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:38:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 09:38:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 09:38:08 --> Total execution time: 0.1364
DEBUG - 2020-03-24 04:38:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:38:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:38:10 --> Total execution time: 0.0384
DEBUG - 2020-03-24 09:38:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 09:38:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 04:38:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:38:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:38:12 --> Total execution time: 0.0497
DEBUG - 2020-03-24 09:38:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 09:38:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 04:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:38:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 09:38:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 04:38:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 04:38:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 04:38:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 04:38:32 --> Total execution time: 0.0769
DEBUG - 2020-03-24 04:38:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 09:38:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:38:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 09:38:58 --> Total execution time: 0.0831
DEBUG - 2020-03-24 04:39:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 09:39:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:39:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 09:39:26 --> Total execution time: 0.3710
DEBUG - 2020-03-24 04:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 09:41:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:41:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 09:41:13 --> Total execution time: 0.0952
DEBUG - 2020-03-24 04:41:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 09:41:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:41:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 09:41:27 --> Total execution time: 0.1320
DEBUG - 2020-03-24 04:41:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 09:41:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:41:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 09:41:52 --> Total execution time: 0.0499
DEBUG - 2020-03-24 04:42:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 04:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 09:42:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 09:42:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 09:42:23 --> Total execution time: 0.1665
DEBUG - 2020-03-24 05:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 10:02:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:02:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 10:02:45 --> Total execution time: 0.1293
DEBUG - 2020-03-24 05:02:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:02:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:02:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 10:02:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 05:03:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:03:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:03:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 05:03:00 --> Total execution time: 0.1262
DEBUG - 2020-03-24 05:03:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 10:03:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:03:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 10:03:26 --> Total execution time: 0.1435
DEBUG - 2020-03-24 05:03:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 10:03:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:03:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 10:03:34 --> Total execution time: 0.0590
DEBUG - 2020-03-24 05:03:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 10:03:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:03:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 10:03:50 --> Total execution time: 0.0527
DEBUG - 2020-03-24 05:03:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 10:03:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:03:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 10:03:58 --> Total execution time: 0.0477
DEBUG - 2020-03-24 05:04:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 10:04:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:04:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 10:04:06 --> Total execution time: 0.0474
DEBUG - 2020-03-24 05:04:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 10:04:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:04:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 10:04:09 --> Total execution time: 0.0581
DEBUG - 2020-03-24 05:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 10:04:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:04:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 10:04:16 --> Total execution time: 0.0535
DEBUG - 2020-03-24 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 10:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-24 10:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 10:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 10:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 10:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 10:11:03 --> Total execution time: 0.2331
DEBUG - 2020-03-24 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 05:11:03 --> Total execution time: 0.0414
DEBUG - 2020-03-24 05:11:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:11:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-24 10:11:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-24 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-24 10:11:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-24 10:11:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-24 10:11:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 10:11:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 10:11:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 10:11:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 10:11:09 --> Total execution time: 0.1356
DEBUG - 2020-03-24 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:11:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 05:11:09 --> Total execution time: 0.0442
DEBUG - 2020-03-24 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-24 10:11:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-24 05:11:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/index.php
DEBUG - 2020-03-24 10:11:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 10:11:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 10:11:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 10:11:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 10:11:10 --> Total execution time: 0.0736
DEBUG - 2020-03-24 05:11:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:11:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 05:11:10 --> Total execution time: 0.0421
DEBUG - 2020-03-24 05:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-03-24 05:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/models/Batch_model.php
DEBUG - 2020-03-24 10:11:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/views/index.php
DEBUG - 2020-03-24 10:11:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 10:11:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 10:11:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 10:11:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 10:11:12 --> Total execution time: 0.1783
DEBUG - 2020-03-24 05:11:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:11:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 05:11:12 --> Total execution time: 0.0401
DEBUG - 2020-03-24 05:11:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/models/Batch_model.php
DEBUG - 2020-03-24 10:11:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/views/batch-view.php
DEBUG - 2020-03-24 05:11:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-24 10:11:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-24 10:11:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 10:11:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 10:11:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 10:11:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 10:11:13 --> Total execution time: 0.0716
DEBUG - 2020-03-24 05:11:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:11:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 05:11:13 --> Total execution time: 0.0411
DEBUG - 2020-03-24 05:11:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:11:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-24 10:11:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-24 05:11:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-24 10:11:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-03-24 10:11:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 10:11:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 10:11:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 10:11:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 10:11:14 --> Total execution time: 0.0865
DEBUG - 2020-03-24 05:11:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:11:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 05:11:15 --> Total execution time: 0.0420
DEBUG - 2020-03-24 05:11:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-24 10:11:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-24 05:11:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 10:11:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-24 10:11:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-24 10:11:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 10:11:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 10:11:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 10:11:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 10:11:17 --> Total execution time: 0.0515
DEBUG - 2020-03-24 05:11:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 05:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 05:11:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 05:11:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 05:11:17 --> Total execution time: 0.0413
DEBUG - 2020-03-24 06:18:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:18:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-24 11:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-24 11:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:18:34 --> Total execution time: 0.1406
DEBUG - 2020-03-24 06:18:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:18:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:18:34 --> Total execution time: 0.0413
DEBUG - 2020-03-24 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:27:40 --> No URI present. Default controller set.
DEBUG - 2020-03-24 06:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:27:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:27:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:27:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-24 11:27:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-24 11:27:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:27:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:27:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:27:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:27:41 --> Total execution time: 0.0579
DEBUG - 2020-03-24 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:27:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:27:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:27:41 --> Total execution time: 0.0815
DEBUG - 2020-03-24 06:27:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:27:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:27:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:27:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-24 11:27:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:27:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:27:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:27:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:27:42 --> Total execution time: 0.0857
DEBUG - 2020-03-24 06:27:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:27:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:27:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:27:42 --> Total execution time: 0.0428
DEBUG - 2020-03-24 06:27:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:27:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:27:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:27:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-24 06:27:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:27:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:27:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-03-24 11:27:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:27:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:27:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:27:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:27:44 --> Total execution time: 0.0751
DEBUG - 2020-03-24 06:27:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:27:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:27:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:27:44 --> Total execution time: 0.0408
DEBUG - 2020-03-24 06:27:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:27:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:27:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:27:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:27:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:27:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:28:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:28:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:28:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-24 11:28:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-03-24 11:28:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:28:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:28:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:28:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:28:00 --> Total execution time: 0.1571
DEBUG - 2020-03-24 06:28:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:28:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:28:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:28:01 --> Total execution time: 0.0422
DEBUG - 2020-03-24 06:28:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:28:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:28:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:28:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:28:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-24 11:28:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-03-24 06:43:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-24 11:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-24 11:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:43:01 --> Total execution time: 0.1712
DEBUG - 2020-03-24 06:43:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:43:01 --> Total execution time: 0.0446
DEBUG - 2020-03-24 06:43:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:43:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:43:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:43:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:43:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:43:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:43:03 --> Total execution time: 0.0629
DEBUG - 2020-03-24 06:43:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:43:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:43:03 --> Total execution time: 0.0484
DEBUG - 2020-03-24 06:43:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:43:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:43:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:43:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:43:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:43:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:43:15 --> Total execution time: 0.0678
DEBUG - 2020-03-24 06:43:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:43:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:43:15 --> Total execution time: 0.0408
DEBUG - 2020-03-24 06:43:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:43:35 --> Total execution time: 0.0522
DEBUG - 2020-03-24 06:43:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:43:35 --> Total execution time: 0.0402
DEBUG - 2020-03-24 06:43:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:43:44 --> Total execution time: 0.0604
DEBUG - 2020-03-24 06:43:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:43:44 --> Total execution time: 0.0579
DEBUG - 2020-03-24 06:43:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:43:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:43:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:43:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:43:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:43:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:43:53 --> Total execution time: 0.0553
DEBUG - 2020-03-24 06:43:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:43:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:43:53 --> Total execution time: 0.0386
DEBUG - 2020-03-24 06:43:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:43:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:43:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:44:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:44:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:44:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:44:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:44:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:44:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:44:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:44:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:44:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:44:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:45:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:45:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-24 11:45:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:45:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:45:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:45:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:45:15 --> Total execution time: 0.0618
DEBUG - 2020-03-24 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:45:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:45:15 --> Total execution time: 0.0515
DEBUG - 2020-03-24 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:45:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:45:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-24 06:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:45:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:45:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:45:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:45:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:45:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:45:16 --> Total execution time: 0.0588
DEBUG - 2020-03-24 06:45:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:45:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:45:16 --> Total execution time: 0.0522
DEBUG - 2020-03-24 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:45:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:45:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:45:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:45:29 --> Total execution time: 0.0605
DEBUG - 2020-03-24 06:45:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:45:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:45:29 --> Total execution time: 0.0379
DEBUG - 2020-03-24 06:45:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:45:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:45:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:45:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:45:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:45:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:45:57 --> Total execution time: 0.0571
DEBUG - 2020-03-24 06:45:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:45:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:45:57 --> Total execution time: 0.0413
DEBUG - 2020-03-24 06:45:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:45:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:45:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:45:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:45:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:45:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:45:58 --> Total execution time: 0.0568
DEBUG - 2020-03-24 06:45:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:45:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:45:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:45:58 --> Total execution time: 0.0453
DEBUG - 2020-03-24 06:46:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:46:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:46:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:46:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:46:02 --> Total execution time: 0.0584
DEBUG - 2020-03-24 06:46:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:46:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:46:02 --> Total execution time: 0.0395
DEBUG - 2020-03-24 06:46:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:46:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:46:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:46:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:46:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:46:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:46:15 --> Total execution time: 0.0571
DEBUG - 2020-03-24 06:46:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:46:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:46:15 --> Total execution time: 0.0433
DEBUG - 2020-03-24 06:46:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:46:16 --> Total execution time: 0.0645
DEBUG - 2020-03-24 06:46:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:46:16 --> Total execution time: 0.0394
DEBUG - 2020-03-24 06:46:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:46:16 --> Total execution time: 0.0538
DEBUG - 2020-03-24 06:46:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:46:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:46:16 --> Total execution time: 0.0479
DEBUG - 2020-03-24 06:46:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:46:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:46:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:46:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:46:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:46:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:46:18 --> Total execution time: 0.0567
DEBUG - 2020-03-24 06:46:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:46:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:46:18 --> Total execution time: 0.0407
DEBUG - 2020-03-24 06:46:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:46:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:46:21 --> Total execution time: 0.0673
DEBUG - 2020-03-24 06:46:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:46:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:46:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:46:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:46:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:46:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:46:56 --> Total execution time: 0.0634
DEBUG - 2020-03-24 06:46:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:46:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:46:56 --> Total execution time: 0.0506
DEBUG - 2020-03-24 06:46:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:46:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:46:57 --> Total execution time: 0.0488
DEBUG - 2020-03-24 06:46:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:46:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:47:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:47:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:47:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:47:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:47:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:47:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:47:17 --> Total execution time: 0.0654
DEBUG - 2020-03-24 06:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:47:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:47:17 --> Total execution time: 0.0597
DEBUG - 2020-03-24 06:47:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:47:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:47:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:47:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:47:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:47:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:47:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:47:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:47:22 --> Total execution time: 0.0570
DEBUG - 2020-03-24 06:47:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:47:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:47:22 --> Total execution time: 0.0440
DEBUG - 2020-03-24 06:47:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:47:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:47:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:47:28 --> Total execution time: 0.0649
DEBUG - 2020-03-24 06:47:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:47:28 --> Total execution time: 0.1968
DEBUG - 2020-03-24 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:47:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:47:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:47:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:47:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:47:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:47:48 --> Total execution time: 0.0644
DEBUG - 2020-03-24 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:47:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:47:48 --> Total execution time: 0.1471
DEBUG - 2020-03-24 06:47:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:47:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:48:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:48:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:48:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:48:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:48:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:48:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:48:13 --> Total execution time: 0.0999
DEBUG - 2020-03-24 06:48:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:48:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:48:13 --> Total execution time: 0.0545
DEBUG - 2020-03-24 06:48:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:48:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:48:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:48:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:48:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:48:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:48:14 --> Total execution time: 0.0592
DEBUG - 2020-03-24 06:48:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:48:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:48:15 --> Total execution time: 0.0406
DEBUG - 2020-03-24 06:48:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:48:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:48:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:48:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:48:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:48:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:48:20 --> Total execution time: 0.0604
DEBUG - 2020-03-24 06:48:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:48:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:48:20 --> Total execution time: 0.0396
DEBUG - 2020-03-24 06:48:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:48:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:48:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:48:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:48:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:48:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:48:22 --> Total execution time: 0.0618
DEBUG - 2020-03-24 06:48:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:48:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:48:22 --> Total execution time: 0.0442
DEBUG - 2020-03-24 06:48:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:48:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:48:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-24 11:48:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:48:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:48:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:48:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:48:23 --> Total execution time: 0.0510
DEBUG - 2020-03-24 06:48:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:48:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:48:24 --> Total execution time: 0.0800
DEBUG - 2020-03-24 06:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:48:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:48:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-24 06:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:48:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:48:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:48:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:48:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:48:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:48:24 --> Total execution time: 0.0628
DEBUG - 2020-03-24 06:48:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:48:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:48:24 --> Total execution time: 0.0398
DEBUG - 2020-03-24 06:48:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:48:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Module_model.php
DEBUG - 2020-03-24 11:48:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/views/module.php
DEBUG - 2020-03-24 11:48:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:48:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:48:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:48:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:48:45 --> Total execution time: 0.1608
DEBUG - 2020-03-24 06:48:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:48:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:48:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:48:45 --> Total execution time: 0.0446
DEBUG - 2020-03-24 06:49:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:49:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:49:02 --> Total execution time: 0.1484
DEBUG - 2020-03-24 06:49:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:49:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:49:17 --> Total execution time: 0.1381
DEBUG - 2020-03-24 06:49:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:49:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:49:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Module_model.php
DEBUG - 2020-03-24 11:49:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/views/module.php
DEBUG - 2020-03-24 11:49:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:49:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:49:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:49:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:49:18 --> Total execution time: 0.0662
DEBUG - 2020-03-24 06:49:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:49:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:49:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:49:19 --> Total execution time: 0.0418
DEBUG - 2020-03-24 06:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:49:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:49:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Module_model.php
DEBUG - 2020-03-24 06:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:49:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:49:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Module_model.php
DEBUG - 2020-03-24 11:49:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/views/module.php
DEBUG - 2020-03-24 11:49:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:49:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:49:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:49:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:49:42 --> Total execution time: 0.1079
DEBUG - 2020-03-24 06:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:49:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:49:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:49:42 --> Total execution time: 0.0430
DEBUG - 2020-03-24 06:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:49:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Role_model.php
DEBUG - 2020-03-24 11:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/views/role.php
DEBUG - 2020-03-24 11:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:49:44 --> Total execution time: 0.0986
DEBUG - 2020-03-24 06:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:49:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:49:44 --> Total execution time: 0.0423
DEBUG - 2020-03-24 06:49:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:49:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:49:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Role_model.php
DEBUG - 2020-03-24 11:49:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/views/permission.php
DEBUG - 2020-03-24 11:49:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:49:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:49:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:49:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:49:47 --> Total execution time: 0.0993
DEBUG - 2020-03-24 06:49:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:49:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:49:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:49:47 --> Total execution time: 0.0411
DEBUG - 2020-03-24 06:50:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Role_model.php
DEBUG - 2020-03-24 06:50:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Role_model.php
DEBUG - 2020-03-24 11:50:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/views/role.php
DEBUG - 2020-03-24 11:50:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:00 --> Total execution time: 0.0651
DEBUG - 2020-03-24 06:50:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:00 --> Total execution time: 0.0410
DEBUG - 2020-03-24 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-24 11:50:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-24 11:50:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:01 --> Total execution time: 0.0740
DEBUG - 2020-03-24 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:01 --> Total execution time: 0.0422
DEBUG - 2020-03-24 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:50:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:04 --> Total execution time: 0.0615
DEBUG - 2020-03-24 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:04 --> Total execution time: 0.0403
DEBUG - 2020-03-24 06:50:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:50:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:18 --> Total execution time: 0.0563
DEBUG - 2020-03-24 06:50:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:18 --> Total execution time: 0.0417
DEBUG - 2020-03-24 06:50:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:50:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:26 --> Total execution time: 0.0571
DEBUG - 2020-03-24 06:50:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:26 --> Total execution time: 0.0423
DEBUG - 2020-03-24 06:50:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:50:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:28 --> Total execution time: 0.0567
DEBUG - 2020-03-24 06:50:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:28 --> Total execution time: 0.0450
DEBUG - 2020-03-24 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:50:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:34 --> Total execution time: 0.0757
DEBUG - 2020-03-24 06:50:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:34 --> Total execution time: 0.0402
DEBUG - 2020-03-24 06:50:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-24 11:50:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-24 11:50:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:35 --> Total execution time: 0.1216
DEBUG - 2020-03-24 06:50:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:35 --> Total execution time: 0.0414
DEBUG - 2020-03-24 06:50:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:50:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-24 11:50:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:38 --> Total execution time: 0.0615
DEBUG - 2020-03-24 06:50:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:38 --> Total execution time: 0.0407
DEBUG - 2020-03-24 06:50:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:50:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-24 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:50:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-24 11:50:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:39 --> Total execution time: 0.0597
DEBUG - 2020-03-24 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:39 --> Total execution time: 0.0425
DEBUG - 2020-03-24 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-24 06:50:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:40 --> Total execution time: 0.0527
DEBUG - 2020-03-24 06:50:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:40 --> Total execution time: 0.0416
DEBUG - 2020-03-24 06:50:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:50:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-24 11:50:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:42 --> Total execution time: 0.0617
DEBUG - 2020-03-24 06:50:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:42 --> Total execution time: 0.0516
DEBUG - 2020-03-24 06:50:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:50:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-24 06:50:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:50:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:44 --> Total execution time: 0.0644
DEBUG - 2020-03-24 06:50:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:44 --> Total execution time: 0.0402
DEBUG - 2020-03-24 06:50:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:50:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-24 11:50:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:46 --> Total execution time: 0.0603
DEBUG - 2020-03-24 06:50:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:46 --> Total execution time: 0.0500
DEBUG - 2020-03-24 06:50:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 11:50:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-24 06:50:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 11:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 11:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 11:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 11:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 11:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 11:50:47 --> Total execution time: 0.0596
DEBUG - 2020-03-24 06:50:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 06:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 06:50:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 06:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 06:50:47 --> Total execution time: 0.0414
DEBUG - 2020-03-24 07:11:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:11:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:11:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:11:53 --> Total execution time: 0.1451
DEBUG - 2020-03-24 07:12:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:12:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:12:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:12:15 --> Total execution time: 0.0553
DEBUG - 2020-03-24 07:13:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:13:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:13:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:13:37 --> Unable to find callback validation rule: game_type_id
ERROR - 2020-03-24 12:13:37 --> Could not find the language line "form_validation_game_type_id"
DEBUG - 2020-03-24 12:13:37 --> Total execution time: 0.0701
DEBUG - 2020-03-24 07:14:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:14:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:14:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-24 12:14:03 --> Query error: Unknown column 'game_type_id' in 'where clause' - Invalid query: SELECT *
FROM `game_type`
WHERE `game_type_id` = '1'
AND `type` = 'challenge'
DEBUG - 2020-03-24 07:14:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:14:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:14:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:14:24 --> Total execution time: 0.1426
DEBUG - 2020-03-24 07:14:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:14:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:14:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-24 12:14:39 --> Could not find the language line "form_validation_game_type"
DEBUG - 2020-03-24 12:14:39 --> Total execution time: 0.0498
DEBUG - 2020-03-24 07:14:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:14:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:14:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:14:58 --> Total execution time: 0.0565
DEBUG - 2020-03-24 07:15:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:15:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:15:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:15:05 --> Total execution time: 0.0675
DEBUG - 2020-03-24 07:15:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:15:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:15:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:15:25 --> Total execution time: 0.0936
DEBUG - 2020-03-24 07:15:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:15:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:15:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:15:33 --> Total execution time: 0.1551
DEBUG - 2020-03-24 07:15:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:15:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:15:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:15:53 --> Total execution time: 0.0786
DEBUG - 2020-03-24 07:15:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:15:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:15:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:15:54 --> Total execution time: 0.0786
DEBUG - 2020-03-24 07:15:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:15:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:15:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:15:55 --> Total execution time: 0.1192
DEBUG - 2020-03-24 07:18:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 07:18:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:18:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-24 12:18:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 12:18:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 12:18:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 12:18:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 12:18:08 --> Total execution time: 0.1267
DEBUG - 2020-03-24 07:18:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 07:18:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 07:18:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 07:18:08 --> Total execution time: 0.0427
DEBUG - 2020-03-24 07:18:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 12:18:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:18:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-24 12:18:59 --> Total execution time: 0.1458
DEBUG - 2020-03-24 07:23:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 07:23:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:23:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-24 12:23:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-24 12:23:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 12:23:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 12:23:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 12:23:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 12:23:50 --> Total execution time: 0.1151
DEBUG - 2020-03-24 07:23:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 07:23:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 07:23:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 07:23:50 --> Total execution time: 0.0451
DEBUG - 2020-03-24 07:24:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 07:24:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:24:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 12:24:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-24 12:24:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-24 12:24:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-24 12:24:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-24 12:24:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-24 12:24:13 --> Total execution time: 0.1465
DEBUG - 2020-03-24 07:24:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 07:24:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 07:24:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-24 07:24:13 --> Total execution time: 0.0411
DEBUG - 2020-03-24 07:24:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-24 07:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-24 07:24:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-24 12:24:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-24 12:24:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
