<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-25 07:01:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:09 --> No URI present. Default controller set.
DEBUG - 2020-03-25 07:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-25 07:01:09 --> Total execution time: 0.1624
DEBUG - 2020-03-25 07:01:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 07:01:09 --> Total execution time: 0.1228
DEBUG - 2020-03-25 07:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 07:01:10 --> Total execution time: 0.1345
DEBUG - 2020-03-25 07:01:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 12:01:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-25 12:01:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-25 12:01:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 12:01:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 12:01:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 12:01:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 12:01:16 --> Total execution time: 0.2475
DEBUG - 2020-03-25 07:01:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 07:01:16 --> Total execution time: 0.1372
DEBUG - 2020-03-25 07:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 12:01:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-25 12:01:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-25 12:01:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 12:01:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 12:01:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 12:01:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 12:01:21 --> Total execution time: 0.2649
DEBUG - 2020-03-25 07:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 07:01:22 --> Total execution time: 0.1345
DEBUG - 2020-03-25 07:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 12:01:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-25 12:01:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-25 07:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 12:01:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 12:01:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 12:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 12:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 12:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 12:01:24 --> Total execution time: 0.2006
DEBUG - 2020-03-25 07:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 07:01:24 --> Total execution time: 0.1395
DEBUG - 2020-03-25 07:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 12:01:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 12:01:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 12:01:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 12:01:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 12:01:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 12:01:37 --> Total execution time: 0.1663
DEBUG - 2020-03-25 07:01:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 07:01:37 --> Total execution time: 0.1522
DEBUG - 2020-03-25 07:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 12:01:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 12:01:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 12:01:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 12:01:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 12:01:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 12:01:43 --> Total execution time: 0.1498
DEBUG - 2020-03-25 07:01:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 07:01:44 --> Total execution time: 0.1323
DEBUG - 2020-03-25 07:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 12:01:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 12:01:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 12:01:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 12:01:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 12:01:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 12:01:45 --> Total execution time: 0.1794
DEBUG - 2020-03-25 07:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:01:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:01:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 07:01:46 --> Total execution time: 0.1609
DEBUG - 2020-03-25 07:17:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:17:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 12:17:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 12:17:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 12:17:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 12:17:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 12:17:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 12:17:04 --> Total execution time: 0.2045
DEBUG - 2020-03-25 07:17:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:17:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:17:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 07:17:04 --> Total execution time: 0.1635
DEBUG - 2020-03-25 07:22:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:22:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:22:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:22:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:22:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:22:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 12:22:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 12:22:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 12:22:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 12:22:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 12:22:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 12:22:43 --> Total execution time: 0.1641
DEBUG - 2020-03-25 07:22:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:22:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:22:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 07:22:43 --> Total execution time: 0.1425
DEBUG - 2020-03-25 07:33:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:33:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 12:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 12:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 12:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 12:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 12:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 12:33:03 --> Total execution time: 0.2588
DEBUG - 2020-03-25 07:33:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 07:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 07:33:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 07:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 07:33:03 --> Total execution time: 0.1754
DEBUG - 2020-03-25 09:17:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 09:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 09:17:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 14:17:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 14:17:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 14:17:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 14:17:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 14:17:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 14:17:40 --> Total execution time: 0.7269
DEBUG - 2020-03-25 09:17:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 09:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 09:17:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 09:17:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 09:17:40 --> Total execution time: 0.1826
DEBUG - 2020-03-25 14:31:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 14:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 14:31:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 14:31:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 14:31:01 --> No URI present. Default controller set.
DEBUG - 2020-03-25 14:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 14:31:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 14:31:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-25 14:31:02 --> Total execution time: 0.3727
DEBUG - 2020-03-25 14:31:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 14:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 14:31:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 14:31:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 14:31:04 --> Total execution time: 0.3093
DEBUG - 2020-03-25 14:31:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 14:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 14:31:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 14:31:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 14:31:07 --> Total execution time: 0.1593
DEBUG - 2020-03-25 15:33:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 20:33:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:33:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-25 20:33:40 --> Severity: Notice --> Undefined property: ContentController::$question D:\shipan7.2\htdocs\xplore\application\controllers\api\ContentController.php 226
ERROR - 2020-03-25 20:33:40 --> Severity: error --> Exception: Call to a member function duplicate_check() on null D:\shipan7.2\htdocs\xplore\application\controllers\api\ContentController.php 226
DEBUG - 2020-03-25 15:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 20:34:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:34:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 20:34:16 --> Total execution time: 0.2474
DEBUG - 2020-03-25 15:34:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 20:34:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:34:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 20:34:57 --> Total execution time: 0.3567
DEBUG - 2020-03-25 15:35:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 20:35:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:35:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 20:35:57 --> Total execution time: 0.1487
DEBUG - 2020-03-25 15:36:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 20:36:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:36:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-25 20:36:21 --> Severity: Notice --> Undefined property: stdClass::$user_question_count D:\shipan7.2\htdocs\xplore\application\controllers\api\ContentController.php 187
DEBUG - 2020-03-25 20:36:21 --> Total execution time: 0.2991
DEBUG - 2020-03-25 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 20:36:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:36:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 20:36:45 --> Total execution time: 0.1452
DEBUG - 2020-03-25 15:37:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 20:37:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:37:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 20:37:50 --> Total execution time: 0.1336
DEBUG - 2020-03-25 15:37:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 20:37:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:37:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 20:37:55 --> You did not select a file to upload.
DEBUG - 2020-03-25 15:39:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 20:39:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:39:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 20:39:46 --> Total execution time: 0.2454
DEBUG - 2020-03-25 15:45:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:45:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:45:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:45:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:45:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-25 20:45:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-25 20:45:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 20:45:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 20:45:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 20:45:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 20:45:46 --> Total execution time: 0.8563
DEBUG - 2020-03-25 15:45:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:45:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:45:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 15:45:47 --> Total execution time: 0.3966
DEBUG - 2020-03-25 15:45:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:45:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:45:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-25 20:45:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-25 20:45:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 20:45:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 20:45:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 20:45:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 20:45:54 --> Total execution time: 0.4682
DEBUG - 2020-03-25 15:45:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:45:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:45:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 15:45:54 --> Total execution time: 0.1125
DEBUG - 2020-03-25 15:45:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:45:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:45:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:45:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:45:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-25 20:45:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-25 15:46:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:46:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 20:46:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 20:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 20:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 20:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 20:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 20:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 20:46:00 --> Total execution time: 0.3859
DEBUG - 2020-03-25 15:46:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:46:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 15:46:00 --> Total execution time: 0.1285
DEBUG - 2020-03-25 15:46:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:46:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:46:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:46:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:46:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 20:46:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 15:46:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:46:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:46:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 15:46:12 --> Total execution time: 0.1235
DEBUG - 2020-03-25 15:47:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:47:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:47:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 20:47:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 20:47:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 20:47:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 20:47:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 20:47:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 20:47:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 20:47:08 --> Total execution time: 0.2040
DEBUG - 2020-03-25 15:47:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:47:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:47:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 15:47:08 --> Total execution time: 0.1342
DEBUG - 2020-03-25 15:47:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:47:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:47:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:47:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:47:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 20:47:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 15:47:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:47:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:47:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-25 20:47:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-25 20:47:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 20:47:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 20:47:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 20:47:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 20:47:12 --> Total execution time: 0.2085
DEBUG - 2020-03-25 15:47:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:47:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:47:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 15:47:12 --> Total execution time: 0.1207
DEBUG - 2020-03-25 15:50:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:50:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:50:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-25 20:50:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-25 20:50:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 20:50:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 20:50:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 20:50:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 20:50:29 --> Total execution time: 0.1964
DEBUG - 2020-03-25 15:50:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:50:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:50:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 15:50:29 --> Total execution time: 0.1316
DEBUG - 2020-03-25 15:50:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:50:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-25 20:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-25 20:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 20:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 20:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 20:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 20:50:40 --> Total execution time: 0.1822
DEBUG - 2020-03-25 15:50:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:50:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:50:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 15:50:40 --> Total execution time: 0.1188
DEBUG - 2020-03-25 15:50:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:50:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-25 20:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-25 20:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 20:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 20:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 20:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 20:50:47 --> Total execution time: 0.2171
DEBUG - 2020-03-25 15:50:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:50:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:50:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 15:50:48 --> Total execution time: 0.1216
DEBUG - 2020-03-25 15:52:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:52:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 20:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-03-25 20:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 20:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 20:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 20:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 20:52:43 --> Total execution time: 0.2538
DEBUG - 2020-03-25 15:52:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 15:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 15:52:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 15:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 15:52:43 --> Total execution time: 0.1380
DEBUG - 2020-03-25 16:13:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:13:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-25 21:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-25 21:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:13:19 --> Total execution time: 0.2657
DEBUG - 2020-03-25 16:13:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:13:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:13:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:13:20 --> Total execution time: 0.1383
DEBUG - 2020-03-25 16:13:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:13:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:13:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 21:13:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:13:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:13:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:13:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:13:28 --> Total execution time: 0.2453
DEBUG - 2020-03-25 16:13:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:13:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:13:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:13:28 --> Total execution time: 0.1280
DEBUG - 2020-03-25 16:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:13:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:13:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:13:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:13:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:13:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:13:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:13:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:13:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:13:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:13:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 21:13:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:13:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:13:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:13:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:13:55 --> Total execution time: 0.1660
DEBUG - 2020-03-25 16:13:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:13:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:13:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:13:55 --> Total execution time: 0.1246
DEBUG - 2020-03-25 16:17:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:17:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 21:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:17:45 --> Total execution time: 0.1795
DEBUG - 2020-03-25 16:17:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:17:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:17:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:17:46 --> Total execution time: 0.1329
DEBUG - 2020-03-25 16:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:17:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:17:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:17:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 21:17:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 21:17:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:17:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:17:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:17:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:17:50 --> Total execution time: 0.2657
DEBUG - 2020-03-25 16:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:17:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:17:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:17:50 --> Total execution time: 0.1187
DEBUG - 2020-03-25 16:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:17:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:17:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:17:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:17:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:17:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 16:41:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 21:41:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 21:41:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:41:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:41:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:41:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:41:11 --> Total execution time: 0.2777
DEBUG - 2020-03-25 16:41:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:41:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:41:11 --> Total execution time: 0.1266
DEBUG - 2020-03-25 16:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 16:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:41:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:41:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:41:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:41:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:41:13 --> Total execution time: 0.1859
DEBUG - 2020-03-25 16:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:41:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:41:13 --> Total execution time: 0.1193
DEBUG - 2020-03-25 16:41:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 16:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 16:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:24 --> Total execution time: 0.1212
DEBUG - 2020-03-25 16:41:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:41:27 --> Total execution time: 0.2392
DEBUG - 2020-03-25 16:41:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:41:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:41:28 --> Total execution time: 0.1368
DEBUG - 2020-03-25 16:41:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:41:31 --> Total execution time: 0.1833
DEBUG - 2020-03-25 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:41:31 --> Total execution time: 0.1338
DEBUG - 2020-03-25 16:41:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:41:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:36 --> Total execution time: 0.1216
DEBUG - 2020-03-25 16:41:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:41:38 --> Total execution time: 0.2108
DEBUG - 2020-03-25 16:41:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:41:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:41:39 --> Total execution time: 0.1463
DEBUG - 2020-03-25 16:41:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:41:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:41:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:41:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:42:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:42:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:42:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:42:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:42:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:42:22 --> Total execution time: 0.1997
DEBUG - 2020-03-25 16:42:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:42:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:42:23 --> Total execution time: 0.1114
DEBUG - 2020-03-25 16:42:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:42:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:42:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 21:42:26 --> Total execution time: 0.3887
DEBUG - 2020-03-25 16:42:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:42:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 21:42:27 --> Total execution time: 0.2191
DEBUG - 2020-03-25 16:42:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:42:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:33 --> Total execution time: 0.1052
DEBUG - 2020-03-25 21:42:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:42:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 21:42:35 --> Total execution time: 0.3349
DEBUG - 2020-03-25 16:42:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:42:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:42:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:42:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:42:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:42:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:42:39 --> Total execution time: 0.2126
DEBUG - 2020-03-25 16:42:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:42:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:42:39 --> Total execution time: 0.1340
DEBUG - 2020-03-25 16:42:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:42:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:46 --> Total execution time: 0.1225
DEBUG - 2020-03-25 16:42:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:42:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:42:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:42:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:42:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:42:48 --> Total execution time: 0.2006
DEBUG - 2020-03-25 16:42:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:42:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:42:48 --> Total execution time: 0.1311
DEBUG - 2020-03-25 16:42:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:42:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:42:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:42:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:43:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:43:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:43:43 --> Total execution time: 0.2132
DEBUG - 2020-03-25 16:43:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:43:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:43:43 --> Total execution time: 0.1273
DEBUG - 2020-03-25 16:43:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:43:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 21:43:44 --> Query error: Unknown column 'Q.status' in 'field list' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`
FROM `user_question` as `Q`
) CI_count_all_results
DEBUG - 2020-03-25 16:44:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:44:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:44:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:44:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:44:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:44:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:44:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:44:01 --> Total execution time: 0.1953
DEBUG - 2020-03-25 16:44:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:44:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:44:01 --> Total execution time: 0.1253
DEBUG - 2020-03-25 16:44:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:44:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 21:44:02 --> Query error: Unknown column 'Q.status' in 'field list' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`
FROM `user_question` as `Q`
) CI_count_all_results
DEBUG - 2020-03-25 16:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:44:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:44:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:44:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:44:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:44:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:44:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:44:09 --> Total execution time: 0.1957
DEBUG - 2020-03-25 16:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:44:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:44:09 --> Total execution time: 0.1285
DEBUG - 2020-03-25 16:44:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:44:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 21:44:10 --> Query error: Unknown column 'Q.status' in 'field list' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`
FROM `user_question` as `Q`
) CI_count_all_results
DEBUG - 2020-03-25 16:44:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:44:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 21:44:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:44:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:44:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:44:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:44:20 --> Total execution time: 0.2043
DEBUG - 2020-03-25 16:44:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:44:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:44:20 --> Total execution time: 0.1207
DEBUG - 2020-03-25 16:44:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:44:25 --> Total execution time: 0.1846
DEBUG - 2020-03-25 16:44:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:44:25 --> Total execution time: 0.1197
DEBUG - 2020-03-25 16:44:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 21:44:26 --> Query error: Unknown column 'Q.status' in 'field list' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`
FROM `user_question` as `Q`
) CI_count_all_results
DEBUG - 2020-03-25 16:44:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-25 21:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-25 21:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:44:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:44:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:44:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:44:30 --> Total execution time: 0.2513
DEBUG - 2020-03-25 16:44:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:44:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:44:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:44:30 --> Total execution time: 0.1329
DEBUG - 2020-03-25 16:45:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:45:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 21:45:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:45:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:45:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:45:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:45:01 --> Total execution time: 0.2494
DEBUG - 2020-03-25 16:45:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:45:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:45:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:04 --> Total execution time: 0.2517
DEBUG - 2020-03-25 16:45:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:45:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 21:45:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:45:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:45:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:45:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:45:04 --> Total execution time: 0.4066
DEBUG - 2020-03-25 16:45:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:45:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:45:05 --> Total execution time: 0.1331
DEBUG - 2020-03-25 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:45:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-25 21:45:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:45:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:45:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:45:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:45:33 --> Total execution time: 0.2542
DEBUG - 2020-03-25 16:45:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:45:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-25 21:45:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-25 21:45:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:45:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:45:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:45:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:45:40 --> Total execution time: 0.2695
DEBUG - 2020-03-25 16:45:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:45:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:45:40 --> Total execution time: 0.1810
DEBUG - 2020-03-25 16:45:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:45:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-25 21:45:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-25 16:45:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:45:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:45:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:45:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:45:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:45:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:45:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:45:42 --> Total execution time: 0.2131
DEBUG - 2020-03-25 16:45:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:45:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:45:43 --> Total execution time: 0.1630
DEBUG - 2020-03-25 16:45:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:45:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 21:45:43 --> Query error: Unknown column 'Q.status' in 'field list' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`
FROM `user_question` as `Q`
) CI_count_all_results
DEBUG - 2020-03-25 16:45:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:45:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:45:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:45:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:45:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:45:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:45:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:45:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:45:45 --> Total execution time: 0.2546
DEBUG - 2020-03-25 16:48:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:48:06 --> No URI present. Default controller set.
DEBUG - 2020-03-25 16:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:48:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:48:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-25 16:48:07 --> Total execution time: 0.2448
DEBUG - 2020-03-25 16:48:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:48:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:48:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:48:07 --> Total execution time: 0.1672
DEBUG - 2020-03-25 16:48:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:48:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:48:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:48:08 --> Total execution time: 0.1219
DEBUG - 2020-03-25 16:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:52:23 --> No URI present. Default controller set.
DEBUG - 2020-03-25 16:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:52:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-03-25 16:52:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\shipan7.2\htdocs\xplore\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-03-25 16:52:32 --> Unable to connect to the database
DEBUG - 2020-03-25 16:52:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:52:35 --> No URI present. Default controller set.
DEBUG - 2020-03-25 16:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:52:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:52:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-25 16:52:42 --> Total execution time: 6.9141
DEBUG - 2020-03-25 16:52:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:52:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:52:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:52:43 --> Total execution time: 0.4725
DEBUG - 2020-03-25 16:52:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:52:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:52:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:52:44 --> Total execution time: 0.1090
DEBUG - 2020-03-25 16:52:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:52:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:52:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:52:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-25 21:52:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-25 21:52:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:52:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:52:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:52:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:52:56 --> Total execution time: 1.3594
DEBUG - 2020-03-25 16:52:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:52:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:52:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:52:57 --> Total execution time: 0.1091
DEBUG - 2020-03-25 16:53:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:53:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:53:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:53:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:53:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:53:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:53:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:53:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:53:05 --> Total execution time: 1.1988
DEBUG - 2020-03-25 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:53:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:53:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:53:05 --> Total execution time: 0.1806
DEBUG - 2020-03-25 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:53:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:53:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 21:53:06 --> Query error: Unknown column 'Q.status' in 'field list' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`
FROM `user_question` as `Q`
) CI_count_all_results
DEBUG - 2020-03-25 16:53:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:53:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:53:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:53:08 --> Total execution time: 0.2461
DEBUG - 2020-03-25 16:53:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:53:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:53:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:53:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:53:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:53:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:53:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:53:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:53:13 --> Total execution time: 0.2036
DEBUG - 2020-03-25 16:53:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:53:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:53:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:53:13 --> Total execution time: 0.2345
DEBUG - 2020-03-25 16:53:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:53:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:53:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 21:53:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 21:53:14 --> Query error: Unknown column 'Q.status' in 'field list' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`
FROM `user_question` as `Q`
) CI_count_all_results
DEBUG - 2020-03-25 16:53:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:53:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:53:15 --> Total execution time: 0.3729
DEBUG - 2020-03-25 16:55:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:55:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:55:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:55:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:55:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:55:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:55:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:55:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:55:32 --> Total execution time: 0.4777
DEBUG - 2020-03-25 16:55:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:55:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:55:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:55:32 --> Total execution time: 0.6696
DEBUG - 2020-03-25 16:55:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:55:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:55:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:55:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:55:33 --> Total execution time: 0.1815
DEBUG - 2020-03-25 16:55:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:55:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:55:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:57:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:57:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:57:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 21:57:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 21:57:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:57:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:57:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:57:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:57:17 --> Total execution time: 0.3190
DEBUG - 2020-03-25 16:57:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:57:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:57:18 --> Total execution time: 0.1436
DEBUG - 2020-03-25 16:57:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:57:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:57:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:57:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 16:57:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:57:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:57:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:57:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:57:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:57:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:57:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:57:20 --> Total execution time: 0.2389
DEBUG - 2020-03-25 16:57:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:57:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:57:20 --> Total execution time: 0.1425
DEBUG - 2020-03-25 16:57:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:57:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:57:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:57:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:57:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:57:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 21:57:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 21:57:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:57:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:57:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:57:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:57:23 --> Total execution time: 0.2016
DEBUG - 2020-03-25 16:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:57:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:57:23 --> Total execution time: 0.1197
DEBUG - 2020-03-25 16:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 16:57:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:57:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:57:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:57:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:57:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:57:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:57:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:57:27 --> Total execution time: 0.1819
DEBUG - 2020-03-25 16:57:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:57:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:57:27 --> Total execution time: 0.1280
DEBUG - 2020-03-25 16:57:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:57:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:57:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:57:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:58:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:58:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:58:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:58:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:58:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:58:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 21:58:04 --> Total execution time: 0.2363
DEBUG - 2020-03-25 16:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:58:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:58:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:58:08 --> Total execution time: 0.1323
DEBUG - 2020-03-25 21:58:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:58:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:58:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:58:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:58:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:58:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:58:10 --> Total execution time: 0.1287
DEBUG - 2020-03-25 21:58:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:58:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:58:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:58:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:58:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:58:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:58:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 21:58:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:58:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 21:58:46 --> Total execution time: 0.5794
DEBUG - 2020-03-25 16:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:59:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:59:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:59:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:59:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:59:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:59:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:59:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:59:09 --> Total execution time: 0.2848
DEBUG - 2020-03-25 16:59:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:59:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:59:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:59:10 --> Total execution time: 0.1449
DEBUG - 2020-03-25 16:59:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:59:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:59:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 21:59:11 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
ERROR - 2020-03-25 21:59:11 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
DEBUG - 2020-03-25 21:59:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:59:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:59:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:59:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:59:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 21:59:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 21:59:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 21:59:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 21:59:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 21:59:54 --> Total execution time: 0.3227
DEBUG - 2020-03-25 16:59:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:59:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 16:59:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 16:59:55 --> Total execution time: 0.1917
DEBUG - 2020-03-25 16:59:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:59:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:59:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:59:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 16:59:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 16:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 16:59:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 21:59:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 21:59:57 --> Total execution time: 0.1207
DEBUG - 2020-03-25 17:00:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:00:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:00:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:00:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:00:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:00:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:00:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:00:00 --> Total execution time: 0.2179
DEBUG - 2020-03-25 17:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:00:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:00:01 --> Total execution time: 0.1672
DEBUG - 2020-03-25 17:00:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:00:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:00:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:00:06 --> Total execution time: 0.1796
DEBUG - 2020-03-25 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:00:06 --> Total execution time: 0.1315
DEBUG - 2020-03-25 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:00:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:00:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:00:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:00:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:00:11 --> Total execution time: 0.1183
DEBUG - 2020-03-25 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:00:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:00:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:00:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:00:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:00:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:00:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:00:13 --> Total execution time: 0.1957
DEBUG - 2020-03-25 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:00:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:00:13 --> Total execution time: 0.1333
DEBUG - 2020-03-25 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:00:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:00:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:00:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:00:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:00:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:00:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:00:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:00:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:00:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:00:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:00:28 --> Total execution time: 0.2625
DEBUG - 2020-03-25 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:00:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:00:29 --> Total execution time: 0.1593
DEBUG - 2020-03-25 17:00:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:00:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:00:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:00:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:08:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:08:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:08:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:08:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:08:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:08:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:08:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:08:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:08:59 --> Total execution time: 1.4877
DEBUG - 2020-03-25 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:08:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:08:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:08:59 --> Total execution time: 0.1827
DEBUG - 2020-03-25 17:09:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:09:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:09:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:09:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:09:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:09:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:09:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-details.php
DEBUG - 2020-03-25 17:09:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:09:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:09:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:09:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-details.php
DEBUG - 2020-03-25 17:09:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:09:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:09:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:09:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:09:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:09:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:09:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:09:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:09:20 --> Total execution time: 0.1963
DEBUG - 2020-03-25 17:09:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:09:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:09:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:09:20 --> Total execution time: 0.1483
DEBUG - 2020-03-25 17:09:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:09:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:09:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:09:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:09:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:09:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:09:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-details.php
DEBUG - 2020-03-25 17:10:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:10:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:10:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-details.php
DEBUG - 2020-03-25 17:10:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 17:10:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:10:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:10:41 --> Total execution time: 0.4564
DEBUG - 2020-03-25 17:10:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:10:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:10:42 --> Total execution time: 0.1570
DEBUG - 2020-03-25 17:10:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:10:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:10:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:10:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:10:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:10:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:10:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:10:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:10:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:10:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:10:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:10:47 --> Total execution time: 0.2439
DEBUG - 2020-03-25 17:10:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:10:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:10:47 --> Total execution time: 0.1317
DEBUG - 2020-03-25 17:10:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:10:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:10:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:10:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 22:10:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:10:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 22:10:53 --> Total execution time: 0.7216
DEBUG - 2020-03-25 17:10:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:10:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:10:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:10:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:10:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:10:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:10:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:10:57 --> Total execution time: 0.2217
DEBUG - 2020-03-25 17:10:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:10:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:10:57 --> Total execution time: 0.1438
DEBUG - 2020-03-25 17:10:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:10:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:10:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:10:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:32:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:32:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:32:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:32:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:32:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:32:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:32:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:32:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:32:45 --> Total execution time: 0.2791
DEBUG - 2020-03-25 17:32:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:32:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:32:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:32:45 --> Total execution time: 0.1383
DEBUG - 2020-03-25 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:32:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:32:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:32:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:32:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:32:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:32:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 22:32:50 --> Severity: error --> Exception: Too few arguments to function MY_Model::insert(), 1 passed in D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php on line 589 and exactly 2 expected D:\shipan7.2\htdocs\xplore\application\core\MY_Model.php 12
DEBUG - 2020-03-25 17:35:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:35:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:35:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 22:35:17 --> Severity: Notice --> Undefined property: stdClass::$catgeory_id D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 594
DEBUG - 2020-03-25 22:35:17 --> Total execution time: 0.2474
DEBUG - 2020-03-25 17:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:35:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:35:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 22:35:50 --> Severity: Notice --> Trying to get property 'title' of non-object D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 574
ERROR - 2020-03-25 22:35:50 --> Severity: Notice --> Trying to get property 'difficulty' of non-object D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 575
ERROR - 2020-03-25 22:35:50 --> Severity: Notice --> Trying to get property 'option_1' of non-object D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 576
ERROR - 2020-03-25 22:35:50 --> Severity: Notice --> Trying to get property 'option_2' of non-object D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 577
ERROR - 2020-03-25 22:35:50 --> Severity: Notice --> Trying to get property 'option_3' of non-object D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 578
ERROR - 2020-03-25 22:35:50 --> Severity: Notice --> Trying to get property 'option_4' of non-object D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 579
ERROR - 2020-03-25 22:35:50 --> Severity: Notice --> Trying to get property 'answer' of non-object D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 580
ERROR - 2020-03-25 22:35:50 --> Severity: Notice --> Trying to get property 'answer_explain' of non-object D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 581
ERROR - 2020-03-25 22:35:50 --> Severity: Notice --> Trying to get property 'picture' of non-object D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 582
ERROR - 2020-03-25 22:35:50 --> Severity: Notice --> Trying to get property 'created_by' of non-object D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 583
ERROR - 2020-03-25 22:35:50 --> Query error: Column 'title' cannot be null - Invalid query: INSERT INTO `question` (`title`, `difficulty`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`, `answer_explain`, `picture`, `created_by_user`, `created_by_admin`, `approved_by`, `status`, `position`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '1', 1, 54)
DEBUG - 2020-03-25 22:35:51 --> DB Transaction Failure
ERROR - 2020-03-25 22:35:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\shipan7.2\htdocs\xplore\system\core\Exceptions.php:271) D:\shipan7.2\htdocs\xplore\system\core\Common.php 575
DEBUG - 2020-03-25 17:36:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 22:36:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:36:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 22:36:25 --> Total execution time: 0.2802
DEBUG - 2020-03-25 17:36:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:36:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:36:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:36:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:36:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:36:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:36:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:36:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:36:29 --> Total execution time: 0.2413
DEBUG - 2020-03-25 17:36:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:36:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:36:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:36:29 --> Total execution time: 0.1501
DEBUG - 2020-03-25 17:36:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:36:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:36:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:36:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:36:31 --> Total execution time: 0.1988
DEBUG - 2020-03-25 17:36:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:36:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:36:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:36:32 --> Total execution time: 0.1733
DEBUG - 2020-03-25 17:36:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:36:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:36:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:36:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:36:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:36:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:36:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:36:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-details.php
DEBUG - 2020-03-25 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:37:08 --> Total execution time: 0.1877
DEBUG - 2020-03-25 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:37:08 --> Total execution time: 0.1322
DEBUG - 2020-03-25 17:37:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:37:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:37:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:37:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:37:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 17:37:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:37:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:37:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:37:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:37:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:37:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:37:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:37:22 --> Total execution time: 0.3428
DEBUG - 2020-03-25 17:37:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:37:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:37:22 --> Total execution time: 0.1896
DEBUG - 2020-03-25 17:37:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:37:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:37:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:37:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:37:24 --> Total execution time: 0.2549
DEBUG - 2020-03-25 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:37:24 --> Total execution time: 0.1552
DEBUG - 2020-03-25 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:37:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:37:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:37:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:37:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-details.php
DEBUG - 2020-03-25 17:37:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:37:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:37:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 22:37:30 --> Severity: Notice --> Undefined property: stdClass::$catgeory_id D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 596
DEBUG - 2020-03-25 22:37:30 --> Total execution time: 0.2423
DEBUG - 2020-03-25 17:38:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:38:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:38:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:38:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:38:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:38:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:38:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:38:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:38:41 --> Total execution time: 0.2297
DEBUG - 2020-03-25 17:38:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:38:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:38:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:38:41 --> Total execution time: 0.1492
DEBUG - 2020-03-25 17:38:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:38:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:38:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:38:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:38:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 22:38:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:38:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 22:38:46 --> Total execution time: 0.1193
DEBUG - 2020-03-25 17:38:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:38:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:38:50 --> Total execution time: 0.2010
DEBUG - 2020-03-25 17:38:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:38:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:38:50 --> Total execution time: 0.1628
DEBUG - 2020-03-25 17:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:38:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:38:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:38:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:38:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:38:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:38:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:38:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:38:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:38:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:38:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:38:53 --> Total execution time: 0.1936
DEBUG - 2020-03-25 17:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:38:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:38:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:38:54 --> Total execution time: 0.1462
DEBUG - 2020-03-25 17:38:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:38:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:38:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:38:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:38:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 22:38:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:38:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 22:38:58 --> Total execution time: 0.2402
DEBUG - 2020-03-25 17:39:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:39:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:39:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:39:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:39:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:39:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:39:01 --> Total execution time: 0.1954
DEBUG - 2020-03-25 17:39:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:39:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:39:01 --> Total execution time: 0.1314
DEBUG - 2020-03-25 17:39:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:39:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:39:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:39:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:39:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 22:39:05 --> Severity: Notice --> Undefined property: stdClass::$catgeory_id D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 595
DEBUG - 2020-03-25 17:40:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:40:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:40:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:40:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:40:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:40:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:40:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:40:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:40:03 --> Total execution time: 0.2023
DEBUG - 2020-03-25 17:40:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:40:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:40:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:40:04 --> Total execution time: 0.1528
DEBUG - 2020-03-25 17:40:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:40:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:40:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:40:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:40:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:40:05 --> Total execution time: 0.3268
DEBUG - 2020-03-25 17:40:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:40:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:40:05 --> Total execution time: 0.1593
DEBUG - 2020-03-25 17:40:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:40:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:40:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:40:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:40:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:40:08 --> Total execution time: 0.2970
DEBUG - 2020-03-25 17:40:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:40:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:40:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:40:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:40:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:40:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:40:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:40:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:40:25 --> Total execution time: 0.2042
DEBUG - 2020-03-25 17:40:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:40:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:40:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:40:26 --> Total execution time: 0.1663
DEBUG - 2020-03-25 17:40:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:40:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:40:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:40:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:41:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:41:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:41:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:41:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:41:20 --> Total execution time: 0.2098
DEBUG - 2020-03-25 17:41:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:41:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:41:20 --> Total execution time: 0.1666
DEBUG - 2020-03-25 17:41:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:41:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 22:41:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 22:41:24 --> Total execution time: 0.2900
DEBUG - 2020-03-25 17:41:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:41:27 --> Total execution time: 0.2075
DEBUG - 2020-03-25 17:41:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:41:27 --> Total execution time: 0.1360
DEBUG - 2020-03-25 17:41:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:41:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 17:41:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-03-25 22:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:41:31 --> Total execution time: 0.2279
DEBUG - 2020-03-25 17:41:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:41:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:41:31 --> Total execution time: 0.1808
DEBUG - 2020-03-25 17:41:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-03-25 17:41:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:41:36 --> Total execution time: 0.2880
DEBUG - 2020-03-25 17:41:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:41:36 --> Total execution time: 0.1572
DEBUG - 2020-03-25 17:41:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:41:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:41:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-03-25 17:41:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-03-25 17:41:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:41:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:41:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:41:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:41:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:41:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:41:45 --> Total execution time: 0.2393
DEBUG - 2020-03-25 17:41:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:41:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:41:45 --> Total execution time: 0.1672
DEBUG - 2020-03-25 17:41:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:41:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:41:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:41:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:42:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:42:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-03-25 22:42:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 416
ERROR - 2020-03-25 22:42:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 224
DEBUG - 2020-03-25 17:42:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:42:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:42:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:42:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:42:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:42:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:42:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:42:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:42:02 --> Total execution time: 0.2263
DEBUG - 2020-03-25 17:42:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:42:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:42:02 --> Total execution time: 0.1439
DEBUG - 2020-03-25 17:42:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:42:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:42:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:42:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:42:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:42:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:42:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:42:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:42:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:42:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:42:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:42:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:42:07 --> Total execution time: 0.2271
DEBUG - 2020-03-25 17:42:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:42:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:42:07 --> Total execution time: 0.1625
DEBUG - 2020-03-25 17:42:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:42:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:42:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:42:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:42:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:42:51 --> Total execution time: 0.2619
DEBUG - 2020-03-25 17:42:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:42:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:42:52 --> Total execution time: 0.1864
DEBUG - 2020-03-25 17:42:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:42:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:42:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:42:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:42:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:43:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:43:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:43:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:43:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:43:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:43:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:43:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:43:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:43:04 --> Total execution time: 0.2466
DEBUG - 2020-03-25 17:43:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:43:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:43:04 --> Total execution time: 0.1748
DEBUG - 2020-03-25 17:43:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:43:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:43:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:43:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:43:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:43:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:43:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:43:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:43:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:43:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:43:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:43:32 --> Total execution time: 0.2429
DEBUG - 2020-03-25 17:43:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:43:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:43:32 --> Total execution time: 0.1773
DEBUG - 2020-03-25 17:43:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:43:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:43:33 --> Total execution time: 0.1353
DEBUG - 2020-03-25 17:43:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:43:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:43:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:43:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:43:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:43:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:43:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:43:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:43:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:43:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:43:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:43:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:43:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:43:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:43:42 --> Total execution time: 0.4270
DEBUG - 2020-03-25 17:43:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:43:43 --> Total execution time: 0.1792
DEBUG - 2020-03-25 17:43:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:43:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:43:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:43:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:43:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:43:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:43:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:43:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:43:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:43:54 --> Total execution time: 0.2184
DEBUG - 2020-03-25 17:43:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:43:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:43:54 --> Total execution time: 0.1605
DEBUG - 2020-03-25 17:43:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:43:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:43:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:43:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:43:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:44:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:44:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:44:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:44:26 --> Total execution time: 0.2597
DEBUG - 2020-03-25 17:44:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:44:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:44:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:44:27 --> Total execution time: 0.1553
DEBUG - 2020-03-25 17:44:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:44:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:44:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:44:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:46:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:46:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:46:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:46:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:46:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-25 22:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-25 22:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-25 22:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-25 22:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-25 22:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-25 22:46:33 --> Total execution time: 0.2256
DEBUG - 2020-03-25 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:46:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-25 17:46:33 --> Total execution time: 0.1556
DEBUG - 2020-03-25 17:46:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:46:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 17:46:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 17:46:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:46:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-25 22:46:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-25 17:53:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 22:53:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:53:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 22:53:33 --> Total execution time: 0.2017
DEBUG - 2020-03-25 17:55:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 22:55:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:55:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 22:55:44 --> Total execution time: 0.1355
DEBUG - 2020-03-25 17:55:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 22:55:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:55:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 22:55:48 --> Total execution time: 0.1382
DEBUG - 2020-03-25 17:56:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-25 17:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-25 22:56:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-25 22:56:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-25 22:56:00 --> Total execution time: 0.1411
