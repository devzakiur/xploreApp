<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-04-11 12:52:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 12:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 16:52:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 16:52:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 16:52:56 --> Total execution time: 0.4422
DEBUG - 2020-04-11 12:53:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 12:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 16:53:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 16:53:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 16:53:15 --> Total execution time: 0.0799
DEBUG - 2020-04-11 12:54:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 12:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 12:54:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 12:54:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 16:54:32 --> Total execution time: 0.3773
DEBUG - 2020-04-11 12:54:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 12:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 16:54:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 16:54:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 16:54:42 --> Total execution time: 0.2793
DEBUG - 2020-04-11 12:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 12:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 16:55:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 16:55:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 12:55:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 12:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 16:55:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 16:55:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 12:55:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 12:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 16:55:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 16:55:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-04-11 16:55:47 --> Severity: error --> Exception: syntax error, unexpected ')' D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 85
DEBUG - 2020-04-11 12:56:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 12:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 16:56:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 16:56:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 12:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 12:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 16:56:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 16:56:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 16:56:26 --> Total execution time: 0.0860
DEBUG - 2020-04-11 14:25:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 14:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 18:25:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 18:25:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 18:25:39 --> Total execution time: 0.7290
DEBUG - 2020-04-11 14:25:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 14:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 18:25:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 18:25:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 18:25:54 --> Total execution time: 0.0645
DEBUG - 2020-04-11 14:25:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 14:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 14:25:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 14:25:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 18:25:59 --> Total execution time: 0.3701
DEBUG - 2020-04-11 14:26:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 14:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 14:26:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 14:26:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 18:26:15 --> Total execution time: 0.1858
DEBUG - 2020-04-11 14:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 14:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 18:26:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 18:26:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 18:26:18 --> Total execution time: 0.0815
DEBUG - 2020-04-11 14:26:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 14:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 18:26:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 18:26:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 18:26:35 --> Total execution time: 0.0953
DEBUG - 2020-04-11 14:27:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 14:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 18:27:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 18:27:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 18:27:02 --> Total execution time: 0.1318
DEBUG - 2020-04-11 16:28:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 16:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 16:28:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 16:28:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-11 16:28:05 --> Total execution time: 0.3670
DEBUG - 2020-04-11 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 16:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 20:29:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 20:29:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 20:29:04 --> Total execution time: 0.1933
DEBUG - 2020-04-11 16:29:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-11 16:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-11 20:29:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-11 20:29:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-11 20:29:27 --> Total execution time: 0.0760
