<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-22 08:21:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 13:21:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:21:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-22 13:21:27 --> Total execution time: 0.8156
DEBUG - 2020-03-22 08:33:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:33:49 --> No URI present. Default controller set.
DEBUG - 2020-03-22 08:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:33:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:33:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-22 08:33:49 --> Total execution time: 0.1724
DEBUG - 2020-03-22 08:33:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:33:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:33:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:33:49 --> Total execution time: 0.0766
DEBUG - 2020-03-22 08:33:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:33:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:33:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:33:50 --> Total execution time: 0.0394
DEBUG - 2020-03-22 08:33:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:33:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:33:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:33:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:33:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-22 13:33:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-22 13:33:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:33:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:33:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:33:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:33:53 --> Total execution time: 0.1932
DEBUG - 2020-03-22 08:33:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:33:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:33:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:33:54 --> Total execution time: 0.0376
DEBUG - 2020-03-22 08:33:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:33:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:33:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:33:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:33:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:33:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:33:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:33:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:33:56 --> Total execution time: 0.2760
DEBUG - 2020-03-22 08:33:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:33:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:33:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:33:56 --> Total execution time: 0.0517
DEBUG - 2020-03-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:33:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:33:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:33:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:33:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:33:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:33:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:33:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-details.php
DEBUG - 2020-03-22 08:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:34:03 --> Total execution time: 0.1251
DEBUG - 2020-03-22 08:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:34:03 --> Total execution time: 0.0446
DEBUG - 2020-03-22 08:34:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:34:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:34:09 --> Total execution time: 0.0521
DEBUG - 2020-03-22 08:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:34:09 --> Total execution time: 0.0387
DEBUG - 2020-03-22 08:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-details.php
DEBUG - 2020-03-22 08:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:34:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:34:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:34:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:34:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:34:16 --> Total execution time: 0.0562
DEBUG - 2020-03-22 08:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:34:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:34:16 --> Total execution time: 0.0441
DEBUG - 2020-03-22 08:34:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:34:18 --> Total execution time: 0.0511
DEBUG - 2020-03-22 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:34:18 --> Total execution time: 0.0446
DEBUG - 2020-03-22 08:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:34:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:34:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:34:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:34:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:34:20 --> Total execution time: 0.0567
DEBUG - 2020-03-22 08:34:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:34:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:34:20 --> Total execution time: 0.0530
DEBUG - 2020-03-22 08:34:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:34:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:34:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:34:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:34:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:34:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:34:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:34:25 --> Total execution time: 0.0560
DEBUG - 2020-03-22 08:34:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:34:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:34:25 --> Total execution time: 0.0392
DEBUG - 2020-03-22 08:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:34:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:34:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:34:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:34:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:34:28 --> Total execution time: 0.0691
DEBUG - 2020-03-22 08:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:34:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:34:28 --> Total execution time: 0.0459
DEBUG - 2020-03-22 08:34:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:34:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:34:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:34:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:36:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:36:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:36:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:36:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:36:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:36:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:36:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:36:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:36:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:36:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:36:55 --> Total execution time: 0.0638
DEBUG - 2020-03-22 08:36:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:36:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:36:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:36:55 --> Total execution time: 0.0392
DEBUG - 2020-03-22 08:36:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:36:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:36:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:36:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:37:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-03-22 13:37:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:37:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:37:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:37:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:37:00 --> Total execution time: 0.0839
DEBUG - 2020-03-22 08:37:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:37:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:37:00 --> Total execution time: 0.0430
DEBUG - 2020-03-22 08:37:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-03-22 13:37:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:37:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:37:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:37:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:37:03 --> Total execution time: 0.0507
DEBUG - 2020-03-22 08:37:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:37:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:37:03 --> Total execution time: 0.0435
DEBUG - 2020-03-22 08:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:37:04 --> Total execution time: 0.0627
DEBUG - 2020-03-22 08:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:37:04 --> Total execution time: 0.0409
DEBUG - 2020-03-22 08:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:37:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:37:08 --> Total execution time: 0.0679
DEBUG - 2020-03-22 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:37:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:37:08 --> Total execution time: 0.0415
DEBUG - 2020-03-22 08:37:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:37:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:37:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:37:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:37:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:37:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:37:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:37:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:37:43 --> Total execution time: 0.1075
DEBUG - 2020-03-22 08:37:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:37:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:37:43 --> Total execution time: 0.0418
DEBUG - 2020-03-22 08:37:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:37:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:37:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:37:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:37:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:37:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:37:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:37:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:37:46 --> Total execution time: 0.0553
DEBUG - 2020-03-22 08:37:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:37:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:37:46 --> Total execution time: 0.0421
DEBUG - 2020-03-22 08:37:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:37:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:37:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:37:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:37:53 --> Total execution time: 0.1368
DEBUG - 2020-03-22 08:37:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:37:53 --> Total execution time: 0.0401
DEBUG - 2020-03-22 08:37:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:37:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:37:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:37:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:37:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:37:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:37:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:37:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:37:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:37:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:37:59 --> Total execution time: 0.0821
DEBUG - 2020-03-22 08:37:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:37:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:37:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:37:59 --> Total execution time: 0.0401
DEBUG - 2020-03-22 08:38:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:38:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:38:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:38:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:38:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:38:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:38:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:38:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:38:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:38:08 --> Total execution time: 0.0995
DEBUG - 2020-03-22 08:38:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:38:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:38:08 --> Total execution time: 0.0392
DEBUG - 2020-03-22 08:38:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:38:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:38:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:38:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:38:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:38:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:38:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:38:18 --> Total execution time: 0.0514
DEBUG - 2020-03-22 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:38:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:38:18 --> Total execution time: 0.0388
DEBUG - 2020-03-22 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:38:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:38:23 --> Total execution time: 0.0573
DEBUG - 2020-03-22 08:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:38:23 --> Total execution time: 0.0402
DEBUG - 2020-03-22 08:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:38:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:38:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:38:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:38:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:38:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:38:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:38:24 --> Total execution time: 0.0632
DEBUG - 2020-03-22 08:38:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:38:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:38:24 --> Total execution time: 0.0429
DEBUG - 2020-03-22 08:38:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:38:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:38:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:38:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:40:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:40:05 --> Total execution time: 0.1142
DEBUG - 2020-03-22 08:40:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:40:05 --> Total execution time: 0.0481
DEBUG - 2020-03-22 08:40:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:40:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:40:06 --> Total execution time: 0.0622
DEBUG - 2020-03-22 08:40:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:40:07 --> Total execution time: 0.0406
DEBUG - 2020-03-22 08:40:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:40:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:40:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:40:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:40:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:40:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:40:09 --> Total execution time: 0.0782
DEBUG - 2020-03-22 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:40:09 --> Total execution time: 0.0400
DEBUG - 2020-03-22 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:40:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:40:11 --> Total execution time: 0.0606
DEBUG - 2020-03-22 08:40:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:40:11 --> Total execution time: 0.0439
DEBUG - 2020-03-22 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:40:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:40:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:40:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:40:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:40:14 --> Total execution time: 0.0619
DEBUG - 2020-03-22 08:40:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:40:14 --> Total execution time: 0.0452
DEBUG - 2020-03-22 08:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:40:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:40:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:40:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:40:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:40:17 --> Total execution time: 0.0558
DEBUG - 2020-03-22 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:40:17 --> Total execution time: 0.0655
DEBUG - 2020-03-22 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:40:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:40:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:40:20 --> Total execution time: 0.0611
DEBUG - 2020-03-22 08:40:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:40:20 --> Total execution time: 0.0381
DEBUG - 2020-03-22 08:40:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:40:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:40:22 --> Total execution time: 0.0576
DEBUG - 2020-03-22 08:40:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:40:22 --> Total execution time: 0.0415
DEBUG - 2020-03-22 08:40:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:40:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:40:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:40:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:40:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:40:32 --> Total execution time: 0.0659
DEBUG - 2020-03-22 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:40:32 --> Total execution time: 0.0404
DEBUG - 2020-03-22 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:40:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:40:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:40:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:40:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:40:35 --> Total execution time: 0.0671
DEBUG - 2020-03-22 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:40:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:40:35 --> Total execution time: 0.0445
DEBUG - 2020-03-22 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:40:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:40:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:40:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:41:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:41:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:41:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:41:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:41:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:41:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:41:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:41:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:41:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:41:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:41:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:41:50 --> Total execution time: 0.0913
DEBUG - 2020-03-22 08:41:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:41:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:41:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:41:50 --> Total execution time: 0.0415
DEBUG - 2020-03-22 08:41:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:41:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:41:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:41:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:41:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:41:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:41:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:41:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:41:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:41:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:41:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:41:52 --> Total execution time: 0.0726
DEBUG - 2020-03-22 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:41:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:41:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:41:52 --> Total execution time: 0.0383
DEBUG - 2020-03-22 08:41:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:41:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:41:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:41:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:41:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:41:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:41:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:42:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:42:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:42:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:42:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:42:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:42:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:42:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:42:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:42:59 --> Total execution time: 0.0877
DEBUG - 2020-03-22 08:42:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:42:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:42:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:42:59 --> Total execution time: 0.0441
DEBUG - 2020-03-22 08:43:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:43:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:43:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:43:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:43:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:43:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:43:06 --> Total execution time: 0.0529
DEBUG - 2020-03-22 08:43:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:43:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:43:06 --> Total execution time: 0.0399
DEBUG - 2020-03-22 08:43:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:43:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:43:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:09 --> Total execution time: 0.0484
DEBUG - 2020-03-22 08:43:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:11 --> Total execution time: 0.0491
DEBUG - 2020-03-22 08:43:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/topic-relation.php
DEBUG - 2020-03-22 08:43:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:43:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:43:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-history-details.php
DEBUG - 2020-03-22 08:43:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:43:35 --> Total execution time: 0.0559
DEBUG - 2020-03-22 08:43:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:43:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:43:35 --> Total execution time: 0.0432
DEBUG - 2020-03-22 08:43:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:43:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:43:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:43:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:43:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:43:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:43:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:43:38 --> Total execution time: 0.0777
DEBUG - 2020-03-22 08:43:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:43:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:43:39 --> Total execution time: 0.0389
DEBUG - 2020-03-22 08:43:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:43:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:43:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:43:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:43:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:43:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:43:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:43:40 --> Total execution time: 0.0556
DEBUG - 2020-03-22 08:43:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:43:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:43:40 --> Total execution time: 0.0428
DEBUG - 2020-03-22 08:43:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:43:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:43:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:43:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:43:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:43:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:43:50 --> Total execution time: 0.0651
DEBUG - 2020-03-22 08:43:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:43:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:43:50 --> Total execution time: 0.0432
DEBUG - 2020-03-22 08:43:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:43:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:43:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:43:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:43:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:43:55 --> Total execution time: 0.0522
DEBUG - 2020-03-22 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:43:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:43:55 --> Total execution time: 0.0416
DEBUG - 2020-03-22 08:43:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:43:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:43:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:43:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:43:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:43:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:43:58 --> Total execution time: 0.0560
DEBUG - 2020-03-22 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:43:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:43:58 --> Total execution time: 0.0424
DEBUG - 2020-03-22 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:43:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:43:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:43:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:44:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:44:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:44:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 08:50:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:50:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:50:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:50:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:50:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:50:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:50:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:50:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:50:12 --> Total execution time: 0.1591
DEBUG - 2020-03-22 08:50:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:50:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:50:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:50:12 --> Total execution time: 0.0396
DEBUG - 2020-03-22 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:50:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:50:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:50:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:50:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:50:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:50:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:50:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:50:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:50:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:50:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:50:13 --> Total execution time: 0.0528
DEBUG - 2020-03-22 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:50:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:50:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:50:13 --> Total execution time: 0.0382
DEBUG - 2020-03-22 08:50:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:50:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:50:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:50:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:51:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:51:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:51:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:51:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:51:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:51:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:51:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:51:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:51:18 --> Total execution time: 0.0530
DEBUG - 2020-03-22 08:51:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:51:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:51:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:51:18 --> Total execution time: 0.0422
DEBUG - 2020-03-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:51:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:51:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:51:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:51:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:51:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:51:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:51:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:51:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:51:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:51:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:51:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:51:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:51:20 --> Total execution time: 0.0696
DEBUG - 2020-03-22 08:51:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:51:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:51:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:51:20 --> Total execution time: 0.0416
DEBUG - 2020-03-22 08:51:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:51:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:51:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:51:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:51:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:51:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:51:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:51:32 --> Total execution time: 0.0523
DEBUG - 2020-03-22 08:51:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:51:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:51:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:51:58 --> Total execution time: 0.0716
DEBUG - 2020-03-22 08:52:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:52:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:52:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:52:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:52:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:52:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:52:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:52:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:52:08 --> Total execution time: 0.1220
DEBUG - 2020-03-22 08:52:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:52:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:52:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:52:08 --> Total execution time: 0.0467
DEBUG - 2020-03-22 08:52:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:52:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:52:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:52:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:52:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:52:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:52:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:52:21 --> Total execution time: 0.0788
DEBUG - 2020-03-22 08:54:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:54:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:54:02 --> Total execution time: 0.0544
DEBUG - 2020-03-22 08:54:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:54:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:54:02 --> Total execution time: 0.0426
DEBUG - 2020-03-22 08:54:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:54:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:54:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:54:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:54:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:54:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:54:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:54:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:54:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:54:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:54:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:54:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:54:04 --> Total execution time: 0.0607
DEBUG - 2020-03-22 08:54:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:54:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:54:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:54:04 --> Total execution time: 0.0641
DEBUG - 2020-03-22 08:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:54:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:54:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:54:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:54:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:54:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:54:08 --> Total execution time: 0.0452
DEBUG - 2020-03-22 08:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:54:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:54:50 --> Total execution time: 0.0638
DEBUG - 2020-03-22 08:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:54:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:54:50 --> Total execution time: 0.0523
DEBUG - 2020-03-22 08:54:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:54:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:54:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:54:51 --> Total execution time: 0.0510
DEBUG - 2020-03-22 08:55:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:55:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:55:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:55:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:55:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:55:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:55:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:55:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:55:16 --> Total execution time: 0.1247
DEBUG - 2020-03-22 08:55:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:55:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:55:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:55:16 --> Total execution time: 0.0576
DEBUG - 2020-03-22 08:55:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:55:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:55:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:55:16 --> Total execution time: 0.0509
DEBUG - 2020-03-22 08:55:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:55:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:55:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:55:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:55:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:55:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:55:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:55:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:55:26 --> Total execution time: 0.0688
DEBUG - 2020-03-22 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:55:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:55:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:55:26 --> Total execution time: 0.0450
DEBUG - 2020-03-22 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:55:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:55:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:55:26 --> Total execution time: 0.0398
DEBUG - 2020-03-22 08:55:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:55:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:55:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:55:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:55:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:55:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:55:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:55:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:55:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:55:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:55:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:55:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:55:52 --> Total execution time: 0.0669
DEBUG - 2020-03-22 08:55:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:55:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:55:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:55:52 --> Total execution time: 0.0445
DEBUG - 2020-03-22 08:55:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:55:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:55:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:55:53 --> Total execution time: 0.0490
DEBUG - 2020-03-22 08:55:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:55:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:55:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:55:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:56:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:56:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:56:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:56:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:56:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:56:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:56:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:56:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:56:59 --> Total execution time: 0.0539
DEBUG - 2020-03-22 08:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:57:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:57:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:57:00 --> Total execution time: 0.0472
DEBUG - 2020-03-22 08:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:57:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:57:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:57:00 --> Total execution time: 0.0440
DEBUG - 2020-03-22 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:57:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:57:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:57:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:57:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:57:24 --> Total execution time: 0.0569
DEBUG - 2020-03-22 08:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:57:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:57:24 --> Total execution time: 0.0445
DEBUG - 2020-03-22 08:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:57:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:57:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:57:25 --> Total execution time: 0.0371
DEBUG - 2020-03-22 08:57:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:57:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:57:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:57:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:58:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:58:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:58:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:58:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:58:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:58:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:58:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:58:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:58:31 --> Total execution time: 0.0616
DEBUG - 2020-03-22 08:58:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:58:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:58:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:58:31 --> Total execution time: 0.0456
DEBUG - 2020-03-22 08:58:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:58:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:58:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:58:32 --> Total execution time: 0.0441
DEBUG - 2020-03-22 08:58:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:58:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:58:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:58:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:59:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:59:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:59:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:59:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:59:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:59:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:59:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:59:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:59:41 --> Total execution time: 0.0552
DEBUG - 2020-03-22 08:59:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:59:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:59:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:59:41 --> Total execution time: 0.0446
DEBUG - 2020-03-22 08:59:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:59:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:59:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:59:42 --> Total execution time: 0.0405
DEBUG - 2020-03-22 08:59:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:59:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:59:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:59:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 08:59:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:59:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:59:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:59:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 13:59:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 13:59:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 13:59:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 13:59:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 13:59:53 --> Total execution time: 0.0682
DEBUG - 2020-03-22 08:59:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:59:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:59:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:59:54 --> Total execution time: 0.0425
DEBUG - 2020-03-22 08:59:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:59:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 08:59:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 08:59:54 --> Total execution time: 0.0390
DEBUG - 2020-03-22 08:59:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 08:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 08:59:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 13:59:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 13:59:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:00:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:00:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:00:14 --> Total execution time: 0.0613
DEBUG - 2020-03-22 09:00:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:00:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:00:14 --> Total execution time: 0.0491
DEBUG - 2020-03-22 09:00:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:00:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:00:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:00:15 --> Total execution time: 0.0543
DEBUG - 2020-03-22 09:00:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:00:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:00:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:00:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:01:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:01:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:01:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:01:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:01:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:01:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:01:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:01:32 --> Total execution time: 0.1137
DEBUG - 2020-03-22 09:01:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:01:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:01:32 --> Total execution time: 0.0727
DEBUG - 2020-03-22 09:01:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:01:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:01:33 --> Total execution time: 0.0432
DEBUG - 2020-03-22 09:01:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:01:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:01:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:01:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:01:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:01:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:01:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:01:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:01:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:01:48 --> Total execution time: 0.1071
DEBUG - 2020-03-22 09:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:01:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:01:48 --> Total execution time: 0.0616
DEBUG - 2020-03-22 09:01:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:01:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:01:49 --> Total execution time: 0.0849
DEBUG - 2020-03-22 09:01:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:01:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:01:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:01:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:01:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:01:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:01:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:01:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:01:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:01:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:01:52 --> Total execution time: 0.0546
DEBUG - 2020-03-22 09:01:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:01:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:01:52 --> Total execution time: 0.0486
DEBUG - 2020-03-22 09:01:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:01:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:01:53 --> Total execution time: 0.0495
DEBUG - 2020-03-22 09:01:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:01:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:01:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:01:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:02:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:02:28 --> Total execution time: 0.0570
DEBUG - 2020-03-22 09:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:02:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:02:28 --> Total execution time: 0.0553
DEBUG - 2020-03-22 09:02:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:02:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:02:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:02:29 --> Total execution time: 0.0395
DEBUG - 2020-03-22 09:02:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:02:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:02:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:02:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:03:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:03:42 --> Total execution time: 0.0625
DEBUG - 2020-03-22 09:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:03:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:03:42 --> Total execution time: 0.0416
DEBUG - 2020-03-22 09:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:03:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:03:42 --> Total execution time: 0.0408
DEBUG - 2020-03-22 09:03:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:03:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:03:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:03:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:03:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:03:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:03:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:03:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:03:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:03:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:03:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:03:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:03:50 --> Total execution time: 0.0588
DEBUG - 2020-03-22 09:03:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:03:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:03:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:03:50 --> Total execution time: 0.0466
DEBUG - 2020-03-22 09:03:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:03:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:03:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:03:51 --> Total execution time: 0.0401
DEBUG - 2020-03-22 09:03:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:03:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:03:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:03:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:08:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:08:14 --> Total execution time: 0.1109
DEBUG - 2020-03-22 09:08:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:08:14 --> Total execution time: 0.0615
DEBUG - 2020-03-22 09:08:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:08:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:08:15 --> Total execution time: 0.0532
DEBUG - 2020-03-22 09:08:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:08:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:08:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:08:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:08:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:08:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:08:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:08:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:08:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:08:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:08:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:08:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:08:22 --> Total execution time: 0.0755
DEBUG - 2020-03-22 09:08:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:08:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:08:23 --> Total execution time: 0.0450
DEBUG - 2020-03-22 09:08:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:08:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:08:23 --> Total execution time: 0.0392
DEBUG - 2020-03-22 09:08:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:08:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:08:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:08:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:08:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:08:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:08:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:08:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:08:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:08:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:08:27 --> Total execution time: 0.0548
DEBUG - 2020-03-22 09:08:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:08:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:08:27 --> Total execution time: 0.0461
DEBUG - 2020-03-22 09:08:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:08:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:08:28 --> Total execution time: 0.0385
DEBUG - 2020-03-22 09:08:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:08:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:08:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:08:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:08:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:08:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:15:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:15:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:15:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:11 --> No URI present. Default controller set.
DEBUG - 2020-03-22 09:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-22 09:15:11 --> Total execution time: 0.0506
DEBUG - 2020-03-22 09:15:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:15:11 --> Total execution time: 0.0400
DEBUG - 2020-03-22 09:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:16 --> No URI present. Default controller set.
DEBUG - 2020-03-22 09:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-22 09:15:16 --> Total execution time: 0.0394
DEBUG - 2020-03-22 09:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:15:16 --> Total execution time: 0.0468
DEBUG - 2020-03-22 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:15:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-22 14:15:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-22 14:15:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:15:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:15:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:15:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:15:20 --> Total execution time: 0.0666
DEBUG - 2020-03-22 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:15:20 --> Total execution time: 0.0404
DEBUG - 2020-03-22 09:15:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:15:21 --> Total execution time: 0.0439
DEBUG - 2020-03-22 09:15:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:15:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:15:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:15:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:15:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:15:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:15:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:15:24 --> Total execution time: 0.0658
DEBUG - 2020-03-22 09:15:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:15:24 --> Total execution time: 0.0714
DEBUG - 2020-03-22 09:15:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:15:25 --> Total execution time: 0.0548
DEBUG - 2020-03-22 09:15:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:15:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:15:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:15:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:15:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:15:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:15:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:15:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:15:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:15:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:15:27 --> Total execution time: 0.0570
DEBUG - 2020-03-22 09:15:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:15:27 --> Total execution time: 0.0438
DEBUG - 2020-03-22 09:15:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:15:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:15:27 --> Total execution time: 0.0420
DEBUG - 2020-03-22 09:15:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:15:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:15:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:15:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:15:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:15:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:24:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:24:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:24:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:24:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:24:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:24:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:24:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:24:43 --> Total execution time: 0.1062
DEBUG - 2020-03-22 09:24:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:24:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:24:43 --> Total execution time: 0.0515
DEBUG - 2020-03-22 09:24:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:24:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:24:43 --> Total execution time: 0.0400
DEBUG - 2020-03-22 09:24:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:24:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:24:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:24:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:24:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:24:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:24:49 --> Total execution time: 0.0536
DEBUG - 2020-03-22 09:24:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:24:49 --> Total execution time: 0.0389
DEBUG - 2020-03-22 09:24:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:24:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:24:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:24:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:24:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:24:52 --> Total execution time: 0.0545
DEBUG - 2020-03-22 09:24:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:24:52 --> Total execution time: 0.0424
DEBUG - 2020-03-22 09:24:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:24:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:24:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:24:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:24:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:24:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:25:00 --> Total execution time: 0.0533
DEBUG - 2020-03-22 09:25:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:25:00 --> Total execution time: 0.0391
DEBUG - 2020-03-22 09:25:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:25:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:25:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:25:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:25:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:25:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:25:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:25:02 --> Total execution time: 0.0573
DEBUG - 2020-03-22 09:25:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:25:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:25:02 --> Total execution time: 0.0395
DEBUG - 2020-03-22 09:25:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:25:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:25:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:25:16 --> Total execution time: 0.0553
DEBUG - 2020-03-22 09:25:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:25:16 --> Total execution time: 0.0424
DEBUG - 2020-03-22 09:25:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:25:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:25:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:25:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:25:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:25:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:25:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:25:18 --> Total execution time: 0.0697
DEBUG - 2020-03-22 09:25:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:25:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:25:18 --> Total execution time: 0.0433
DEBUG - 2020-03-22 09:25:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:25:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:25:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:25:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:25:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:25:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:25:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:25:23 --> Total execution time: 0.0516
DEBUG - 2020-03-22 09:25:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:25:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:25:23 --> Total execution time: 0.0396
DEBUG - 2020-03-22 09:25:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:25:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:25:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:25:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:25:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:25:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:25:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:25:25 --> Total execution time: 0.0645
DEBUG - 2020-03-22 09:25:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:25:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:25:25 --> Total execution time: 0.0458
DEBUG - 2020-03-22 09:25:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:25:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:25:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:25:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:26:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:26:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:26:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:26:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:26:04 --> Total execution time: 0.0728
DEBUG - 2020-03-22 09:26:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:26:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:26:04 --> Total execution time: 0.0438
DEBUG - 2020-03-22 09:26:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:26:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:26:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:26:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:26:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:26:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:26:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:26:06 --> Total execution time: 0.1551
DEBUG - 2020-03-22 09:26:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:26:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:26:06 --> Total execution time: 0.0405
DEBUG - 2020-03-22 09:26:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:26:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:26:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:26:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:26:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:26:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:26:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:26:12 --> Total execution time: 0.0796
DEBUG - 2020-03-22 09:26:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:26:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:26:12 --> Total execution time: 0.0402
DEBUG - 2020-03-22 09:26:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:26:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:26:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:26:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:26:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:26:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:26:14 --> Total execution time: 0.0671
DEBUG - 2020-03-22 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:26:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:26:14 --> Total execution time: 0.0427
DEBUG - 2020-03-22 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:26:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:26:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:26:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:26:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:26:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:26:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:26:22 --> Total execution time: 0.0931
DEBUG - 2020-03-22 09:26:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:26:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:26:22 --> Total execution time: 0.0399
DEBUG - 2020-03-22 09:26:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:26:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:26:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:26:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:26:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:26:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:26:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:26:24 --> Total execution time: 0.0621
DEBUG - 2020-03-22 09:26:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:26:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:26:24 --> Total execution time: 0.0463
DEBUG - 2020-03-22 09:26:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:26:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:26:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:26:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:27:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:27:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:27:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:27:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:27:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:27:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:27:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:27:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:27:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:27:26 --> Total execution time: 0.0521
DEBUG - 2020-03-22 09:27:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:27:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:27:26 --> Total execution time: 0.0392
DEBUG - 2020-03-22 09:27:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:27:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:27:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:27:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:27:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:27:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:27:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:27:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:27:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:27:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:27:30 --> Total execution time: 0.0562
DEBUG - 2020-03-22 09:27:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:27:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:27:30 --> Total execution time: 0.0438
DEBUG - 2020-03-22 09:27:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:27:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:27:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:27:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:27:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:27:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:27:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:27:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:27:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:27:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:27:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:27:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:27:31 --> Total execution time: 0.0510
DEBUG - 2020-03-22 09:27:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:27:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:27:32 --> Total execution time: 0.0391
DEBUG - 2020-03-22 09:27:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:27:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:27:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:27:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:27:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:27:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:27:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:27:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:27:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:27:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:27:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:27:33 --> Total execution time: 0.0559
DEBUG - 2020-03-22 09:27:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:27:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:27:34 --> Total execution time: 0.0382
DEBUG - 2020-03-22 09:27:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:27:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:27:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:27:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:31:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:31:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:31:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:31:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:31:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:31:40 --> Total execution time: 0.1630
DEBUG - 2020-03-22 09:31:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:31:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:31:40 --> Total execution time: 0.0430
DEBUG - 2020-03-22 09:31:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:31:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:31:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:31:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:31:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:31:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:31:42 --> Total execution time: 0.0539
DEBUG - 2020-03-22 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:31:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:31:42 --> Total execution time: 0.0494
DEBUG - 2020-03-22 09:31:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:31:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:31:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:31:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:31:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:31:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:31:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:31:45 --> Total execution time: 0.0623
DEBUG - 2020-03-22 09:31:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:31:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:31:45 --> Total execution time: 0.0411
DEBUG - 2020-03-22 09:31:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:31:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:31:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:31:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:31:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:31:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:31:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:31:46 --> Total execution time: 0.0670
DEBUG - 2020-03-22 09:31:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:31:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:31:46 --> Total execution time: 0.0431
DEBUG - 2020-03-22 09:31:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:31:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:31:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:31:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:31:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:31:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:31:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:31:50 --> Total execution time: 0.0612
DEBUG - 2020-03-22 09:31:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:31:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:31:50 --> Total execution time: 0.0419
DEBUG - 2020-03-22 09:31:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:31:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:31:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:31:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:31:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:31:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:31:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:31:52 --> Total execution time: 0.1342
DEBUG - 2020-03-22 09:31:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:31:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:31:52 --> Total execution time: 0.0402
DEBUG - 2020-03-22 09:31:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:31:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:31:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:31:59 --> Total execution time: 0.0669
DEBUG - 2020-03-22 09:31:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:31:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:31:59 --> Total execution time: 0.0434
DEBUG - 2020-03-22 09:32:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:32:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:32:01 --> Total execution time: 0.0565
DEBUG - 2020-03-22 09:32:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:32:01 --> Total execution time: 0.0455
DEBUG - 2020-03-22 09:32:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:32:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:32:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:32:07 --> Total execution time: 0.0615
DEBUG - 2020-03-22 09:32:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:32:07 --> Total execution time: 0.1124
DEBUG - 2020-03-22 09:32:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:32:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:32:10 --> Total execution time: 0.0557
DEBUG - 2020-03-22 09:32:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:32:10 --> Total execution time: 0.0427
DEBUG - 2020-03-22 09:32:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:32:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:32:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:32:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:32:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:32:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:32:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:32:12 --> Total execution time: 0.0718
DEBUG - 2020-03-22 09:32:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:32:12 --> Total execution time: 0.0381
DEBUG - 2020-03-22 09:32:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:32:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:32:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:32:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:32:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:32:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:32:14 --> Total execution time: 0.0574
DEBUG - 2020-03-22 09:32:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:32:15 --> Total execution time: 0.0401
DEBUG - 2020-03-22 09:32:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:32:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:32:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:32:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:32:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:32:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:32:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:32:20 --> Total execution time: 0.0494
DEBUG - 2020-03-22 09:32:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:32:21 --> Total execution time: 0.0416
DEBUG - 2020-03-22 09:32:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:32:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:32:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:32:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:32:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:32:22 --> Total execution time: 0.0641
DEBUG - 2020-03-22 09:32:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:32:22 --> Total execution time: 0.0401
DEBUG - 2020-03-22 09:32:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:32:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:32:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:32:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:32:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:32:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:32:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:32:40 --> Total execution time: 0.0707
DEBUG - 2020-03-22 09:32:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:32:40 --> Total execution time: 0.0415
DEBUG - 2020-03-22 09:32:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:32:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:32:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:32:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:32:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:32:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:32:42 --> Total execution time: 0.0561
DEBUG - 2020-03-22 09:32:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:32:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:32:42 --> Total execution time: 0.0402
DEBUG - 2020-03-22 09:32:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:32:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:32:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:32:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:33:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:33:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:33:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:33:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:33:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:33:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:33:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:33:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:33:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:33:00 --> Total execution time: 0.0722
DEBUG - 2020-03-22 09:33:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:33:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:33:01 --> Total execution time: 0.0390
DEBUG - 2020-03-22 09:33:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:33:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:33:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:33:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:33:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:33:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:33:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:33:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:33:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:33:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:33:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:33:03 --> Total execution time: 0.0651
DEBUG - 2020-03-22 09:33:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:33:03 --> Total execution time: 0.0434
DEBUG - 2020-03-22 09:33:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:33:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:33:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:33:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:33:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:33:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:33:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:33:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:33:52 --> Total execution time: 0.0804
DEBUG - 2020-03-22 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:33:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:33:52 --> Total execution time: 0.0425
DEBUG - 2020-03-22 09:33:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:33:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:33:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:33:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:33:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:33:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:33:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:33:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:33:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:33:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:33:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:33:57 --> Total execution time: 0.0566
DEBUG - 2020-03-22 09:33:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:33:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:33:57 --> Total execution time: 0.0427
DEBUG - 2020-03-22 09:33:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:33:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:33:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:33:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:34:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:34:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:34:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:34:03 --> Total execution time: 0.2249
DEBUG - 2020-03-22 09:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:34:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:34:03 --> Total execution time: 0.0458
DEBUG - 2020-03-22 09:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:34:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:34:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:44:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:44:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:44:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:44:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:44:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:44:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:44:18 --> Total execution time: 0.1523
DEBUG - 2020-03-22 09:44:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:44:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:44:19 --> Total execution time: 0.0385
DEBUG - 2020-03-22 09:44:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:44:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:44:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:44:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:44:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:44:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:44:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:44:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:44:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:44:21 --> Total execution time: 0.2252
DEBUG - 2020-03-22 09:44:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:44:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:44:21 --> Total execution time: 0.0411
DEBUG - 2020-03-22 09:44:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:44:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:44:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:44:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:44:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:44:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:44:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:44:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:44:24 --> Total execution time: 0.0485
DEBUG - 2020-03-22 09:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:44:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:44:24 --> Total execution time: 0.0391
DEBUG - 2020-03-22 09:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:44:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:44:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:44:26 --> Total execution time: 0.0566
DEBUG - 2020-03-22 09:44:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:44:26 --> Total execution time: 0.0391
DEBUG - 2020-03-22 09:44:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:44:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:44:34 --> Total execution time: 0.0720
DEBUG - 2020-03-22 09:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:44:34 --> Total execution time: 0.0391
DEBUG - 2020-03-22 09:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:44:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:45:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:45:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:45:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:45:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:45:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:45:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:45:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:45:09 --> Total execution time: 0.0581
DEBUG - 2020-03-22 09:45:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:45:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:45:09 --> Total execution time: 0.0424
DEBUG - 2020-03-22 09:45:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:45:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:45:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:45:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:45:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:45:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:45:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:45:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:45:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:45:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:45:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:45:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:45:11 --> Total execution time: 0.0523
DEBUG - 2020-03-22 09:45:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:45:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:45:11 --> Total execution time: 0.0390
DEBUG - 2020-03-22 09:45:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:45:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:45:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:45:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:45:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:45:13 --> Total execution time: 0.0629
DEBUG - 2020-03-22 09:45:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:45:13 --> Total execution time: 0.0417
DEBUG - 2020-03-22 09:45:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:45:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:45:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:45:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:45:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:46:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:46:00 --> Total execution time: 0.0543
DEBUG - 2020-03-22 09:46:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:46:00 --> Total execution time: 0.0420
DEBUG - 2020-03-22 09:46:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:46:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:46:04 --> Total execution time: 0.0682
DEBUG - 2020-03-22 09:46:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:46:04 --> Total execution time: 0.0403
DEBUG - 2020-03-22 09:46:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:46:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:46:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:46:08 --> Total execution time: 0.0768
DEBUG - 2020-03-22 09:46:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:46:08 --> Total execution time: 0.0392
DEBUG - 2020-03-22 09:46:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:46:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:46:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:46:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:46:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:46:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:46:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:46:10 --> Total execution time: 0.0672
DEBUG - 2020-03-22 09:46:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:46:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:46:10 --> Total execution time: 0.0485
DEBUG - 2020-03-22 09:46:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:46:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:46:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:46:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:46:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:46:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:46:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:46:26 --> Total execution time: 0.1120
DEBUG - 2020-03-22 09:46:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:46:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:46:26 --> Total execution time: 0.0428
DEBUG - 2020-03-22 09:46:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:46:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:46:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:46:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:46:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:46:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:46:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:46:50 --> Total execution time: 0.0574
DEBUG - 2020-03-22 09:46:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:46:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:46:51 --> Total execution time: 0.0487
DEBUG - 2020-03-22 09:46:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:46:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:46:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:46:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:46:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:46:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:46:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:46:55 --> Total execution time: 0.0734
DEBUG - 2020-03-22 09:46:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:46:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:46:56 --> Total execution time: 0.0392
DEBUG - 2020-03-22 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:46:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:46:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:46:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:47:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:47:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:47:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:47:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:47:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:47:07 --> Total execution time: 0.0554
DEBUG - 2020-03-22 09:47:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:47:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:47:07 --> Total execution time: 0.0434
DEBUG - 2020-03-22 09:47:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:47:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:47:07 --> Total execution time: 0.0421
DEBUG - 2020-03-22 09:47:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:47:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:47:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:47:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:47:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:47:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:47:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:47:21 --> Total execution time: 0.0665
DEBUG - 2020-03-22 09:47:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:47:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:47:21 --> Total execution time: 0.0470
DEBUG - 2020-03-22 09:47:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:47:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:47:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:47:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:47:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:47:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:47:25 --> Total execution time: 0.1067
DEBUG - 2020-03-22 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:47:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:47:25 --> Total execution time: 0.0417
DEBUG - 2020-03-22 09:47:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:47:28 --> Total execution time: 0.0538
DEBUG - 2020-03-22 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:47:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:47:28 --> Total execution time: 0.0379
DEBUG - 2020-03-22 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:47:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:47:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:47:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:47:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:47:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:47:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:47:32 --> Total execution time: 0.0578
DEBUG - 2020-03-22 09:47:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:47:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:47:32 --> Total execution time: 0.0427
DEBUG - 2020-03-22 09:47:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:47:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 09:47:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:47:45 --> Total execution time: 0.0841
DEBUG - 2020-03-22 09:47:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:47:45 --> Total execution time: 0.0426
DEBUG - 2020-03-22 09:47:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:47:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 09:47:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 14:47:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 14:47:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 14:47:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 14:47:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 14:47:46 --> Total execution time: 0.0673
DEBUG - 2020-03-22 09:47:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 09:47:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 09:47:47 --> Total execution time: 0.0486
DEBUG - 2020-03-22 09:47:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 09:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 09:47:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 14:47:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 14:47:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 10:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:10:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 15:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:10:36 --> Total execution time: 0.1350
DEBUG - 2020-03-22 10:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:10:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:10:36 --> Total execution time: 0.0444
DEBUG - 2020-03-22 10:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:10:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:10:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:10:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:10:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:30:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 15:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:30:32 --> Total execution time: 0.1277
DEBUG - 2020-03-22 10:30:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:30:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:30:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:30:33 --> Total execution time: 0.0419
DEBUG - 2020-03-22 10:30:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:30:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:30:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:30:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:30:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:30:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 10:30:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:30:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:30:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-03-22 15:30:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:30:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:30:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:30:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:30:34 --> Total execution time: 0.0771
DEBUG - 2020-03-22 10:30:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:30:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:30:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:30:34 --> Total execution time: 0.0430
DEBUG - 2020-03-22 10:30:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:30:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:30:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:30:36 --> Total execution time: 0.0395
DEBUG - 2020-03-22 10:30:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:30:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:30:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:30:36 --> Total execution time: 0.0391
DEBUG - 2020-03-22 10:30:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:30:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:30:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:30:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:30:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:30:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:30:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:30:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:30:52 --> Total execution time: 0.0558
DEBUG - 2020-03-22 10:30:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:30:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:30:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:30:53 --> Total execution time: 0.0463
DEBUG - 2020-03-22 10:30:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:30:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:30:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
ERROR - 2020-03-22 15:30:53 --> Severity: Notice --> Undefined property: UsersController::$Users_Model D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
ERROR - 2020-03-22 15:30:53 --> Severity: error --> Exception: Call to a member function get_all_users() on null D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
DEBUG - 2020-03-22 10:31:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:31:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:31:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:31:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:31:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:31:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:31:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:31:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:31:00 --> Total execution time: 0.0600
DEBUG - 2020-03-22 10:31:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:31:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:31:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:31:00 --> Total execution time: 0.0425
DEBUG - 2020-03-22 10:31:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:31:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:31:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
ERROR - 2020-03-22 15:31:01 --> Severity: Notice --> Undefined property: UsersController::$Users_Model D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
ERROR - 2020-03-22 15:31:01 --> Severity: error --> Exception: Call to a member function get_all_users() on null D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
DEBUG - 2020-03-22 10:31:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:31:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:31:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:31:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:31:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:31:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:31:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:31:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:31:02 --> Total execution time: 0.0607
DEBUG - 2020-03-22 10:31:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:31:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:31:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:31:02 --> Total execution time: 0.0394
DEBUG - 2020-03-22 10:31:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:31:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:31:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
ERROR - 2020-03-22 15:31:02 --> Severity: Notice --> Undefined property: UsersController::$Users_Model D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
ERROR - 2020-03-22 15:31:02 --> Severity: error --> Exception: Call to a member function get_all_users() on null D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
DEBUG - 2020-03-22 10:31:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:31:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:31:03 --> Total execution time: 0.0638
DEBUG - 2020-03-22 10:31:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:31:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:31:03 --> Total execution time: 0.0748
DEBUG - 2020-03-22 10:31:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:31:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
ERROR - 2020-03-22 15:31:03 --> Severity: Notice --> Undefined property: UsersController::$Users_Model D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
ERROR - 2020-03-22 15:31:03 --> Severity: error --> Exception: Call to a member function get_all_users() on null D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
DEBUG - 2020-03-22 10:31:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:31:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:31:59 --> Total execution time: 0.0490
DEBUG - 2020-03-22 10:31:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:31:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:31:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:31:59 --> Total execution time: 0.0408
DEBUG - 2020-03-22 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:32:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
ERROR - 2020-03-22 15:32:00 --> Severity: Notice --> Undefined property: UsersController::$Users_Model D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
ERROR - 2020-03-22 15:32:00 --> Severity: error --> Exception: Call to a member function get_all_users() on null D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
DEBUG - 2020-03-22 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:32:01 --> Total execution time: 0.0597
DEBUG - 2020-03-22 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:32:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:32:01 --> Total execution time: 0.0749
DEBUG - 2020-03-22 10:32:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:32:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
ERROR - 2020-03-22 15:32:02 --> Severity: Notice --> Undefined property: UsersController::$Users_Model D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
ERROR - 2020-03-22 15:32:02 --> Severity: error --> Exception: Call to a member function get_all_users() on null D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
DEBUG - 2020-03-22 10:32:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:32:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
ERROR - 2020-03-22 15:32:05 --> Severity: Notice --> Undefined property: UsersController::$Users_Model D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
ERROR - 2020-03-22 15:32:05 --> Severity: error --> Exception: Call to a member function get_all_users() on null D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
DEBUG - 2020-03-22 10:32:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:32:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:32:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:32:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:32:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:32:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:32:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:32:27 --> Total execution time: 0.0654
DEBUG - 2020-03-22 10:32:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:32:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:32:27 --> Total execution time: 0.0404
DEBUG - 2020-03-22 10:32:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:32:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
ERROR - 2020-03-22 15:32:27 --> Severity: Notice --> Undefined property: UsersController::$Users_Model D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
ERROR - 2020-03-22 15:32:27 --> Severity: error --> Exception: Call to a member function get_all_users() on null D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
DEBUG - 2020-03-22 10:32:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:32:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:32:30 --> Total execution time: 0.0494
DEBUG - 2020-03-22 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:32:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:32:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:32:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:32:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:32:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:32:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:32:46 --> Total execution time: 0.0544
DEBUG - 2020-03-22 10:32:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:32:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:32:46 --> Total execution time: 0.0889
DEBUG - 2020-03-22 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:32:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:32:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:32:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
ERROR - 2020-03-22 15:32:47 --> Severity: Notice --> Undefined property: UsersController::$Users_Model D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
ERROR - 2020-03-22 15:32:47 --> Severity: error --> Exception: Call to a member function get_all_users() on null D:\shipan7.2\htdocs\xplore\application\modules\users\controllers\UsersController.php 56
DEBUG - 2020-03-22 10:32:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:32:47 --> Total execution time: 0.1096
DEBUG - 2020-03-22 10:33:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:33:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:33:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:33:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:33:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:33:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:33:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:33:18 --> Total execution time: 0.0527
DEBUG - 2020-03-22 10:33:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:33:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:33:18 --> Total execution time: 0.0438
DEBUG - 2020-03-22 10:33:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:33:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:33:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:33:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:33:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:33:19 --> Total execution time: 0.1153
DEBUG - 2020-03-22 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:33:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:33:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:33:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:33:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:33:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:33:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:33:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:33:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:33:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:33:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:33:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 10:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:33:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:33:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 15:33:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:33:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:33:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:33:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:33:42 --> Total execution time: 0.0887
DEBUG - 2020-03-22 10:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:33:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:33:42 --> Total execution time: 0.0403
DEBUG - 2020-03-22 10:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:33:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:33:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:33:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:34:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 15:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:34:57 --> Total execution time: 0.0598
DEBUG - 2020-03-22 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:34:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:34:57 --> Total execution time: 0.0409
DEBUG - 2020-03-22 10:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:34:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:34:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:34:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:34:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 10:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:34:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:34:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:34:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:34:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:34:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:34:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:34:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:34:58 --> Total execution time: 0.0616
DEBUG - 2020-03-22 10:34:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:34:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:34:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:34:58 --> Total execution time: 0.0412
DEBUG - 2020-03-22 10:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:34:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:34:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:34:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:35:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:35:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:35:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 10:35:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:35:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:35:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:35:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:35:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:35:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:35:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:35:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:35:02 --> Total execution time: 0.0597
DEBUG - 2020-03-22 10:35:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:35:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:35:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:35:02 --> Total execution time: 0.0395
DEBUG - 2020-03-22 10:35:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:35:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:35:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:35:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:35:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:35:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:35:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:35:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:35:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:35:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:35:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:35:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:35:56 --> Total execution time: 0.1131
DEBUG - 2020-03-22 10:35:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:35:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:35:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:35:56 --> Total execution time: 0.0403
DEBUG - 2020-03-22 10:35:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:35:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:35:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:35:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 10:36:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:36:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:36:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:36:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:36:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:36:01 --> Total execution time: 0.0497
DEBUG - 2020-03-22 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:36:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:36:01 --> Total execution time: 0.0403
DEBUG - 2020-03-22 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:36:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:36:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:36:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:36:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:36:03 --> Total execution time: 0.0571
DEBUG - 2020-03-22 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:36:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:36:03 --> Total execution time: 0.0383
DEBUG - 2020-03-22 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:36:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:36:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:36:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:36:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:36:27 --> Total execution time: 0.0525
DEBUG - 2020-03-22 10:36:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:36:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:36:27 --> Total execution time: 0.0415
DEBUG - 2020-03-22 10:36:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 10:36:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:36:31 --> Total execution time: 0.0499
DEBUG - 2020-03-22 10:36:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:36:31 --> Total execution time: 0.0394
DEBUG - 2020-03-22 10:36:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:36:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:36:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:36:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:36:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:36:39 --> Total execution time: 0.0617
DEBUG - 2020-03-22 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:36:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:36:39 --> Total execution time: 0.0419
DEBUG - 2020-03-22 10:36:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:36:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:36:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:36:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:36:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:37:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:37:04 --> Total execution time: 0.0607
DEBUG - 2020-03-22 10:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:37:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:37:04 --> Total execution time: 0.0418
DEBUG - 2020-03-22 10:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:37:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:37:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:37:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:37:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:37:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:37:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:37:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:37:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:37:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:37:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:37:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:37:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:37:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:37:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:37:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:37:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:37:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:37:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:37:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:37:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:37:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:37:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:37:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:37:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:37:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:37:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:37:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:37:20 --> Total execution time: 0.0511
DEBUG - 2020-03-22 10:37:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:37:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:37:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:37:20 --> Total execution time: 0.0429
DEBUG - 2020-03-22 10:37:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:37:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:37:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:37:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:41:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:41:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:41:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:41:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:41:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:41:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:41:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:41:11 --> Total execution time: 0.0890
DEBUG - 2020-03-22 10:41:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:41:11 --> Total execution time: 0.0463
DEBUG - 2020-03-22 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:41:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:41:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:41:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:41:13 --> Total execution time: 0.0493
DEBUG - 2020-03-22 10:41:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:41:14 --> Total execution time: 0.0477
DEBUG - 2020-03-22 10:41:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:41:15 --> Total execution time: 0.0471
DEBUG - 2020-03-22 10:41:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:41:16 --> Total execution time: 0.0455
DEBUG - 2020-03-22 10:41:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:41:17 --> Total execution time: 0.0453
DEBUG - 2020-03-22 10:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:41:19 --> Total execution time: 0.0476
DEBUG - 2020-03-22 10:41:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:41:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:41:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-22 15:41:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:41:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:41:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:41:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:41:23 --> Total execution time: 0.1024
DEBUG - 2020-03-22 10:41:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:41:23 --> Total execution time: 0.0409
DEBUG - 2020-03-22 10:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:41:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:41:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 10:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:41:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:41:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 10:41:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:41:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 10:41:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:41:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:41:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 10:41:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:41:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-22 15:41:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-22 10:41:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:41:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:41:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:41:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:41:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:41:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:41:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:41:56 --> Total execution time: 0.0617
DEBUG - 2020-03-22 10:41:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:41:56 --> Total execution time: 0.0395
DEBUG - 2020-03-22 10:41:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:41:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:41:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:41:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:41:58 --> Total execution time: 0.0497
DEBUG - 2020-03-22 10:41:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:41:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:41:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:41:59 --> Total execution time: 0.0470
DEBUG - 2020-03-22 10:42:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:42:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:42:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:42:01 --> Total execution time: 0.0470
DEBUG - 2020-03-22 10:42:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:42:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:42:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:42:14 --> Total execution time: 0.0544
DEBUG - 2020-03-22 10:42:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:42:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:42:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:42:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:42:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:42:15 --> Total execution time: 0.0526
DEBUG - 2020-03-22 10:42:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:42:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:42:15 --> Total execution time: 0.0445
DEBUG - 2020-03-22 10:42:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:42:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:42:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:42:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:42:15 --> Total execution time: 0.0718
DEBUG - 2020-03-22 10:42:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:42:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:42:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:42:17 --> Total execution time: 0.0402
DEBUG - 2020-03-22 10:42:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:42:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:42:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:42:20 --> Total execution time: 0.0457
DEBUG - 2020-03-22 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:43:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:43:44 --> Total execution time: 0.0533
DEBUG - 2020-03-22 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:43:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:43:44 --> Total execution time: 0.0566
DEBUG - 2020-03-22 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:43:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:43:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:43:44 --> Total execution time: 0.0473
DEBUG - 2020-03-22 10:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:43:44 --> Total execution time: 0.0631
DEBUG - 2020-03-22 10:43:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:43:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:43:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:43:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:43:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:43:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:43:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:43:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:43:48 --> Total execution time: 0.0532
DEBUG - 2020-03-22 10:43:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:43:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:43:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:43:49 --> Total execution time: 0.0418
DEBUG - 2020-03-22 10:43:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:43:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:43:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:43:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:43:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:43:49 --> Total execution time: 0.0568
DEBUG - 2020-03-22 10:43:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:43:49 --> Total execution time: 0.0761
DEBUG - 2020-03-22 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:44:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:44:29 --> Total execution time: 0.0515
DEBUG - 2020-03-22 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:44:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:44:29 --> Total execution time: 0.0426
DEBUG - 2020-03-22 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:44:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:44:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:44:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:44:29 --> Total execution time: 0.0518
DEBUG - 2020-03-22 15:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:44:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:44:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:44:34 --> Total execution time: 0.0431
DEBUG - 2020-03-22 10:45:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:45:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:45:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:45:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:45:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:45:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:45:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:45:41 --> Total execution time: 0.0626
DEBUG - 2020-03-22 10:45:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:45:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:45:41 --> Total execution time: 0.0427
DEBUG - 2020-03-22 10:45:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:45:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:45:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:45:42 --> Total execution time: 0.0557
DEBUG - 2020-03-22 15:45:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:45:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:45:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:45:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:45:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-22 15:45:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-22 15:45:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-22 15:45:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-22 15:45:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-22 15:45:51 --> Total execution time: 0.0696
DEBUG - 2020-03-22 10:45:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:45:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:45:51 --> Total execution time: 0.0418
DEBUG - 2020-03-22 10:45:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 10:45:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-22 10:45:51 --> Total execution time: 0.0462
DEBUG - 2020-03-22 15:45:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:45:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:45:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:45:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:45:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:45:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:45:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:45:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:45:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:45:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:45:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:45:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:45:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:45:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:45:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:45:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:45:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:45:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:45:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:45:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:45:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:46:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:46:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:46:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:46:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:46:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:46:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:46:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-22 10:46:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-22 10:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-22 10:46:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-22 15:46:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-22 15:46:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
