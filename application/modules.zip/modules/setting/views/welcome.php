<div class="content">
    <?php $data['msg']="Welcome To Setting"; ?>
    <?php $this->load->view("message",$data) ?>
</div> <!-- content -->