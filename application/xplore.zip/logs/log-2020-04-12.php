<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-04-12 12:23:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:23:56 --> No URI present. Default controller set.
DEBUG - 2020-04-12 12:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:23:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:23:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-12 12:23:56 --> Total execution time: 0.5622
DEBUG - 2020-04-12 12:23:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:23:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:23:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:23:57 --> Total execution time: 0.1046
DEBUG - 2020-04-12 12:23:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:23:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:23:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:23:57 --> Total execution time: 0.0663
DEBUG - 2020-04-12 12:24:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:24:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:24:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:24:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:24:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-12 16:24:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-12 16:24:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-12 16:24:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-12 16:24:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-12 16:24:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-12 16:24:05 --> Total execution time: 0.2003
DEBUG - 2020-04-12 12:24:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:24:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:24:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:24:06 --> Total execution time: 0.0592
DEBUG - 2020-04-12 12:24:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:24:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:24:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/index.php
DEBUG - 2020-04-12 16:24:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-12 16:24:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-12 16:24:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-12 16:24:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-12 16:24:09 --> Total execution time: 0.0959
DEBUG - 2020-04-12 12:24:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:24:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:24:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:24:09 --> Total execution time: 0.1121
DEBUG - 2020-04-12 12:24:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:24:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:24:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:24:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:24:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-04-12 12:24:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:24:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:24:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-12 16:24:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-12 16:24:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-12 16:24:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-12 16:24:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-12 16:24:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-12 16:24:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-12 16:24:12 --> Total execution time: 0.2222
DEBUG - 2020-04-12 12:24:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:24:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:24:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:24:13 --> Total execution time: 0.0782
DEBUG - 2020-04-12 12:24:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:24:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:24:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:24:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:24:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-12 16:24:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-12 12:26:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:26:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:26:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-12 16:26:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-04-12 16:26:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-12 16:26:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-12 16:26:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-12 16:26:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-12 16:26:46 --> Total execution time: 0.1027
DEBUG - 2020-04-12 12:26:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:26:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:26:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:26:47 --> Total execution time: 0.0748
DEBUG - 2020-04-12 12:26:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:26:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:26:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:26:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:26:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
ERROR - 2020-04-12 16:26:48 --> Severity: Notice --> Undefined variable: category_id D:\shipan7.2\htdocs\xplore\application\modules\library\models\Library_Model.php 190
ERROR - 2020-04-12 16:26:48 --> Severity: Warning --> implode(): Invalid arguments passed D:\shipan7.2\htdocs\xplore\application\modules\library\models\Library_Model.php 190
ERROR - 2020-04-12 16:26:48 --> Severity: Notice --> Undefined variable: category_id D:\shipan7.2\htdocs\xplore\application\modules\library\models\Library_Model.php 190
ERROR - 2020-04-12 16:26:48 --> Severity: Warning --> implode(): Invalid arguments passed D:\shipan7.2\htdocs\xplore\application\modules\library\models\Library_Model.php 190
DEBUG - 2020-04-12 16:26:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-12 12:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:26:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:26:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:26:53 --> Total execution time: 0.1352
DEBUG - 2020-04-12 12:26:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:26:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:26:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-12 16:26:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-04-12 16:26:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-12 16:26:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-12 16:26:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-12 16:26:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-12 16:26:57 --> Total execution time: 0.0836
DEBUG - 2020-04-12 12:26:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:26:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:26:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:26:57 --> Total execution time: 0.1062
DEBUG - 2020-04-12 12:26:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:26:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:26:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:26:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:26:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:26:58 --> Total execution time: 0.0855
DEBUG - 2020-04-12 12:26:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:26:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:26:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
ERROR - 2020-04-12 16:26:59 --> Severity: Notice --> Undefined variable: category_id D:\shipan7.2\htdocs\xplore\application\modules\library\models\Library_Model.php 190
ERROR - 2020-04-12 16:26:59 --> Severity: Warning --> implode(): Invalid arguments passed D:\shipan7.2\htdocs\xplore\application\modules\library\models\Library_Model.php 190
ERROR - 2020-04-12 16:26:59 --> Severity: Notice --> Undefined variable: category_id D:\shipan7.2\htdocs\xplore\application\modules\library\models\Library_Model.php 190
ERROR - 2020-04-12 16:26:59 --> Severity: Warning --> implode(): Invalid arguments passed D:\shipan7.2\htdocs\xplore\application\modules\library\models\Library_Model.php 190
DEBUG - 2020-04-12 16:27:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-12 12:27:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:27:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:27:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-12 16:27:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-04-12 16:27:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-12 16:27:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-12 16:27:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-12 16:27:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-12 16:27:47 --> Total execution time: 0.0852
DEBUG - 2020-04-12 12:27:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:27:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:27:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:27:47 --> Total execution time: 0.0613
DEBUG - 2020-04-12 12:27:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:27:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:27:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:27:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:27:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:27:48 --> Total execution time: 0.0829
DEBUG - 2020-04-12 12:27:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:27:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:27:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-12 16:27:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-12 12:28:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:28:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:28:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-12 16:28:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-04-12 16:28:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-12 16:28:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-12 16:28:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-12 16:28:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-12 16:28:40 --> Total execution time: 0.1614
DEBUG - 2020-04-12 12:28:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:28:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:28:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:28:41 --> Total execution time: 0.0673
DEBUG - 2020-04-12 12:28:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:28:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:28:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:28:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 12:28:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-12 12:28:43 --> Total execution time: 0.0914
DEBUG - 2020-04-12 12:28:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-12 12:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-12 12:28:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-12 16:28:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-12 16:28:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
