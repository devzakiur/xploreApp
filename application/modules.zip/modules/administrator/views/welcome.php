<div class="content">
    <?php $data['msg']="Welcome To Admistrator"; ?>
    <?php $this->load->view("message",$data) ?>
</div> <!-- content -->