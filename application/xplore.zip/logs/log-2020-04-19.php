<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-04-19 07:31:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 07:31:27 --> No URI present. Default controller set.
DEBUG - 2020-04-19 07:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 07:31:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 07:31:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-19 07:31:28 --> Total execution time: 0.9346
DEBUG - 2020-04-19 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 07:31:28 --> No URI present. Default controller set.
DEBUG - 2020-04-19 07:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 07:31:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 07:31:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-19 07:31:28 --> Total execution time: 0.0760
DEBUG - 2020-04-19 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 07:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 07:31:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 07:31:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-19 07:31:28 --> Total execution time: 0.2312
DEBUG - 2020-04-19 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 07:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 07:31:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 07:31:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-19 07:31:28 --> Total execution time: 0.0765
DEBUG - 2020-04-19 07:31:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 07:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 07:31:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 07:31:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-19 07:31:29 --> Total execution time: 0.0739
DEBUG - 2020-04-19 07:31:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 07:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 07:31:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 07:31:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 07:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 07:31:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 11:31:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-19 11:31:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-19 11:31:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-19 11:31:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-19 11:31:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-19 11:31:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-19 11:31:34 --> Total execution time: 0.5043
DEBUG - 2020-04-19 07:31:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 07:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 07:31:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 07:31:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-19 07:31:35 --> Total execution time: 0.0541
DEBUG - 2020-04-19 09:35:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 09:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 09:35:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 09:35:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 09:35:04 --> No URI present. Default controller set.
DEBUG - 2020-04-19 09:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 09:35:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 09:35:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-19 09:35:04 --> Total execution time: 0.1734
DEBUG - 2020-04-19 09:35:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 09:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 09:35:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 09:35:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-19 09:35:05 --> Total execution time: 0.2000
DEBUG - 2020-04-19 10:25:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 10:25:40 --> No URI present. Default controller set.
DEBUG - 2020-04-19 10:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 10:25:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 10:25:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-19 10:25:41 --> Total execution time: 0.8168
DEBUG - 2020-04-19 10:25:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-19 10:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-19 10:25:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-19 10:25:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-19 10:25:41 --> Total execution time: 0.4782
