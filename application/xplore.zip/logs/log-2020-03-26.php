<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-26 07:06:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-26 07:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-26 07:06:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-26 07:06:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-26 07:06:17 --> Total execution time: 2.0854
DEBUG - 2020-03-26 07:06:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-26 07:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-26 12:06:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-26 12:06:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-26 12:06:41 --> Total execution time: 0.4226
DEBUG - 2020-03-26 07:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-26 07:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-26 12:07:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-26 12:07:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-26 12:07:22 --> Total execution time: 0.1151
DEBUG - 2020-03-26 13:33:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-26 13:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-26 18:33:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-26 18:33:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-26 18:33:52 --> Total execution time: 2.3627
DEBUG - 2020-03-26 13:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-26 13:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-26 18:34:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-26 18:34:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-26 18:34:01 --> Total execution time: 0.1286
DEBUG - 2020-03-26 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-26 13:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-26 18:34:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-26 18:34:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-26 18:34:05 --> Total execution time: 0.1542
