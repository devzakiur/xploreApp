#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `role_id` smallint(4) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `temp_password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `otp_code` tinyint(4) DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `ip` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `user_agent` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_key` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_role_id` (`role_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `admin` (`id`, `role_id`, `name`, `username`, `password`, `temp_password`, `otp_code`, `phone`, `status`, `ip`, `last_login`, `user_agent`, `reset_key`, `created_at`) VALUES (1, 1, '', 'superadmin', '$2y$10$EUWe3zy4/S7YJziZFjUhn.1mQjQrP6Ok9QlTZ/GiWE/5r5ohjR.vq', '', NULL, '', 1, '::1', '2020-02-04 08:18:47', 'Chrome 79.0.3945.130Windows 10', '', '2020-01-19 09:43:11');
INSERT INTO `admin` (`id`, `role_id`, `name`, `username`, `password`, `temp_password`, `otp_code`, `phone`, `status`, `ip`, `last_login`, `user_agent`, `reset_key`, `created_at`) VALUES (42, 2, 'Test', 'admin@gmail.com', '$2y$10$ugy0xuG/fNE0SYxFnWUPVe4jz8c/uzePjFxoO2PRO8lLKYlSV74/S', '', NULL, '(+88) 012-4512-4512', 1, '103.58.95.12', '2020-01-27 15:39:10', 'Opera 66.0.3515.44Windows 10', NULL, '2020-01-18 11:06:08');
INSERT INTO `admin` (`id`, `role_id`, `name`, `username`, `password`, `temp_password`, `otp_code`, `phone`, `status`, `ip`, `last_login`, `user_agent`, `reset_key`, `created_at`) VALUES (44, 4, 'jubair', 'superadmin@gmail.com', '$2y$10$NySu3vkq4Yp0LWcCmTUGZOkdztQhHyWYZ134lab.euOuqy2kKVhL.', '', NULL, '(+88) 019-1278-3472', 1, NULL, NULL, NULL, NULL, '2020-01-27 16:43:00');


#
# TABLE STRUCTURE FOR: batch
#

DROP TABLE IF EXISTS `batch`;

CREATE TABLE `batch` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `category_id` smallint(3) NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `updateby` smallint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4;

INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (16, 1, 'শ্রম মন্ত্রণালয়ের সহকারি সচিব', 1, 1, '2020-01-27 22:57:33');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (17, 1, 'পল্লী উন্নয়ন বোর্ডের মাঠ সংগঠক', 1, 1, '2020-01-27 23:04:08');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (18, 1, '১৮ তম বিসিএস', 1, 1, '2020-01-27 23:07:57');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (20, 1, 'সাব রেজিস্টার', 1, 1, '2020-01-27 22:56:34');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (21, 1, '২১ তম', 1, 1, '2020-01-27 22:59:56');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (22, 1, 'পানি উন্নয়ন বোর্ডের সহকারি পরিচালক', 1, 1, '2020-01-27 22:58:53');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (23, 1, '২৪ তম বিসিএস', 1, 1, '2020-01-27 23:08:37');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (24, 1, '২৫ তম', 1, 1, '2020-01-27 23:08:47');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (25, 1, 'ঢাকা বিশ্ববিদ্যালয় খ ইউনিট', 1, 1, '2020-01-27 23:06:53');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (26, 1, '২৬ তম বিসিএস', 1, 1, '2020-01-27 23:09:01');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (27, 1, '27', 1, 0, '2020-01-25 13:10:51');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (28, 1, '28', 1, 0, '2020-01-25 13:10:52');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (29, 1, '29', 1, 0, '2020-01-25 13:10:53');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (30, 1, '30', 1, 0, '2020-01-25 13:10:54');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (31, 1, '31', 1, 0, '2020-01-25 13:10:59');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (32, 1, '32', 1, 0, '2020-01-25 13:11:00');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (33, 1, '33', 1, 0, '2020-01-25 13:11:01');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (34, 1, '34', 1, 0, '2020-01-25 13:11:02');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (35, 1, '35', 1, 0, '2020-01-25 13:11:03');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (36, 1, '36', 1, 0, '2020-01-25 13:11:04');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (37, 1, '37', 1, 0, '2020-01-25 13:11:05');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (38, 1, '38', 1, 0, '2020-01-25 13:11:06');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (39, 1, '39', 1, 0, '2020-01-25 13:11:07');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (40, 1, '40', 1, 0, '2020-01-25 13:11:10');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (41, 1, '41', 1, 0, '2020-01-25 13:11:12');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (42, 1, '42', 1, 0, '2020-01-25 13:11:13');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (43, 1, '43', 1, 0, '2020-01-25 13:11:14');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (44, 1, '44', 1, 0, '2020-01-25 13:11:15');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (45, 1, '34 তম', 1, 0, '2020-01-27 18:05:49');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (46, 1, '৩৫ তম', 1, 0, '2020-01-27 18:06:12');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (47, 1, '৩৬ তম', 1, 0, '2020-01-27 18:06:20');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (48, 1, '৩৭ তম', 1, 0, '2020-01-27 18:07:15');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (49, 1, '৩৮ তম', 1, 0, '2020-01-27 18:07:26');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (50, 1, '৩৯ তম', 1, 0, '2020-01-27 18:07:32');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (51, 1, '৪০ তম', 1, 0, '2020-01-27 18:07:38');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (52, 1, '৩৩ তম', 1, 0, '2020-01-27 18:07:45');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (53, 1, 'ব্যাংক নিয়োগ পরীক্ষার প্রশ্ন', 1, 1, '2020-01-27 18:12:47');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (54, 1, 'বিশ্ববিদ্যালয় ভর্তি পরীক্ষার প্রশ্ন', 1, 1, '2020-01-27 18:11:06');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (55, 1, 'পিএসসি ও অন্যান্য পরীক্ষার প্রশ্ন', 1, 0, '2020-01-27 18:15:12');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `updateby`, `created_at`) VALUES (56, 1, '১০ তম', 1, 0, '2020-01-27 18:17:18');


#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `updateby` smallint(4) unsigned NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_category_updateby` (`updateby`) USING BTREE,
  KEY `idx_category_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `category` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (1, 'Bcs', 1, 0, '2020-01-21 11:53:27');
INSERT INTO `category` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (2, 'Bank', 1, 0, '2020-01-21 11:53:29');
INSERT INTO `category` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (3, 'General Knowledge', 1, 0, '2020-01-21 11:53:50');
INSERT INTO `category` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (4, 'Govt Job', 1, 0, '2020-01-27 18:04:57');
INSERT INTO `category` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (5, 'বিশ্ববিদ্যালয় ভর্তি পরীক্ষা', 1, 0, '2020-01-27 18:34:22');
INSERT INTO `category` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (6, 'এস এস সি', 1, 0, '2020-01-27 22:50:56');
INSERT INTO `category` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (7, 'এইচ এস সি', 1, 0, '2020-01-27 22:52:01');
INSERT INTO `category` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (8, 'অষ্টম শ্রেণী', 1, 0, '2020-01-27 22:52:38');
INSERT INTO `category` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (9, 'Mathematics', 1, 0, '2020-01-27 23:29:22');


#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c0ri8hlt32nncahosoug3u3jd80rd6u5', '::1', 1580713708, '__ci_last_regenerate|i:1580713708;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f7p54vqghn9le8so837r342an5nqtfuh', '::1', 1580714099, '__ci_last_regenerate|i:1580714099;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ne0bo9sao11gi48mngi8pfvfpq6r9rud', '::1', 1580714531, '__ci_last_regenerate|i:1580714531;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rc7m3r2lssp7fbtpbm92sj3m9pcgdvh2', '::1', 1580716163, '__ci_last_regenerate|i:1580716163;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bc5f6idfmrfb8cnf6e4l0e0pkbd7c0bm', '::1', 1580716807, '__ci_last_regenerate|i:1580716807;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4dl7a4cqmioj8h2uu60ajms4h9t4994k', '::1', 1580717471, '__ci_last_regenerate|i:1580717471;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('17m5ame0dtgppdoups0r2382ffuakih9', '::1', 1580717888, '__ci_last_regenerate|i:1580717888;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n6lvcr4upbsgqttsen472c9t8g0sf4qj', '::1', 1580718379, '__ci_last_regenerate|i:1580718379;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('je3i5vpvb1jp5tbo55ug1e4v8gmbf9d4', '::1', 1580719057, '__ci_last_regenerate|i:1580719057;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('srfgghcffoqhrtikheeh9flo6esn335q', '::1', 1580719459, '__ci_last_regenerate|i:1580719459;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('36b4099rb9oq00pqtvtrjvb1i2s5gppu', '::1', 1580719839, '__ci_last_regenerate|i:1580719839;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tnaifs3dlvk7ffblrf0jjq85n2914qtf', '::1', 1580720140, '__ci_last_regenerate|i:1580720140;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8tp5ocq3fsfigt6h9o2l08u44hsa6nub', '::1', 1580720453, '__ci_last_regenerate|i:1580720453;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rftpm2ofv31lthf4pagvmq65lbv6i27c', '::1', 1580720899, '__ci_last_regenerate|i:1580720899;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('li9g4me9rvabejbjg7mbeeeuj5l6h3tl', '::1', 1580721241, '__ci_last_regenerate|i:1580721241;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6hdt64cicfbt11ms4fmqd8bumgb7hu53', '::1', 1580721557, '__ci_last_regenerate|i:1580721557;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q7vv2rjvqiaopnf64rn296c24nmpi0vq', '::1', 1580723199, '__ci_last_regenerate|i:1580723199;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fjcas7be9as0v623otes6b3kph374gpt', '::1', 1580723531, '__ci_last_regenerate|i:1580723531;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tjnska4r4st4mrlpf97dji7qq8vg114v', '::1', 1580723925, '__ci_last_regenerate|i:1580723925;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kmdq3306rk1nhq5d2gscccmo20tvnnbi', '::1', 1580724449, '__ci_last_regenerate|i:1580724449;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jfvs11fcf9hdlvion12u06r6sthl6abe', '::1', 1580724784, '__ci_last_regenerate|i:1580724784;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('suriurd0ahogjo0qhvgd85l175rr6osq', '::1', 1580725102, '__ci_last_regenerate|i:1580725102;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vh1q7titvfe1o6r84p210voc26317gr5', '::1', 1580727106, '__ci_last_regenerate|i:1580727106;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9no08ak3829cibelp3s8etiatf0jaro0', '::1', 1580728190, '__ci_last_regenerate|i:1580728190;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('45udpkiva0vn93qnhjqmo7a1jnilmctr', '::1', 1580728398, '__ci_last_regenerate|i:1580728190;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('45b4h700ghhlrthga1tg733edd6dlv6k', '::1', 1580788029, '__ci_last_regenerate|i:1580788029;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:9:\"dashboard\";sub_menu|s:9:\"dashboard\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8dm2p5j1r7fdlo4l93oanlbo79mkevbp', '::1', 1580788673, '__ci_last_regenerate|i:1580788673;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:8:\"category\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('72iecc99ink0e2lehm2pr4g9r1g6fa0v', '::1', 1580788975, '__ci_last_regenerate|i:1580788975;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:9:\"dashboard\";sub_menu|s:9:\"dashboard\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jmjnfe5dmft2o3ti2hqf77lhgh4dsfc2', '::1', 1580789458, '__ci_last_regenerate|i:1580789458;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:8:\"category\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vt011uoc9uqkn1guavr8irv76eioi6k0', '::1', 1580789772, '__ci_last_regenerate|i:1580789772;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0k9hv377vh2c4p463djiet7bk1gvi7jd', '::1', 1580790098, '__ci_last_regenerate|i:1580790098;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lja972i02o6qu15ooflkua3n9t6qvv6n', '::1', 1580790431, '__ci_last_regenerate|i:1580790431;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('frfrqkjd12ofqbqcf6a9qahr29mvtmll', '::1', 1580790780, '__ci_last_regenerate|i:1580790780;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ssrifk3rcivmqtv8tsk02a5gca9okaqc', '::1', 1580791246, '__ci_last_regenerate|i:1580791246;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jd8hbvbvor01in66mo8fu6oic23vka7e', '::1', 1580791978, '__ci_last_regenerate|i:1580791978;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5s6rg92aafvp3d3b3d73j94r8hvfide7', '::1', 1580792355, '__ci_last_regenerate|i:1580792355;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('06aie99e9qt3cqci9dihqbtd5ec4qd0v', '::1', 1580793146, '__ci_last_regenerate|i:1580793146;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d1ssij9sjp4furl73euka1joe53l75d', '::1', 1580793147, '__ci_last_regenerate|i:1580793146;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9o6feicfl1kb5pnruhv0684t3cl2bpp7', '::1', 1580802434, '__ci_last_regenerate|i:1580802434;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fiupmubhjfcl8vukbaakk5kv7sfdlpi0', '::1', 1580803269, '__ci_last_regenerate|i:1580803269;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hpn153a08hn7h8tp6e22r0sknmhc12sg', '::1', 1580803782, '__ci_last_regenerate|i:1580803782;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q2cqbtnf30lrsb0jnjmfkvms3kdiukp8', '::1', 1580804753, '__ci_last_regenerate|i:1580804753;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('afee3dvgeprpi7qamkpgcssj95hot00o', '::1', 1580805156, '__ci_last_regenerate|i:1580805156;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i22bdibhh7uh9tooio3v2k16fl0n4cnp', '::1', 1580805463, '__ci_last_regenerate|i:1580805463;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pptnl1qd9u75iugpk94555vtlra08g3m', '::1', 1580806919, '__ci_last_regenerate|i:1580806919;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k7kmvnur6fgjehcfc709n6a2gto5fjsm', '::1', 1580807592, '__ci_last_regenerate|i:1580807592;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('07lumcscm9vb0r89lkmvc8n1f1sj544g', '::1', 1580807900, '__ci_last_regenerate|i:1580807900;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ajt8ja1ncgmsb7k91jqmtgr7jf77iq2r', '::1', 1580808363, '__ci_last_regenerate|i:1580808363;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('91mla7j3d8ltm4igbr9gubf2gk8uogba', '::1', 1580809312, '__ci_last_regenerate|i:1580809312;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dq030crp06p8v7ds326lhjnoop3j3a9r', '::1', 1580809671, '__ci_last_regenerate|i:1580809671;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('daf01m9nqff2mngeoplvelcm9su9lb5b', '::1', 1580810083, '__ci_last_regenerate|i:1580810083;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uvpum64rckgc818m6aphvcq66u75m4ej', '::1', 1580810702, '__ci_last_regenerate|i:1580810702;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4bu4k71m6i5u11hgcp93gik556rn08it', '::1', 1580810710, '__ci_last_regenerate|i:1580810702;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');


#
# TABLE STRUCTURE FOR: library
#

DROP TABLE IF EXISTS `library`;

CREATE TABLE `library` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `cover_image` varchar(100) DEFAULT NULL,
  `details` longtext NOT NULL,
  `gist` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_by` smallint(3) NOT NULL,
  `updateby` smallint(3) NOT NULL,
  `approved_by` smallint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4;

INSERT INTO `library` (`id`, `title`, `cover_image`, `details`, `gist`, `status`, `created_by`, `updateby`, `approved_by`, `created_at`) VALUES (25, 'গণপ্রজাতন্ত্রী বাংলাsদেশের সংবিধান প্রবর্তিত হয় ?', 'uploads/library/coverimage/Xplore_1580802711C.jpg', '&lt;p&gt;&lt;span style=&quot;font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; text-align: justify;&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vitae enim vitae orci sollicitudin interdum in id turpis. Pellentesque auctor ornare dapibus. Mauris rutrum justo sed lacus gravida, a accumsan mauris bibendum. In eget arcu porttitor, tempor eros sit amet, varius ex. Vivamus eget ligula bibendum, vehicula ex nec, elementum enim. Praesent laoreet, odio ut commodo tempor, elit nisl luctus felis, eu pellentesque eros nunc eu quam. Duis sollicitudin, metus et bibendum gravida, metus risus sodales nulla, vel aliquet sapien dui sit amet felis. Donec aliquet nulla quis turpis tincidunt, a pretium justo vestibulum.&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', '&lt;p&gt;&lt;span style=&quot;font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; text-align: justify;&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vitae enim vitae orci sollicitudin interdum in id turpis. Pellentesque auctor ornare dapibus. Mauris rutrum justo sed lacus gravida, a accumsan mauris bibendum. In eget arcu porttitor, tempor eros sit amet, varius ex. Vivamus eget ligula bibendum, vehicula ex nec, elementum enim. Praesent laoreet, odio ut commodo tempor, elit nisl luctus felis, eu pellentesque eros nunc eu quam. Duis sollicitudin, metus et bibendum gravida, metus risus sodales nulla, vel aliquet sapien dui sit amet felis. Donec aliquet nulla quis turpis tincidunt, a pretium justo vestibulum.&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', 0, 1, 0, 0, '2020-02-04 13:51:51');
INSERT INTO `library` (`id`, `title`, `cover_image`, `details`, `gist`, `status`, `created_by`, `updateby`, `approved_by`, `created_at`) VALUES (26, 'গণপ্রজাতন্ত্রী বাংলাsদেশের সংবিধান প্রবর্তিত হয় ?', 'uploads/library/coverimage/Xplore_1580802800C.jpg', '&lt;p&gt;&lt;span style=&quot;font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; text-align: justify;&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vitae enim vitae orci sollicitudin interdum in id turpis. Pellentesque auctor ornare dapibus. Mauris rutrum justo sed lacus gravida, a accumsan mauris bibendum. In eget arcu porttitor, tempor eros sit amet, varius ex. Vivamus eget ligula bibendum, vehicula ex nec, elementum enim. Praesent laoreet, odio ut commodo tempor, elit nisl luctus felis, eu pellentesque eros nunc eu quam. Duis sollicitudin, metus et bibendum gravida, metus risus sodales nulla, vel aliquet sapien dui sit amet felis. Donec aliquet nulla quis turpis tincidunt, a pretium justo vestibulum.&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', '&lt;p&gt;&lt;span style=&quot;font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; text-align: justify;&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vitae enim vitae orci sollicitudin interdum in id turpis. Pellentesque auctor ornare dapibus. Mauris rutrum justo sed lacus gravida, a accumsan mauris bibendum. In eget arcu porttitor, tempor eros sit amet, varius ex. Vivamus eget ligula bibendum, vehicula ex nec, elementum enim. Praesent laoreet, odio ut commodo tempor, elit nisl luctus felis, eu pellentesque eros nunc eu quam. Duis sollicitudin, metus et bibendum gravida, metus risus sodales nulla, vel aliquet sapien dui sit amet felis. Donec aliquet nulla quis turpis tincidunt, a pretium justo vestibulum.&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', 0, 1, 0, 0, '2020-02-04 13:53:20');
INSERT INTO `library` (`id`, `title`, `cover_image`, `details`, `gist`, `status`, `created_by`, `updateby`, `approved_by`, `created_at`) VALUES (27, 'গণপ্রজাতন্ত্রী বাংলাsদেশের সংবিধান প্রবর্তিত হয় ddf?', NULL, '&lt;p&gt;sdf&lt;/p&gt;', '&lt;p&gt;sf&lt;/p&gt;', 0, 1, 1, 0, '2020-02-04 15:52:36');
INSERT INTO `library` (`id`, `title`, `cover_image`, `details`, `gist`, `status`, `created_by`, `updateby`, `approved_by`, `created_at`) VALUES (28, 'গণপ্রজাতন্ত্রী বাংলাদেশের সংবিধান প্রবর্তিত হয় ?', 'uploads/library/coverimage/Xplore_1580805074C.jpg', '&lt;p&gt;sdf&lt;/p&gt;', '&lt;p&gt;sdsdf&lt;/p&gt;', 0, 1, 1, 0, '2020-02-04 15:54:56');
INSERT INTO `library` (`id`, `title`, `cover_image`, `details`, `gist`, `status`, `created_by`, `updateby`, `approved_by`, `created_at`) VALUES (29, 'গণপ্রজাতন্ত্রী বাংলাদেশের সংবিধান প্রবর্তিত হয় ?', NULL, '&lt;p&gt;zxc&lt;/p&gt;', '&lt;p&gt;xz&lt;/p&gt;', 0, 1, 0, 0, '2020-02-04 14:31:32');


#
# TABLE STRUCTURE FOR: library_image
#

DROP TABLE IF EXISTS `library_image`;

CREATE TABLE `library_image` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `library_id` smallint(3) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_library_id` (`library_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: library_video
#

DROP TABLE IF EXISTS `library_video`;

CREATE TABLE `library_video` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `library_id` smallint(3) NOT NULL,
  `code` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_library_id` (`library_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: permission_category
#

DROP TABLE IF EXISTS `permission_category`;

CREATE TABLE `permission_category` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `perm_group_id` smallint(3) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `short_code` varchar(50) DEFAULT NULL,
  `link` varchar(100) NOT NULL,
  `submenu` tinyint(1) NOT NULL,
  `subparent` tinyint(1) NOT NULL DEFAULT 0,
  `icon` varchar(50) DEFAULT NULL,
  `position` tinyint(2) NOT NULL,
  `enable_view` tinyint(1) DEFAULT 0,
  `enable_add` tinyint(1) DEFAULT 0,
  `enable_edit` tinyint(1) DEFAULT 0,
  `enable_delete` tinyint(1) DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_perm_group_id` (`perm_group_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (3, 3, 'Administrator', 'administrator', 'administrator', 0, 0, NULL, 1, 1, 0, 0, 0, 1, '2020-01-16 15:38:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (4, 3, 'Role Permission', 'role_permission', 'role-permission', 1, 0, '', 1, 1, 1, 1, 1, 1, '2020-01-16 15:38:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (5, 3, 'Manage User', 'manage_user', 'manage-user', 1, 0, '', 2, 1, 1, 1, 1, 1, '2020-01-16 15:38:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (6, 4, 'General Setup', 'general_setup', 'general-setup', 0, 0, NULL, 3, 1, 0, 0, 0, 1, '2020-01-16 15:38:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (7, 5, 'Dashboard', 'dashboard', 'dashboard', 0, 0, NULL, 1, 1, 0, 0, 0, 1, '2020-01-18 11:05:30');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (8, 4, 'Category', 'category', 'category', 1, 0, '', 1, 1, 1, 1, 1, 1, '2020-01-16 15:38:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (9, 4, 'Subject', 'subject', 'subject', 1, 0, '', 2, 1, 1, 1, 1, 1, '2020-01-18 10:55:50');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (10, 4, 'Section', 'section', 'section', 1, 0, '', 3, 1, 1, 1, 1, 1, '2020-01-18 10:55:50');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (11, 4, 'Topic', 'topic', 'topic', 1, 0, '', 4, 1, 1, 1, 1, 1, '2020-01-18 10:55:50');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (12, 3, 'Assign Permission', 'assign_permission', 'assign-permission', 0, 0, '', 1, 1, 1, 1, 1, 0, '2020-01-18 11:09:10');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (13, 6, 'Setting', 'setting', 'setting', 0, 0, NULL, 7, 1, 0, 0, 0, 0, '2020-01-19 10:42:13');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (14, 6, 'Reset Profile', 'reset_profile', 'reset-profile', 1, 0, '', 1, 1, 0, 1, 0, 1, '2020-01-18 12:34:47');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (15, 3, 'Backup', 'backup', 'backup', 1, 0, '', 1, 1, 1, 0, 0, 1, '2020-01-19 13:33:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (16, 4, 'Subject Assign', 'subject_assign', 'subject-assign', 1, 0, '', 3, 1, 1, 1, 1, 1, '2020-01-19 10:42:04');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (17, 4, 'Section Assign', 'section_assign', 'section-assign', 1, 0, '', 4, 1, 1, 1, 1, 1, '2020-01-19 10:42:04');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (18, 4, 'Topic Assign', 'topic_assign', 'topic-assign', 1, 0, '', 6, 1, 1, 1, 1, 1, '2020-01-19 10:42:04');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (19, 7, 'Question Setup', 'question_setup', 'question-setup', 0, 0, NULL, 3, 1, 0, 0, 0, 1, '2020-01-22 11:02:32');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (20, 7, 'Question', 'question', 'question', 1, 0, '', 1, 1, 1, 1, 1, 1, '2020-01-22 11:37:15');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (23, 4, 'Batch', 'batch', 'batch', 1, 0, '', 1, 1, 1, 1, 1, 1, '2020-01-25 12:24:21');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (24, 4, 'Question Year', 'question_year', 'question-year', 1, 0, '', 2, 1, 1, 1, 1, 0, '2020-01-25 12:24:42');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (25, 8, 'Library Setup', 'library_setup', 'library-setup', 0, 0, NULL, 3, 1, 0, 0, 0, 1, '2020-01-27 14:44:24');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (26, 8, 'Library', 'library', 'library', 1, 0, '', 1, 1, 1, 1, 1, 1, '2020-01-27 14:44:38');


#
# TABLE STRUCTURE FOR: permission_group
#

DROP TABLE IF EXISTS `permission_group`;

CREATE TABLE `permission_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `short_code` varchar(50) NOT NULL,
  `link` varchar(100) NOT NULL,
  `position` tinyint(1) NOT NULL,
  `is_active` smallint(1) DEFAULT 1,
  `system` smallint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (3, 'Administrator', 'administrator', 'administrator', 1, 1, 0, '2020-01-18 13:25:19');
INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (4, 'General Setup', 'general_setup', 'general-setup', 3, 1, 0, '2020-01-18 13:25:16');
INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (5, 'Dashboard', 'dashboard', 'dashboard', 1, 1, 0, '2020-01-18 13:25:17');
INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (6, 'Setting', 'setting', 'setting', 7, 1, 0, '2020-01-19 10:42:13');
INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (7, 'Question Setup', 'question_setup', 'question-setup', 3, 1, 0, '2020-01-22 11:02:31');
INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (8, 'Library Setup', 'library_setup', 'library-setup', 3, 1, 0, '2020-01-27 14:44:24');


#
# TABLE STRUCTURE FOR: question
#

DROP TABLE IF EXISTS `question`;

CREATE TABLE `question` (
  `id` int(7) unsigned NOT NULL AUTO_INCREMENT,
  `difficulty` tinyint(1) NOT NULL,
  `title` text NOT NULL,
  `option_1` varchar(100) NOT NULL,
  `option_2` varchar(100) NOT NULL,
  `option_3` varchar(100) NOT NULL,
  `option_4` varchar(100) NOT NULL,
  `answer` tinyint(1) NOT NULL,
  `answer_explain` text NOT NULL,
  `picture` varchar(100) DEFAULT NULL,
  `created_by_admin` smallint(3) NOT NULL,
  `created_by_user` int(7) NOT NULL,
  `approved_by` smallint(3) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=pending,1=approved',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updateby` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dificulty` (`difficulty`),
  KEY `idx_create_by_user` (`created_by_user`),
  KEY `idx_approved_by` (`approved_by`),
  KEY `idx_created_by_admin` (`created_by_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `question` (`id`, `difficulty`, `title`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`, `answer_explain`, `picture`, `created_by_admin`, `created_by_user`, `approved_by`, `status`, `created_at`, `updateby`) VALUES (1, 2, 'নিচের কোনটি অমূলদ সংখ্যা?', '০.৪', '৯', '৫.৬৩৯', '২৭৪৮', 4, '&lt;p dir=&quot;ltr&quot; style=&quot;line-height:1.38;margin-top:0pt;margin-bottom:0pt;&quot;&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;ক) ০.৪ (মূলদ সংখ্যা)&lt;/span&gt;&lt;/p&gt;&lt;p dir=&quot;ltr&quot; style=&quot;line-height:1.38;margin-top:0pt;margin-bottom:0pt;&quot;&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;[∵ সকল দশমিক পৌনঃপুনিক সংখাই মূলদ সংখ্যা]&lt;/span&gt;&lt;/p&gt;&lt;p dir=&quot;ltr&quot; style=&quot;line-height:1.38;margin-top:0pt;margin-bottom:0pt;&quot;&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;খ) &lt;/span&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;৯&lt;/span&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt; = &lt;/span&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;৩&lt;/span&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;২&lt;/span&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt; = ৩ (মূলদ সংখ্যা)&lt;/span&gt;&lt;/p&gt;&lt;p dir=&quot;ltr&quot; style=&quot;line-height:1.38;margin-top:0pt;margin-bottom:0pt;&quot;&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;গ) ৫.৬৩৯ (মূলদ সংখ্যা)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span id=&quot;docs-internal-guid-af6a9b3e-7fff-65bc-2ab8-715d58f3ccfb&quot;&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;ঘ) &lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;২৭&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;৪৮&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;= &lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;৩ х ৯&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;৩ х ১৬&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;= &lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;৩&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;৪&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt; (মূলদ সংখ্যা)&lt;/span&gt;&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', NULL, 1, 0, 0, 0, '2020-02-04 10:19:06', 1);


#
# TABLE STRUCTURE FOR: question_batch_year
#

DROP TABLE IF EXISTS `question_batch_year`;

CREATE TABLE `question_batch_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(7) unsigned NOT NULL,
  `batch_id` smallint(3) NOT NULL,
  `question_year` year(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_question_batch` (`batch_id`),
  KEY `idx_question_year` (`question_year`),
  KEY `idx_question_id` (`question_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `question_batch_year` (`id`, `question_id`, `batch_id`, `question_year`) VALUES (2, 1, 51, '2019');


#
# TABLE STRUCTURE FOR: question_year
#

DROP TABLE IF EXISTS `question_year`;

CREATE TABLE `question_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `updateby` smallint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `question_year` (`id`, `name`, `status`, `updateby`, `created_at`) VALUES (2, '2019', 1, 0, '2020-01-25 12:31:23');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `type`, `created_at`) VALUES (1, 'Super Admin', 'system', '2020-01-16 13:53:12');
INSERT INTO `roles` (`id`, `name`, `type`, `created_at`) VALUES (2, 'Admin', 'system', '2020-01-16 13:53:12');
INSERT INTO `roles` (`id`, `name`, `type`, `created_at`) VALUES (3, 'Test', 'custom', '2020-01-16 14:20:57');
INSERT INTO `roles` (`id`, `name`, `type`, `created_at`) VALUES (4, 'content manager', 'custom', '2020-01-27 22:38:01');


#
# TABLE STRUCTURE FOR: roles_permissions
#

DROP TABLE IF EXISTS `roles_permissions`;

CREATE TABLE `roles_permissions` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` smallint(4) DEFAULT NULL,
  `perm_cat_id` smallint(4) DEFAULT NULL,
  `can_view` tinyint(1) DEFAULT NULL,
  `can_add` tinyint(1) DEFAULT NULL,
  `can_edit` tinyint(1) DEFAULT NULL,
  `can_delete` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_role_id` (`role_id`) USING BTREE,
  KEY `idx_perm_cat_id` (`perm_cat_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (1, 3, 3, 1, 0, 0, 0, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (2, 3, 4, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (3, 3, 5, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (4, 3, 6, 1, 0, 0, 0, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (5, 3, 8, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (6, 3, 9, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (7, 3, 10, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (8, 3, 11, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (13, 2, 6, 1, 0, 0, 0, '2020-01-18 11:05:52');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (14, 2, 8, 1, 1, 1, 1, '2020-01-18 11:05:52');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (15, 2, 9, 1, 1, 1, 1, '2020-01-18 11:05:52');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (16, 2, 10, 1, 1, 1, 1, '2020-01-18 11:05:52');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (17, 2, 11, 1, 1, 1, 1, '2020-01-18 11:05:52');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (19, 2, 13, 1, 0, 0, 0, '2020-01-18 12:34:53');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (20, 2, 14, 1, 0, 1, 0, '2020-01-18 12:34:53');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (22, 2, 16, 1, 1, 1, 0, '2020-01-21 11:49:04');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (23, 2, 17, 1, 1, 1, 0, '2020-01-21 11:49:04');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (24, 2, 18, 1, 1, 1, 0, '2020-01-21 11:49:04');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (25, 2, 3, 1, 0, 0, 0, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (26, 2, 4, 1, 1, 1, 1, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (27, 2, 5, 1, 1, 1, 1, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (28, 2, 12, 1, 1, 1, 1, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (29, 2, 15, 1, 1, 0, 0, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (30, 2, 7, 1, 0, 0, 0, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (31, 2, 23, 1, 1, 1, 1, '2020-01-26 11:42:17');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (32, 2, 19, 1, 0, 0, 0, '2020-01-26 11:42:51');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (33, 2, 20, 1, 1, 1, 1, '2020-01-26 11:42:51');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (34, 2, 25, 1, 0, 0, 0, '2020-01-27 14:45:07');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (35, 2, 26, 1, 1, 1, 1, '2020-01-27 14:45:07');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (36, 4, 26, 1, 1, 1, 0, '2020-01-27 22:39:47');


#
# TABLE STRUCTURE FOR: section
#

DROP TABLE IF EXISTS `section`;

CREATE TABLE `section` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `updateby` smallint(4) unsigned NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_section_updateby` (`updateby`) USING BTREE,
  KEY `idx_section_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (2, 'সাহিত্য', 1, 0, '2020-01-21 11:55:33');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (3, 'বাংলাদেশের জাতীয় বিষয়াবলী', 1, 1, '2020-01-27 18:57:37');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (4, 'আন্তর্জাতিক নিরাপত্তা ও  আন্তরাষ্ট্রীয় ক্ষমতা সম্পর্ক', 1, 1, '2020-01-21 11:57:27');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (5, 'Language', 1, 0, '2020-01-27 18:36:34');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (6, 'Literature', 1, 0, '2020-01-27 18:36:56');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (7, 'Arithmetic', 1, 0, '2020-01-27 18:39:59');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (8, 'Algebra', 1, 0, '2020-01-27 18:40:04');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (10, 'ব্যাকরণ', 1, 0, '2020-01-27 23:10:07');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (11, 'বাংলাদেশের জাতীয় অর্জন', 1, 0, '2020-01-27 23:12:07');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (12, 'বাংলাদেশের অর্থনীতি', 1, 0, '2020-01-27 23:12:58');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (13, 'বাংলাদেশের সংবিধান', 1, 0, '2020-01-27 23:13:39');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (14, 'বাংলাদেশের সরকার বাবস্থা', 1, 0, '2020-01-27 23:14:25');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (15, 'আন্তর্জাতিক সংগঠন', 1, 0, '2020-01-27 23:15:31');
INSERT INTO `section` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (16, 'Geometry', 1, 0, '2020-01-27 23:26:25');


#
# TABLE STRUCTURE FOR: section_assign
#

DROP TABLE IF EXISTS `section_assign`;

CREATE TABLE `section_assign` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `subject_id` smallint(3) NOT NULL,
  `section_id` smallint(3) NOT NULL,
  `updateby` smallint(3) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_subject_id` (`subject_id`),
  KEY `idx_section_id` (`section_id`),
  KEY `idx_updateby` (`updateby`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (4, 3, 3, 0, '2020-01-21 12:51:07');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (8, 8, 8, 0, '2020-01-27 18:41:19');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (9, 8, 7, 0, '2020-01-27 18:41:24');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (11, 4, 5, 0, '2020-01-27 18:41:54');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (12, 4, 6, 0, '2020-01-27 18:42:02');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (13, 2, 4, 0, '2020-01-27 18:42:09');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (14, 1, 10, 0, '2020-01-27 23:17:40');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (15, 1, 2, 0, '2020-01-27 23:17:47');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (16, 2, 15, 0, '2020-01-27 23:18:52');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (17, 3, 12, 0, '2020-01-27 23:18:57');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (18, 3, 11, 0, '2020-01-27 23:19:03');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (19, 3, 13, 0, '2020-01-27 23:19:14');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (20, 3, 14, 0, '2020-01-27 23:19:21');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (21, 8, 16, 0, '2020-01-27 23:27:08');


#
# TABLE STRUCTURE FOR: subject
#

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `updateby` smallint(4) unsigned NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_subject_updateby` (`updateby`) USING BTREE,
  KEY `idx_subject_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `subject` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (1, 'বাংলা ভাষা ও সাহিত্য', 1, 1, '2020-01-27 18:21:16');
INSERT INTO `subject` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (2, 'আন্তর্জাতিক বিষয়াবলী', 1, 0, '2020-01-21 11:54:34');
INSERT INTO `subject` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (3, 'বাংলাদেশ বিষয়াবলী', 1, 0, '2020-01-21 11:55:06');
INSERT INTO `subject` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (4, 'English Language and Literature', 1, 0, '2020-01-27 18:21:44');
INSERT INTO `subject` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (8, 'গাণিতিক যুক্তি', 1, 0, '2020-01-27 18:27:11');


#
# TABLE STRUCTURE FOR: subject_assign
#

DROP TABLE IF EXISTS `subject_assign`;

CREATE TABLE `subject_assign` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `category_id` smallint(3) NOT NULL,
  `subject_id` smallint(3) NOT NULL,
  `updateby` smallint(3) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_subject_id` (`subject_id`),
  KEY `idx_updateby` (`updateby`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4;

INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (1, 2, 1, 0, '2020-01-21 12:47:40');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (2, 1, 1, 0, '2020-01-21 12:47:40');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (22, 2, 8, 0, '2020-01-27 18:33:09');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (23, 1, 8, 0, '2020-01-27 18:33:09');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (27, 2, 4, 0, '2020-01-27 18:33:32');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (28, 1, 4, 0, '2020-01-27 18:33:32');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (29, 4, 4, 0, '2020-01-27 18:33:32');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (30, 1, 3, 0, '2020-01-27 18:35:02');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (31, 3, 3, 0, '2020-01-27 18:35:02');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (32, 5, 3, 0, '2020-01-27 18:35:02');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (33, 1, 2, 0, '2020-01-27 18:35:08');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (34, 3, 2, 0, '2020-01-27 18:35:08');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (35, 5, 2, 0, '2020-01-27 18:35:08');


#
# TABLE STRUCTURE FOR: topic
#

DROP TABLE IF EXISTS `topic`;

CREATE TABLE `topic` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `updateby` smallint(4) unsigned NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_topic_updateby` (`updateby`) USING BTREE,
  KEY `idx_topic_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (1, 'উপসর্গ', 1, 0, '2020-01-21 17:19:33');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (2, 'মহাকাব্য', 1, 0, '2020-01-21 11:58:01');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (3, 'প্রাচীনকাল থেকে সমসাময়িক কালের ইতিহাস কৃষ্টি ও সংস্কৃতি', 1, 1, '2020-01-27 18:57:09');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (4, 'আলোচিত বিপ্লব', 1, 0, '2020-01-21 11:58:28');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (5, 'The Renaissance Period(1500-1660)', 1, 0, '2020-01-27 19:05:05');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (6, 'Gender', 1, 0, '2020-01-27 19:06:21');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (7, 'ঐকিক নিয়ম', 1, 0, '2020-01-27 21:58:45');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (8, 'adverbal', 1, 1, '2020-01-27 22:29:10');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (9, 'শতকরা', 1, 0, '2020-01-27 23:21:14');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (10, 'সূচক ও লগারিদম', 1, 0, '2020-01-27 23:21:55');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (11, 'ত্রিকোণমিতি', 1, 0, '2020-01-27 23:22:46');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (12, 'হুমায়ন আহমেদ', 1, 0, '2020-01-27 23:23:57');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (13, 'জাতিসংঘ', 1, 0, '2020-01-27 23:24:54');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (14, 'সংশোধনী', 1, 0, '2020-01-27 23:40:46');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (15, 'সিন্ধু সভ্যতা', 1, 0, '2020-01-28 10:10:01');
INSERT INTO `topic` (`id`, `name`, `status`, `updateby`, `updatetime`) VALUES (16, 'বাংলার প্রাচীন জনপদ', 1, 0, '2020-01-28 10:18:44');


#
# TABLE STRUCTURE FOR: topic_assign
#

DROP TABLE IF EXISTS `topic_assign`;

CREATE TABLE `topic_assign` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `section_id` smallint(3) NOT NULL,
  `topic_id` smallint(3) NOT NULL,
  `updateby` smallint(3) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_section_id` (`section_id`),
  KEY `idx_topic_id` (`topic_id`),
  KEY `idx_updateby` (`updateby`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (6, 2, 2, 0, '2020-01-21 13:30:13');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (7, 3, 3, 0, '2020-01-21 13:30:29');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (8, 4, 4, 0, '2020-01-21 13:30:53');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (9, 5, 6, 0, '2020-01-27 19:07:44');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (10, 6, 5, 0, '2020-01-27 19:08:40');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (11, 7, 7, 0, '2020-01-27 21:59:26');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (12, 5, 8, 0, '2020-01-27 22:32:15');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (13, 2, 12, 0, '2020-01-27 23:25:28');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (14, 15, 13, 0, '2020-01-27 23:25:52');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (15, 16, 11, 0, '2020-01-27 23:27:41');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (16, 7, 9, 0, '2020-01-27 23:28:04');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (17, 8, 10, 0, '2020-01-27 23:28:14');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (18, 13, 14, 0, '2020-01-27 23:41:01');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (19, 10, 1, 0, '2020-01-28 04:27:35');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (20, 11, 15, 0, '2020-01-28 10:10:39');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (21, 14, 16, 0, '2020-01-28 10:19:16');


#
# TABLE STRUCTURE FOR: topic_library
#

DROP TABLE IF EXISTS `topic_library`;

CREATE TABLE `topic_library` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `library_id` smallint(3) NOT NULL,
  `topic_id` smallint(3) NOT NULL,
  `category_id` smallint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_library_id` (`library_id`),
  KEY `idx_topic_id` (`topic_id`),
  KEY `idx_category_id` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `topic_library` (`id`, `library_id`, `topic_id`, `category_id`, `created_at`) VALUES (1, 25, 1, 1, '2020-02-04 13:51:51');
INSERT INTO `topic_library` (`id`, `library_id`, `topic_id`, `category_id`, `created_at`) VALUES (2, 26, 1, 2, '2020-02-04 13:53:20');
INSERT INTO `topic_library` (`id`, `library_id`, `topic_id`, `category_id`, `created_at`) VALUES (7, 29, 4, 1, '2020-02-04 14:31:32');
INSERT INTO `topic_library` (`id`, `library_id`, `topic_id`, `category_id`, `created_at`) VALUES (8, 27, 4, 3, '2020-02-04 15:52:36');
INSERT INTO `topic_library` (`id`, `library_id`, `topic_id`, `category_id`, `created_at`) VALUES (9, 27, 4, 5, '2020-02-04 15:52:36');
INSERT INTO `topic_library` (`id`, `library_id`, `topic_id`, `category_id`, `created_at`) VALUES (10, 28, 2, 1, '2020-02-04 15:54:56');


#
# TABLE STRUCTURE FOR: topics_questions
#

DROP TABLE IF EXISTS `topics_questions`;

CREATE TABLE `topics_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(7) NOT NULL,
  `topic_id` smallint(4) NOT NULL,
  `category_id` smallint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_question_id` (`question_id`),
  KEY `idx_topic_id` (`topic_id`),
  KEY `idx_category_id` (`category_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (3, 1, 9, 2, '2020-02-04 10:19:06');
INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (4, 1, 9, 1, '2020-02-04 10:19:06');


