#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `role_id` smallint(4) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `temp_password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `otp_code` tinyint(4) DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `ip` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `user_agent` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_key` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_role_id` (`role_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `admin` (`id`, `role_id`, `name`, `username`, `password`, `temp_password`, `otp_code`, `phone`, `status`, `ip`, `last_login`, `user_agent`, `reset_key`, `created_at`) VALUES (1, 1, '', 'superadmin', '$2y$10$EUWe3zy4/S7YJziZFjUhn.1mQjQrP6Ok9QlTZ/GiWE/5r5ohjR.vq', '', NULL, '', 1, '::1', '2020-02-08 07:16:18', 'Chrome 79.0.3945.130Windows 10', '', '2020-01-19 09:43:11');
INSERT INTO `admin` (`id`, `role_id`, `name`, `username`, `password`, `temp_password`, `otp_code`, `phone`, `status`, `ip`, `last_login`, `user_agent`, `reset_key`, `created_at`) VALUES (42, 2, 'Test', 'admin@gmail.com', '$2y$10$ugy0xuG/fNE0SYxFnWUPVe4jz8c/uzePjFxoO2PRO8lLKYlSV74/S', '', NULL, '(+88) 012-4512-4512', 1, '103.58.95.12', '2020-02-06 08:02:28', 'Opera 66.0.3515.44Windows 10', NULL, '2020-01-18 11:06:08');
INSERT INTO `admin` (`id`, `role_id`, `name`, `username`, `password`, `temp_password`, `otp_code`, `phone`, `status`, `ip`, `last_login`, `user_agent`, `reset_key`, `created_at`) VALUES (44, 4, 'jubair', 'superadmin@gmail.com', '$2y$10$NySu3vkq4Yp0LWcCmTUGZOkdztQhHyWYZ134lab.euOuqy2kKVhL.', '', NULL, '(+88) 019-1278-3472', 1, NULL, NULL, NULL, NULL, '2020-01-27 16:43:00');


#
# TABLE STRUCTURE FOR: batch
#

DROP TABLE IF EXISTS `batch`;

CREATE TABLE `batch` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `category_id` smallint(3) NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `position` tinyint(3) NOT NULL DEFAULT 0,
  `updateby` smallint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4;

INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (16, 1, 'শ্রম মন্ত্রণালয়ের সহকারি সচিব', 1, 0, 1, '2020-01-27 22:57:33');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (17, 1, 'পল্লী উন্নয়ন বোর্ডের মাঠ সংগঠক', 1, 0, 1, '2020-01-27 23:04:08');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (18, 1, '১৮ তম বিসিএস', 1, 0, 1, '2020-01-27 23:07:57');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (20, 1, 'সাব রেজিস্টার', 1, 0, 1, '2020-01-27 22:56:34');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (21, 1, '২১ তম', 1, 0, 1, '2020-01-27 22:59:56');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (22, 1, 'পানি উন্নয়ন বোর্ডের সহকারি পরিচালক', 1, 0, 1, '2020-01-27 22:58:53');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (23, 1, '২৪ তম বিসিএস', 1, 0, 1, '2020-01-27 23:08:37');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (24, 1, '২৫ তম', 1, 0, 1, '2020-01-27 23:08:47');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (25, 1, 'ঢাকা বিশ্ববিদ্যালয় খ ইউনিট', 1, 0, 1, '2020-01-27 23:06:53');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (26, 1, '২৬ তম বিসিএস', 1, 0, 1, '2020-01-27 23:09:01');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (27, 1, '27', 1, 0, 0, '2020-01-25 13:10:51');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (28, 1, '28', 1, 0, 0, '2020-01-25 13:10:52');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (29, 1, '29', 1, 0, 0, '2020-01-25 13:10:53');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (30, 1, '30', 1, 0, 0, '2020-01-25 13:10:54');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (31, 1, '31', 1, 0, 0, '2020-01-25 13:10:59');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (32, 1, '32', 1, 0, 0, '2020-01-25 13:11:00');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (33, 1, '33', 1, 0, 0, '2020-01-25 13:11:01');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (34, 1, '34', 1, 0, 0, '2020-01-25 13:11:02');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (35, 1, '35', 1, 0, 0, '2020-01-25 13:11:03');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (36, 1, '36', 1, 0, 0, '2020-01-25 13:11:04');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (37, 1, '37', 1, 0, 0, '2020-01-25 13:11:05');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (38, 1, '38', 1, 0, 0, '2020-01-25 13:11:06');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (39, 1, '39', 1, 0, 0, '2020-01-25 13:11:07');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (40, 1, '40', 1, 0, 0, '2020-01-25 13:11:10');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (41, 1, '41', 1, 0, 0, '2020-01-25 13:11:12');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (42, 1, '42', 1, 0, 0, '2020-01-25 13:11:13');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (43, 1, '43', 1, 0, 0, '2020-01-25 13:11:14');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (44, 1, '44', 1, 0, 0, '2020-01-25 13:11:15');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (45, 1, '34 তম', 1, 0, 0, '2020-01-27 18:05:49');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (46, 1, '৩৫ তম', 1, 0, 0, '2020-01-27 18:06:12');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (47, 1, '৩৬ তম', 1, 0, 0, '2020-01-27 18:06:20');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (48, 1, '৩৭ তম', 1, 0, 0, '2020-01-27 18:07:15');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (49, 1, '৩৮ তম', 1, 0, 0, '2020-01-27 18:07:26');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (50, 1, '৩৯ তম', 1, 0, 0, '2020-01-27 18:07:32');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (51, 1, '৪০ তম', 1, 0, 0, '2020-01-27 18:07:38');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (52, 1, '৩৩ তম', 1, 0, 0, '2020-01-27 18:07:45');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (53, 1, 'ব্যাংক নিয়োগ পরীক্ষার প্রশ্ন', 1, 0, 1, '2020-01-27 18:12:47');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (54, 1, 'বিশ্ববিদ্যালয় ভর্তি পরীক্ষার প্রশ্ন', 1, 0, 1, '2020-01-27 18:11:06');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (55, 1, 'পিএসসি ও অন্যান্য পরীক্ষার প্রশ্ন', 1, 0, 0, '2020-01-27 18:15:12');
INSERT INTO `batch` (`id`, `category_id`, `name`, `status`, `position`, `updateby`, `created_at`) VALUES (56, 1, '১০ তম', 1, 0, 0, '2020-01-27 18:17:18');


#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `position` tinyint(3) NOT NULL DEFAULT 0,
  `updateby` smallint(4) unsigned NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_category_updateby` (`updateby`) USING BTREE,
  KEY `idx_category_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `category` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (1, 'Bsc', 1, 1, 1, '2020-02-08 13:32:32');
INSERT INTO `category` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (2, 'Bank', 1, 0, 0, '2020-01-21 11:53:29');
INSERT INTO `category` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (3, 'General Knowledge', 1, 2, 1, '2020-02-08 13:32:42');
INSERT INTO `category` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (4, 'Govt Job', 1, 0, 0, '2020-01-27 18:04:57');
INSERT INTO `category` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (5, 'বিশ্ববিদ্যালয় ভর্তি পরীক্ষা', 1, 0, 0, '2020-01-27 18:34:22');
INSERT INTO `category` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (6, 'এস এস সি', 1, 0, 0, '2020-01-27 22:50:56');
INSERT INTO `category` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (7, 'এইচ এস সি', 1, 0, 0, '2020-01-27 22:52:01');
INSERT INTO `category` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (8, 'অষ্টম শ্রেণী', 1, 0, 0, '2020-01-27 22:52:38');
INSERT INTO `category` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (9, 'Mathematics', 1, 0, 0, '2020-01-27 23:29:22');


#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0668a53dbaee0436e4410440f0f3167d416b241d', '114.129.9.115', 1580899645, '__ci_last_regenerate|i:1580899645;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7a68a3a78b12fefb2cc5a17031c3ce72e62624f0', '114.129.9.115', 1580899736, '__ci_last_regenerate|i:1580899645;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0039274167628f67a16d07b4f5230812683e60be', '114.129.9.115', 1580899783, '__ci_last_regenerate|i:1580899783;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('20fad1fd820e5b211e74bbb5943fdee3edf1570c', '114.129.9.115', 1580900187, '__ci_last_regenerate|i:1580900187;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:9:\"dashboard\";sub_menu|s:9:\"dashboard\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7e59cc8d40b62cbb60d30c3a17402cb5f4844bc1', '114.129.9.115', 1580900193, '__ci_last_regenerate|i:1580900187;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8d646e4065d91c1695bf12522ed4284b4166bb36', '103.58.95.12', 1580907013, '__ci_last_regenerate|i:1580907013;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5d55242630ca4006b6d168591de4cf95eef270ff', '103.58.95.12', 1580907386, '__ci_last_regenerate|i:1580907386;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('87a0366ab65f4e09e5b97875ea1faade55a56833', '103.58.95.12', 1580909288, '__ci_last_regenerate|i:1580909288;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('61121de053615c1edfe947982d14305f2be873ad', '103.58.95.12', 1580915809, '__ci_last_regenerate|i:1580915809;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('511c25f801b59ec4068d5379c5938c6f95942654', '103.58.95.12', 1580917677, '__ci_last_regenerate|i:1580917677;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ec04358c5a8487eccae1ff9c3c19a85a9a1817c', '103.58.95.12', 1580918343, '__ci_last_regenerate|i:1580918343;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1f3b6d34b736a20ef6273a806d310ae03d28a7de', '103.58.95.12', 1580918854, '__ci_last_regenerate|i:1580918854;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e0fade3db11d29288938948a3e94dc7e1966c130', '103.58.95.12', 1580920233, '__ci_last_regenerate|i:1580920233;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:7:\"section\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7cc269291280ad6d1c2c0af98cdd1a8196d1866c', '103.58.95.12', 1580920781, '__ci_last_regenerate|i:1580920781;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfd5600b00284c3ae725eebf6bd030be4448f020', '202.83.127.36', 1580922636, '__ci_last_regenerate|i:1580922636;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f2b1f149ca096018cbd6468b9336508fde1ba234', '103.58.95.12', 1580922292, '__ci_last_regenerate|i:1580922292;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9d4b6d7a960c74375092f62457854c8d3319d4a2', '103.58.95.12', 1580922843, '__ci_last_regenerate|i:1580922843;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6b0ec30f129797a26f1491baa3690d2ac0345ab5', '202.83.127.36', 1580922945, '__ci_last_regenerate|i:1580922945;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('55f486d5c5e10b525354e2cc9f7a597c2534d2e0', '103.58.95.12', 1580922882, '__ci_last_regenerate|i:1580922843;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dc2222b50f7bf5d9ccf6c85d37b5e427a0722f02', '202.83.127.36', 1580923320, '__ci_last_regenerate|i:1580923320;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5e260fe53903e7910920536558d046582bbe53aa', '202.83.127.36', 1580923603, '__ci_last_regenerate|i:1580923320;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0c6a8d3da40d21852288ed221c704e7a92eeaee9', '104.238.217.123', 1580932878, '__ci_last_regenerate|i:1580932878;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('695fc05468049eb8253771b71f40f440c96f3385', '220.181.51.115', 1580936078, '__ci_last_regenerate|i:1580936078;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('789ca84439d174194787f002700ebb8ee77f2048', '93.63.162.100', 1580938691, '__ci_last_regenerate|i:1580938691;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('323c96759a8cc1a85a433b7d96d56e2f9f0bad31', '93.63.162.100', 1580938692, '__ci_last_regenerate|i:1580938692;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f9e32a0a8a69e6df5233a191053f4b8019e07b16', '93.63.162.100', 1580938692, '__ci_last_regenerate|i:1580938692;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2a6fe04249fb52cb614d824390b6d69182700582', '54.202.104.48', 1580941076, '__ci_last_regenerate|i:1580941076;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('acd9261e5c350db6304474963d9dcd6ade6b843c', '54.218.36.42', 1580941078, '__ci_last_regenerate|i:1580941078;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('680401b29d681a439a82a7ebe3ead3374976b85e', '123.125.71.78', 1580947015, '__ci_last_regenerate|i:1580947015;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('db9f5c4bf25963fe4763489af45b3343e2409c4b', '138.197.148.89', 1580947054, '__ci_last_regenerate|i:1580947054;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('56929cdab2cba61ead4c5ef8e99f168942ca476e', '142.93.145.204', 1580947054, '__ci_last_regenerate|i:1580947054;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('771d6cdef243c8242adfda132db205f11af830df', '138.197.173.88', 1580947055, '__ci_last_regenerate|i:1580947055;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('674b40ef1409455c03b0e31d31b6f496316c3bae', '138.197.152.122', 1580947055, '__ci_last_regenerate|i:1580947055;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cc47b72de0355ac8ae4a3544b38c48c1baf54423', '114.129.9.115', 1580960193, '__ci_last_regenerate|i:1580960193;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4842e4306cab79fd230f75c97fa1613451d8af09', '52.25.81.41', 1580960106, '__ci_last_regenerate|i:1580960106;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dc752bc28a90649e7b4dc2425a00820f7b277d50', '114.129.9.115', 1580960540, '__ci_last_regenerate|i:1580960540;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ba22f5945e6e2dbc1facf43c76f55fed9cdcdd3e', '114.129.9.115', 1580961060, '__ci_last_regenerate|i:1580961060;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d260ee78da69560f1fe564eeb83dbd172f1c8a2d', '114.129.9.115', 1580961441, '__ci_last_regenerate|i:1580961441;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1209eec03d85c18bb2df18a55b6212cc8f5eeb44', '114.129.9.115', 1580964855, '__ci_last_regenerate|i:1580964855;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fbbd14d5dd7c288400ac3e835f1f15387e1fa14d', '52.221.180.193', 1580963443, '__ci_last_regenerate|i:1580963443;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('be567cb04e54407c635dae7520348905424c43c5', '52.221.180.193', 1580963443, '__ci_last_regenerate|i:1580963443;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e34ae408ba6e1577f0c8edb7f49b6ee99a23be4d', '52.221.180.193', 1580963444, '__ci_last_regenerate|i:1580963444;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('130a3be43e66172808f9126e5fd35c23eabf72cb', '52.221.180.193', 1580963446, '__ci_last_regenerate|i:1580963446;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eac6f7cff81b83cf4666ccd4f99cf47c8ba556f3', '114.129.9.115', 1580965207, '__ci_last_regenerate|i:1580965207;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c28c24eb4bb679f321d501d19a987701ff1c8b8c', '103.58.95.12', 1580965201, '__ci_last_regenerate|i:1580965201;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2f7e93edec9377a87bfc95153cf5b36d26ae1343', '103.58.95.12', 1580965517, '__ci_last_regenerate|i:1580965517;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b3628abfd50f4c97ce3401e3e87b9d236b41fc39', '114.129.9.115', 1580965952, '__ci_last_regenerate|i:1580965952;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a204c728d2cdcf6be9be6c1aaf58ee9148b05a3f', '103.58.95.12', 1580965961, '__ci_last_regenerate|i:1580965961;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7b2bcc9a7b617c5ce66392c7b76d80c193022edb', '114.129.9.115', 1580965969, '__ci_last_regenerate|i:1580965952;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('49d4f60468ad83b58af3d104af222bc307a02e34', '103.58.95.12', 1580966153, '__ci_last_regenerate|i:1580965961;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('42ea7bcc4c3703d97010c0bcd24689d0764a32b9', '65.154.226.100', 1580973226, '__ci_last_regenerate|i:1580973224;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fba130b1ce53280b23d3a1023892a18fedf8d705', '65.154.226.100', 1580973229, '__ci_last_regenerate|i:1580973229;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f67d1cd50b1aef343ff4f90a086890c4ee88c8a0', '65.155.30.101', 1580973231, '__ci_last_regenerate|i:1580973230;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('12b8c2bd539b356c804d61d2825dbfed5ba18d08', '65.154.226.220', 1580974616, '__ci_last_regenerate|i:1580974616;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d0741bb8ed77c4fc96223c171a8d44563f909e6e', '65.154.226.220', 1580974619, '__ci_last_regenerate|i:1580974619;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6dd80a87712b48653adaf7d656e71b59b120f8a8', '103.58.95.12', 1580976148, '__ci_last_regenerate|i:1580976148;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5e5302786edc10b3f38c323f8e238146f36614cd', '103.58.95.12', 1580977575, '__ci_last_regenerate|i:1580977575;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('607c04a15fac9ae14283c1907f996bcb1796bb7e', '114.129.9.115', 1580977319, '__ci_last_regenerate|i:1580977319;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0d1342fb6dfc7408812573d7764b80c035492508', '114.129.9.115', 1580976948, '__ci_last_regenerate|i:1580976948;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8f16406419a22217334bd3e270e0404341adce6e', '114.129.9.115', 1580978098, '__ci_last_regenerate|i:1580978098;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('afbe5bf3c61dd486827535d95e71e98ac6d0f902', '52.33.153.86', 1580977449, '__ci_last_regenerate|i:1580977449;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('55b44a3042e898a573cf9e823e5b1ead29b830dd', '103.58.95.12', 1580978297, '__ci_last_regenerate|i:1580978297;id|s:2:\"42\";username|s:15:\"admin@gmail.com\";role_id|s:1:\"2\";role_name|s:5:\"Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f458969873c35cefe1aa4ac3f52d817a54b17898', '114.129.9.115', 1580979890, '__ci_last_regenerate|i:1580979890;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dbfdf7c4fcc1da08491969e92e6740048734380c', '103.58.95.12', 1580980325, '__ci_last_regenerate|i:1580980325;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('976c71bb95a152595f1a2494944f2da4657fde9f', '18.188.218.13', 1580979235, '__ci_last_regenerate|i:1580979235;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d95eba1e54006c5afe92b90126e6426ca4cc295c', '18.188.218.13', 1580979239, '__ci_last_regenerate|i:1580979239;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4f30a3b5ed8969a62d3dc6735c86ce04c79d85e2', '114.129.9.115', 1580980424, '__ci_last_regenerate|i:1580980424;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('622a06bdcc6a23abe08198eace0e57444cf122e3', '103.58.95.12', 1580980325, '__ci_last_regenerate|i:1580980325;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('404088d54f6997da15de835efddf6e62cb8656a4', '103.58.95.12', 1580980325, '__ci_last_regenerate|i:1580980325;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67361b8b4c9fd5c7b6e16abcb9a6d73597e2f23b', '103.58.95.12', 1580980327, '__ci_last_regenerate|i:1580980325;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2bd7f472aae21284fd3aab0dee64933da67e7aad', '103.58.95.12', 1580980346, '__ci_last_regenerate|i:1580980345;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9d54d5174be8802ecfea7a5a3dd7581106629899', '114.129.9.115', 1580980499, '__ci_last_regenerate|i:1580980424;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('75il7le6im8f0svso5e368rbos287v2f', '::1', 1580981174, '__ci_last_regenerate|i:1580981174;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:5:\"topic\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c5brn2nda59nt2i0kqdcgd89b8d46tlu', '::1', 1580982126, '__ci_last_regenerate|i:1580982126;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:5:\"batch\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2qk1ap5vdpumg9leac9panjnca8oecev', '::1', 1580984721, '__ci_last_regenerate|i:1580984721;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:9:\"dashboard\";sub_menu|s:9:\"dashboard\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('masvteapd0ouo6c80l80rdijeiignsp5', '::1', 1580985459, '__ci_last_regenerate|i:1580985459;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fp32c9pqr1dbo3isvijd5l7hirv99fc6', '::1', 1580985873, '__ci_last_regenerate|i:1580985873;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hqceb6vkfiavnl1ugnd4c5nb3oversu1', '::1', 1580985879, '__ci_last_regenerate|i:1580985873;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:5:\"batch\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pgo24ijra4v472eombimiimchpueejlr', '::1', 1581140295, '__ci_last_regenerate|i:1581140295;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lsqhe52ceg6kr9j6ukpi7bp0idkf8ffs', '::1', 1581142470, '__ci_last_regenerate|i:1581142470;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dfhkd620l2nvtnug89n5dqbvp34p689n', '::1', 1581142886, '__ci_last_regenerate|i:1581142886;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:8:\"category\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gbhde18icjkjp4pm3oomlp3tuuv6t8pm', '::1', 1581144486, '__ci_last_regenerate|i:1581144486;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nvdsnd7kp9opdkph32igocj899hj5hgp', '::1', 1581143208, '__ci_last_regenerate|i:1581143208;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:8:\"category\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kbctit743755rpj369alr9fgg3ink45q', '::1', 1581146697, '__ci_last_regenerate|i:1581146697;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1hejvbam5h90jgcqjm82qotq2e6grdld', '::1', 1581144816, '__ci_last_regenerate|i:1581144816;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1b7r1msof44caqom8bb5g5d6cltcbf0e', '::1', 1581145150, '__ci_last_regenerate|i:1581145150;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2m9n6rlft1ug0ucmu7cra2vorq6ige8e', '::1', 1581145610, '__ci_last_regenerate|i:1581145610;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4d39ld253iqhb7mbjmjrjb64ntilu1rs', '::1', 1581146268, '__ci_last_regenerate|i:1581146268;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n6i4jt273qaot7c9dalkfq26f29u16kn', '::1', 1581146671, '__ci_last_regenerate|i:1581146671;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jsg75nkcdve86cim3nmn16ahdk64nc9i', '::1', 1581146754, '__ci_last_regenerate|i:1581146671;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9qrp02ehjdplifvk2ds7k42b5dgo4ove', '::1', 1581147007, '__ci_last_regenerate|i:1581147007;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:8:\"category\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t49ln6dks4a6el0agook7hq1h3vv2fm7', '::1', 1581147434, '__ci_last_regenerate|i:1581147434;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:8:\"category\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ic5utlp8nrvt1d0rcpkee3eriqsq717r', '::1', 1581147759, '__ci_last_regenerate|i:1581147759;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:8:\"category\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cna3qseij6sgjs1fcut2uotfq03079bn', '::1', 1581148126, '__ci_last_regenerate|i:1581148126;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:7:\"subject\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('15aghqef23eo513fjanu0t194h6u9b5n', '::1', 1581148545, '__ci_last_regenerate|i:1581148545;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"general_setup\";sub_menu|s:7:\"subject\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ud8249tqls8t1u5gcha6gvcuen2e9a4d', '::1', 1581148956, '__ci_last_regenerate|i:1581148956;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rfkr5riu0343e87n4pg6kglauanl6s03', '::1', 1581149275, '__ci_last_regenerate|i:1581149275;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:14:\"question_setup\";sub_menu|s:8:\"question\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jcplbqq651f0le0dgq1ko1m8f00rmdnc', '::1', 1581149677, '__ci_last_regenerate|i:1581149677;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gaieg0p1sb13n5vtth0dm8bvj81igdka', '::1', 1581149980, '__ci_last_regenerate|i:1581149980;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h5rc3m03oj12ifg6vtmplqsrofuapfvv', '::1', 1581151097, '__ci_last_regenerate|i:1581151097;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:13:\"library_setup\";sub_menu|s:7:\"library\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('88o8jbcuhc1ecmmstcqc5fvgi8if7rh6', '::1', 1581151430, '__ci_last_regenerate|i:1581151430;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:9:\"dashboard\";sub_menu|s:9:\"dashboard\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tk8vq12qa6djuv9a8fa7u0st4m14ttrp', '::1', 1581151433, '__ci_last_regenerate|i:1581151430;id|s:1:\"1\";username|s:10:\"superadmin\";role_id|s:1:\"1\";role_name|s:11:\"Super Admin\";top_menu|s:9:\"dashboard\";sub_menu|s:9:\"dashboard\";set_active|s:9:\"dashboard\";menu_code|s:9:\"dashboard\";');


#
# TABLE STRUCTURE FOR: library
#

DROP TABLE IF EXISTS `library`;

CREATE TABLE `library` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `cover_image` varchar(100) DEFAULT NULL,
  `details` longtext NOT NULL,
  `gist` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `position` int(6) NOT NULL DEFAULT 0,
  `created_by` smallint(3) NOT NULL,
  `updateby` smallint(3) NOT NULL,
  `approved_by` smallint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4;

INSERT INTO `library` (`id`, `title`, `cover_image`, `details`, `gist`, `status`, `position`, `created_by`, `updateby`, `approved_by`, `created_at`) VALUES (32, 'গণপ্রজাতন্ত্রী বাংলাsদেশের সংবিধান প্রবর্তিত হয় ?', 'uploads/library/coverimage/Xplore_1580898532C.jpg', '&lt;div&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum ipsum libero, mollis at nisi sit amet, congue volutpat diam. Sed ultrices pretium enim vel vulputate. Vivamus velit lorem, pharetra eget maximus eu, luctus eget augue. Nunc vestibulum vitae arcu at tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam vestibulum, ex et fringilla sagittis, orci felis suscipit arcu, at bibendum ante erat vel neque. Fusce lacinia nisl leo, sed rhoncus magna semper ac. Etiam eget eros congue, venenatis velit non, pellentesque sem. Suspendisse hendrerit enim ut enim dictum molestie. Phasellus ut condimentum sapien. Suspendisse nec ligula at arcu consequat ullamcorper. Mauris dignissim venenatis sem consectetur consequat. Quisque laoreet nisi eget ligula vehicula placerat.&lt;br&gt;&lt;/div&gt;', '&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum ipsum libero, mollis at nisi sit amet, congue volutpat diam. Sed ultrices pretium enim vel vulputate. Vivamus velit lorem, pharetra eget maximus eu, luctus eget augue. Nunc vestibulum vitae arcu at tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam vestibulum, ex et fringilla sagittis, orci felis suscipit arcu, at bibendum ante erat vel neque. Fusce lacinia nisl leo, sed rhoncus magna semper ac. Etiam eget eros congue, venenatis velit non, pellentesque sem. Suspendisse hendrerit enim ut enim dictum molestie. Phasellus ut condimentum sapien. Suspendisse nec ligula at arcu consequat ullamcorper. Mauris dignissim venenatis sem consectetur consequat. Quisque laoreet nisi eget ligula vehicula placerat.&lt;br&gt;&lt;/p&gt;', 0, 1, 1, 1, 0, '2020-02-08 14:17:18');


#
# TABLE STRUCTURE FOR: library_image
#

DROP TABLE IF EXISTS `library_image`;

CREATE TABLE `library_image` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `library_id` smallint(3) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_library_id` (`library_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4;

INSERT INTO `library_image` (`id`, `library_id`, `picture`, `created_at`) VALUES (44, 32, 'uploads/library/slideimage/Xplore_1580898532S_0.jpg', '2020-02-05 16:28:52');
INSERT INTO `library_image` (`id`, `library_id`, `picture`, `created_at`) VALUES (45, 32, 'uploads/library/slideimage/Xplore_1580898532S_1.jpg', '2020-02-05 16:28:52');
INSERT INTO `library_image` (`id`, `library_id`, `picture`, `created_at`) VALUES (46, 32, 'uploads/library/slideimage/Xplore_1580898532S_2.jpg', '2020-02-05 16:28:52');


#
# TABLE STRUCTURE FOR: library_video
#

DROP TABLE IF EXISTS `library_video`;

CREATE TABLE `library_video` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `library_id` smallint(3) NOT NULL,
  `video_url` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_library_id` (`library_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4;

INSERT INTO `library_video` (`id`, `library_id`, `video_url`, `created_at`) VALUES (90, 32, 'https://www.youtube.com/embed/iFUFFUb5W4w', '2020-02-08 14:20:11');
INSERT INTO `library_video` (`id`, `library_id`, `video_url`, `created_at`) VALUES (91, 32, 'https://www.youtube.com/embed/zCFJLa8dIjo', '2020-02-08 14:20:11');
INSERT INTO `library_video` (`id`, `library_id`, `video_url`, `created_at`) VALUES (92, 32, 'https://www.dailymotion.com/embed/video/x2e4evk', '2020-02-08 14:20:11');


#
# TABLE STRUCTURE FOR: permission_category
#

DROP TABLE IF EXISTS `permission_category`;

CREATE TABLE `permission_category` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `perm_group_id` smallint(3) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `short_code` varchar(50) DEFAULT NULL,
  `link` varchar(100) NOT NULL,
  `submenu` tinyint(1) NOT NULL,
  `subparent` tinyint(1) NOT NULL DEFAULT 0,
  `icon` varchar(50) DEFAULT NULL,
  `position` tinyint(2) NOT NULL,
  `enable_view` tinyint(1) DEFAULT 0,
  `enable_add` tinyint(1) DEFAULT 0,
  `enable_edit` tinyint(1) DEFAULT 0,
  `enable_delete` tinyint(1) DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_perm_group_id` (`perm_group_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (3, 3, 'Administrator', 'administrator', 'administrator', 0, 0, NULL, 1, 1, 0, 0, 0, 1, '2020-01-16 15:38:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (4, 3, 'Role Permission', 'role_permission', 'role-permission', 1, 0, '', 1, 1, 1, 1, 1, 1, '2020-01-16 15:38:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (5, 3, 'Manage User', 'manage_user', 'manage-user', 1, 0, '', 2, 1, 1, 1, 1, 1, '2020-01-16 15:38:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (6, 4, 'General Setup', 'general_setup', 'general-setup', 0, 0, NULL, 3, 1, 0, 0, 0, 1, '2020-01-16 15:38:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (7, 5, 'Dashboard', 'dashboard', 'dashboard', 0, 0, NULL, 1, 1, 0, 0, 0, 1, '2020-01-18 11:05:30');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (8, 4, 'Category', 'category', 'category', 1, 0, '', 1, 1, 1, 1, 1, 1, '2020-01-16 15:38:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (9, 4, 'Subject', 'subject', 'subject', 1, 0, '', 2, 1, 1, 1, 1, 1, '2020-01-18 10:55:50');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (10, 4, 'Section', 'section', 'section', 1, 0, '', 3, 1, 1, 1, 1, 1, '2020-01-18 10:55:50');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (11, 4, 'Topic', 'topic', 'topic', 1, 0, '', 4, 1, 1, 1, 1, 1, '2020-01-18 10:55:50');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (12, 3, 'Assign Permission', 'assign_permission', 'assign-permission', 0, 0, '', 1, 1, 1, 1, 1, 0, '2020-01-18 11:09:10');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (13, 6, 'Setting', 'setting', 'setting', 0, 0, NULL, 7, 1, 0, 0, 0, 0, '2020-01-19 10:42:13');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (14, 6, 'Reset Profile', 'reset_profile', 'reset-profile', 1, 0, '', 1, 1, 0, 1, 0, 1, '2020-01-18 12:34:47');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (15, 3, 'Backup', 'backup', 'backup', 1, 0, '', 1, 1, 1, 0, 0, 1, '2020-01-19 13:33:46');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (16, 4, 'Subject Assign', 'subject_assign', 'subject-assign', 1, 0, '', 3, 1, 1, 1, 1, 1, '2020-01-19 10:42:04');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (17, 4, 'Section Assign', 'section_assign', 'section-assign', 1, 0, '', 4, 1, 1, 1, 1, 1, '2020-01-19 10:42:04');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (18, 4, 'Topic Assign', 'topic_assign', 'topic-assign', 1, 0, '', 6, 1, 1, 1, 1, 1, '2020-01-19 10:42:04');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (19, 7, 'Question Setup', 'question_setup', 'question-setup', 0, 0, NULL, 3, 1, 0, 0, 0, 1, '2020-01-22 11:02:32');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (20, 7, 'Question', 'question', 'question', 1, 0, '', 1, 1, 1, 1, 1, 1, '2020-01-22 11:37:15');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (23, 4, 'Batch', 'batch', 'batch', 1, 0, '', 1, 1, 1, 1, 1, 1, '2020-01-25 12:24:21');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (24, 4, 'Question Year', 'question_year', 'question-year', 1, 0, '', 2, 1, 1, 1, 1, 0, '2020-01-25 12:24:42');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (25, 8, 'Library Setup', 'library_setup', 'library-setup', 0, 0, NULL, 3, 1, 0, 0, 0, 1, '2020-01-27 14:44:24');
INSERT INTO `permission_category` (`id`, `perm_group_id`, `name`, `short_code`, `link`, `submenu`, `subparent`, `icon`, `position`, `enable_view`, `enable_add`, `enable_edit`, `enable_delete`, `status`, `created_at`) VALUES (26, 8, 'Library', 'library', 'library', 1, 0, '', 1, 1, 1, 1, 1, 1, '2020-01-27 14:44:38');


#
# TABLE STRUCTURE FOR: permission_group
#

DROP TABLE IF EXISTS `permission_group`;

CREATE TABLE `permission_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `short_code` varchar(50) NOT NULL,
  `link` varchar(100) NOT NULL,
  `position` tinyint(1) NOT NULL,
  `is_active` smallint(1) DEFAULT 1,
  `system` smallint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (3, 'Administrator', 'administrator', 'administrator', 1, 1, 0, '2020-01-18 13:25:19');
INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (4, 'General Setup', 'general_setup', 'general-setup', 3, 1, 0, '2020-01-18 13:25:16');
INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (5, 'Dashboard', 'dashboard', 'dashboard', 1, 1, 0, '2020-01-18 13:25:17');
INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (6, 'Setting', 'setting', 'setting', 7, 1, 0, '2020-01-19 10:42:13');
INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (7, 'Question Setup', 'question_setup', 'question-setup', 3, 1, 0, '2020-01-22 11:02:31');
INSERT INTO `permission_group` (`id`, `name`, `short_code`, `link`, `position`, `is_active`, `system`, `created_at`) VALUES (8, 'Library Setup', 'library_setup', 'library-setup', 3, 1, 0, '2020-01-27 14:44:24');


#
# TABLE STRUCTURE FOR: question
#

DROP TABLE IF EXISTS `question`;

CREATE TABLE `question` (
  `id` int(7) unsigned NOT NULL AUTO_INCREMENT,
  `difficulty` tinyint(1) NOT NULL,
  `title` text NOT NULL,
  `option_1` varchar(100) NOT NULL,
  `option_2` varchar(100) NOT NULL,
  `option_3` varchar(100) NOT NULL,
  `option_4` varchar(100) NOT NULL,
  `answer` tinyint(1) NOT NULL,
  `answer_explain` text NOT NULL,
  `picture` varchar(100) DEFAULT NULL,
  `created_by_admin` smallint(3) NOT NULL,
  `created_by_user` int(7) NOT NULL,
  `approved_by` smallint(3) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=pending,1=approved',
  `position` int(6) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updateby` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dificulty` (`difficulty`),
  KEY `idx_create_by_user` (`created_by_user`),
  KEY `idx_approved_by` (`approved_by`),
  KEY `idx_created_by_admin` (`created_by_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;

INSERT INTO `question` (`id`, `difficulty`, `title`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`, `answer_explain`, `picture`, `created_by_admin`, `created_by_user`, `approved_by`, `status`, `position`, `created_at`, `updateby`) VALUES (1, 2, 'নিচের কোনটি অমূলদ সংখ্যা?', '০.৪', '৯', '৫.৬৩৯', '২৭৪৮', 4, '&lt;p dir=&quot;ltr&quot; style=&quot;line-height:1.38;margin-top:0pt;margin-bottom:0pt;&quot;&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;ক) ০.৪ (মূলদ সংখ্যা)&lt;/span&gt;&lt;/p&gt;&lt;p dir=&quot;ltr&quot; style=&quot;line-height:1.38;margin-top:0pt;margin-bottom:0pt;&quot;&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;[∵ সকল দশমিক পৌনঃপুনিক সংখাই মূলদ সংখ্যা]&lt;/span&gt;&lt;/p&gt;&lt;p dir=&quot;ltr&quot; style=&quot;line-height:1.38;margin-top:0pt;margin-bottom:0pt;&quot;&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;খ) &lt;/span&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;৯&lt;/span&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt; = &lt;/span&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;৩&lt;/span&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;২&lt;/span&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt; = ৩ (মূলদ সংখ্যা)&lt;/span&gt;&lt;/p&gt;&lt;p dir=&quot;ltr&quot; style=&quot;line-height:1.38;margin-top:0pt;margin-bottom:0pt;&quot;&gt;&lt;span style=&quot;font-size:11pt;font-family:Arial;color:#000000;background-color:transparent;font-weight:400;font-style:normal;font-variant:normal;text-decoration:none;vertical-align:baseline;white-space:pre;white-space:pre-wrap;&quot;&gt;গ) ৫.৬৩৯ (মূলদ সংখ্যা)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span id=&quot;docs-internal-guid-af6a9b3e-7fff-65bc-2ab8-715d58f3ccfb&quot;&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;ঘ) &lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;২৭&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;৪৮&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;= &lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;৩ х ৯&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;৩ х ১৬&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;= &lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;৩&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt;৪&lt;/span&gt;&lt;span style=&quot;font-size: 11pt; font-family: Arial; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;&quot;&gt; (মূলদ সংখ্যা)&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;', NULL, 1, 0, 0, 0, 0, '2020-02-05 15:43:09', 1);
INSERT INTO `question` (`id`, `difficulty`, `title`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`, `answer_explain`, `picture`, `created_by_admin`, `created_by_user`, `approved_by`, `status`, `position`, `created_at`, `updateby`) VALUES (8, 1, 'কোনটি দ্বিঘাত সমীকরন?', '$$x = {-b \\pm \\sqrt{b^2-4ac} \\over 2a}.$$', '$$x = {-b \\pm \\sqrt{b^2-4ac} \\over 2a}.$$', '$$x = {-b \\pm \\sqrt{b^2-4ac} \\over 2a}.$$', '$$x = {-b \\pm \\sqrt{b^2-4ac} \\over 2a}.$$', 1, '&lt;p&gt;$$x = {-b \\pm \\sqrt{b^2-4ac} \\over 2a}.$$&lt;br&gt;&lt;/p&gt;', 'uploads/question/Xplore_1580898645Q.jpg', 1, 0, 0, 0, 0, '2020-02-05 22:02:41', 42);
INSERT INTO `question` (`id`, `difficulty`, `title`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`, `answer_explain`, `picture`, `created_by_admin`, `created_by_user`, `approved_by`, `status`, `position`, `created_at`, `updateby`) VALUES (9, 1, 'কোনটি সমীকরন?', '$$x = {-b \\pm \\sqrt{b^2-4ac} \\over 2a}.$$', '$$x = {-b \\pm \\sqrt{b^2-4ac} \\over 2a}.$$', '$$x = {-b \\pm \\sqrt{b^2-4ac} \\over 2a}.$$', '$$x = {-b \\pm \\sqrt{b^2-4ac} \\over 2a}.$$', 2, '&lt;p&gt;&lt;span class=&quot;note-math&quot;&gt;&lt;span class=&quot;note-latex&quot; style=&quot;display: none;&quot;&gt;\\begin{array}{cc}    a &amp;amp; b \\\\    c &amp;amp; d \\end{array}&lt;/span&gt;&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', NULL, 42, 0, 0, 0, 0, '2020-02-05 18:55:04', 0);
INSERT INTO `question` (`id`, `difficulty`, `title`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`, `answer_explain`, `picture`, `created_by_admin`, `created_by_user`, `approved_by`, `status`, `position`, `created_at`, `updateby`) VALUES (17, 2, 'Matrix', '$$\\begin{Bmatrix}    a & b \\\\    c & d \\end{Bmatrix}$$', '$$\\begin{Bmatrix}    a & b \\\\    c & d \\end{Bmatrix}$$', '$$\\begin{Bmatrix}    a & b \\\\    c & d \\end{Bmatrix}$$', '$$\\begin{Bmatrix}    a & b \\\\    c & d \\end{Bmatrix}$$', 2, '&lt;p&gt;&lt;span class=&quot;note-math&quot;&gt;&lt;span class=&quot;katex&quot;&gt;&lt;span class=&quot;katex-mathml&quot;&gt;&lt;math&gt;&lt;semantics&gt;&lt;mrow&gt;&lt;mrow&gt;&lt;mo fence=&quot;true&quot;&gt;{&lt;/mo&gt;&lt;mtable&gt;&lt;mtr&gt;&lt;mtd&gt;&lt;mstyle scriptlevel=&quot;0&quot; displaystyle=&quot;false&quot;&gt;&lt;mrow&gt;&lt;mi&gt;a&lt;/mi&gt;&lt;/mrow&gt;&lt;/mstyle&gt;&lt;/mtd&gt;&lt;mtd&gt;&lt;mstyle scriptlevel=&quot;0&quot; displaystyle=&quot;false&quot;&gt;&lt;mrow&gt;&lt;mi&gt;b&lt;/mi&gt;&lt;/mrow&gt;&lt;/mstyle&gt;&lt;/mtd&gt;&lt;/mtr&gt;&lt;mtr&gt;&lt;mtd&gt;&lt;mstyle scriptlevel=&quot;0&quot; displaystyle=&quot;false&quot;&gt;&lt;mrow&gt;&lt;mi&gt;c&lt;/mi&gt;&lt;/mrow&gt;&lt;/mstyle&gt;&lt;/mtd&gt;&lt;mtd&gt;&lt;mstyle scriptlevel=&quot;0&quot; displaystyle=&quot;false&quot;&gt;&lt;mrow&gt;&lt;mi&gt;d&lt;/mi&gt;&lt;/mrow&gt;&lt;/mstyle&gt;&lt;/mtd&gt;&lt;/mtr&gt;&lt;/mtable&gt;&lt;mo fence=&quot;true&quot;&gt;}&lt;/mo&gt;&lt;/mrow&gt;&lt;/mrow&gt;&lt;annotation encoding=&quot;application/x-tex&quot;&gt;\\begin{Bmatrix}    a &amp;amp; b \\\\    c &amp;amp; d \\end{Bmatrix}&lt;/annotation&gt;&lt;/semantics&gt;&lt;/math&gt;&lt;/span&gt;&lt;span class=&quot;katex-html&quot; aria-hidden=&quot;true&quot;&gt;&lt;span class=&quot;strut&quot; style=&quot;height: 1.45em;&quot;&gt;&lt;/span&gt;&lt;span class=&quot;strut bottom&quot; style=&quot;height: 2.40003em; vertical-align: -0.95003em;&quot;&gt;&lt;/span&gt;&lt;span class=&quot;base&quot;&gt;&lt;span class=&quot;minner&quot;&gt;&lt;span class=&quot;mopen delimcenter&quot; style=&quot;top: 0em;&quot;&gt;&lt;span class=&quot;delimsizing size3&quot;&gt;{&lt;/span&gt;&lt;/span&gt;&lt;span class=&quot;mord&quot;&gt;&lt;span class=&quot;mtable&quot;&gt;&lt;span class=&quot;col-align-c&quot;&gt;&lt;span class=&quot;vlist-t vlist-t2&quot;&gt;&lt;span class=&quot;vlist-r&quot;&gt;&lt;span class=&quot;vlist&quot; style=&quot;height: 1.45em;&quot;&gt;&lt;span class=&quot;&quot; style=&quot;top: -3.61em;&quot;&gt;&lt;span class=&quot;pstrut&quot; style=&quot;height: 3em;&quot;&gt;&lt;/span&gt;&lt;span class=&quot;mord&quot;&gt;&lt;span class=&quot;mord mathit&quot;&gt;a&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;span class=&quot;&quot; style=&quot;top: -2.41em;&quot;&gt;&lt;span class=&quot;pstrut&quot; style=&quot;height: 3em;&quot;&gt;&lt;/span&gt;&lt;span class=&quot;mord&quot;&gt;&lt;span class=&quot;mord mathit&quot;&gt;c&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;span class=&quot;vlist-s&quot;&gt;​&lt;/span&gt;&lt;/span&gt;&lt;span class=&quot;vlist-r&quot;&gt;&lt;span class=&quot;vlist&quot; style=&quot;height: 0.95em;&quot;&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;span class=&quot;arraycolsep&quot; style=&quot;width: 0.5em;&quot;&gt;&lt;/span&gt;&lt;span class=&quot;arraycolsep&quot; style=&quot;width: 0.5em;&quot;&gt;&lt;/span&gt;&lt;span class=&quot;col-align-c&quot;&gt;&lt;span class=&quot;vlist-t vlist-t2&quot;&gt;&lt;span class=&quot;vlist-r&quot;&gt;&lt;span class=&quot;vlist&quot; style=&quot;height: 1.45em;&quot;&gt;&lt;span class=&quot;&quot; style=&quot;top: -3.61em;&quot;&gt;&lt;span class=&quot;pstrut&quot; style=&quot;height: 3em;&quot;&gt;&lt;/span&gt;&lt;span class=&quot;mord&quot;&gt;&lt;span class=&quot;mord mathit&quot;&gt;b&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;span class=&quot;&quot; style=&quot;top: -2.41em;&quot;&gt;&lt;span class=&quot;pstrut&quot; style=&quot;height: 3em;&quot;&gt;&lt;/span&gt;&lt;span class=&quot;mord&quot;&gt;&lt;span class=&quot;mord mathit&quot;&gt;d&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;span class=&quot;vlist-s&quot;&gt;​&lt;/span&gt;&lt;/span&gt;&lt;span class=&quot;vlist-r&quot;&gt;&lt;span class=&quot;vlist&quot; style=&quot;height: 0.95em;&quot;&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;span class=&quot;mclose delimcenter&quot; style=&quot;top: 0em;&quot;&gt;&lt;span class=&quot;delimsizing size3&quot;&gt;}&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&lt;span class=&quot;note-latex&quot; style=&quot;display: none;&quot;&gt;\\begin{Bmatrix}    a &amp;amp; b \\\\    c &amp;amp; d \\end{Bmatrix}&lt;/span&gt;&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', NULL, 42, 0, 0, 0, 5, '2020-02-08 14:10:13', 1);


#
# TABLE STRUCTURE FOR: question_batch_year
#

DROP TABLE IF EXISTS `question_batch_year`;

CREATE TABLE `question_batch_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(7) unsigned NOT NULL,
  `batch_id` smallint(3) NOT NULL,
  `question_year` year(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_question_batch` (`batch_id`),
  KEY `idx_question_year` (`question_year`),
  KEY `idx_question_id` (`question_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4;

INSERT INTO `question_batch_year` (`id`, `question_id`, `batch_id`, `question_year`) VALUES (23, 1, 51, '2019');
INSERT INTO `question_batch_year` (`id`, `question_id`, `batch_id`, `question_year`) VALUES (26, 8, 56, '2020');


#
# TABLE STRUCTURE FOR: question_year
#

DROP TABLE IF EXISTS `question_year`;

CREATE TABLE `question_year` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `updateby` smallint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `question_year` (`id`, `name`, `status`, `updateby`, `created_at`) VALUES (2, '2019', 1, 0, '2020-01-25 12:31:23');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `type`, `created_at`) VALUES (1, 'Super Admin', 'system', '2020-01-16 13:53:12');
INSERT INTO `roles` (`id`, `name`, `type`, `created_at`) VALUES (2, 'Admin', 'system', '2020-01-16 13:53:12');
INSERT INTO `roles` (`id`, `name`, `type`, `created_at`) VALUES (3, 'Test', 'custom', '2020-01-16 14:20:57');
INSERT INTO `roles` (`id`, `name`, `type`, `created_at`) VALUES (4, 'content manager', 'custom', '2020-01-27 22:38:01');


#
# TABLE STRUCTURE FOR: roles_permissions
#

DROP TABLE IF EXISTS `roles_permissions`;

CREATE TABLE `roles_permissions` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` smallint(4) DEFAULT NULL,
  `perm_cat_id` smallint(4) DEFAULT NULL,
  `can_view` tinyint(1) DEFAULT NULL,
  `can_add` tinyint(1) DEFAULT NULL,
  `can_edit` tinyint(1) DEFAULT NULL,
  `can_delete` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_role_id` (`role_id`) USING BTREE,
  KEY `idx_perm_cat_id` (`perm_cat_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (1, 3, 3, 1, 0, 0, 0, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (2, 3, 4, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (3, 3, 5, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (4, 3, 6, 1, 0, 0, 0, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (5, 3, 8, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (6, 3, 9, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (7, 3, 10, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (8, 3, 11, 1, 1, 1, 1, '2020-01-18 11:05:23');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (13, 2, 6, 1, 0, 0, 0, '2020-01-18 11:05:52');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (14, 2, 8, 1, 1, 1, 1, '2020-01-18 11:05:52');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (15, 2, 9, 1, 1, 1, 1, '2020-01-18 11:05:52');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (16, 2, 10, 1, 1, 1, 1, '2020-01-18 11:05:52');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (17, 2, 11, 1, 1, 1, 1, '2020-01-18 11:05:52');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (19, 2, 13, 1, 0, 0, 0, '2020-01-18 12:34:53');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (20, 2, 14, 1, 0, 1, 0, '2020-01-18 12:34:53');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (22, 2, 16, 1, 1, 1, 0, '2020-01-21 11:49:04');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (23, 2, 17, 1, 1, 1, 0, '2020-01-21 11:49:04');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (24, 2, 18, 1, 1, 1, 0, '2020-01-21 11:49:04');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (25, 2, 3, 1, 0, 0, 0, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (26, 2, 4, 1, 1, 1, 1, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (27, 2, 5, 1, 1, 1, 1, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (28, 2, 12, 1, 1, 1, 1, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (29, 2, 15, 1, 1, 0, 0, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (30, 2, 7, 1, 0, 0, 0, '2020-01-21 13:41:00');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (31, 2, 23, 1, 1, 1, 1, '2020-01-26 11:42:17');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (32, 2, 19, 1, 0, 0, 0, '2020-01-26 11:42:51');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (33, 2, 20, 1, 1, 1, 1, '2020-01-26 11:42:51');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (34, 2, 25, 1, 0, 0, 0, '2020-01-27 14:45:07');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (35, 2, 26, 1, 1, 1, 1, '2020-01-27 14:45:07');
INSERT INTO `roles_permissions` (`id`, `role_id`, `perm_cat_id`, `can_view`, `can_add`, `can_edit`, `can_delete`, `created_at`) VALUES (36, 4, 26, 1, 1, 1, 0, '2020-01-27 22:39:47');


#
# TABLE STRUCTURE FOR: section
#

DROP TABLE IF EXISTS `section`;

CREATE TABLE `section` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `position` tinyint(3) NOT NULL DEFAULT 0,
  `updateby` smallint(4) unsigned NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_section_updateby` (`updateby`) USING BTREE,
  KEY `idx_section_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (2, 'সাহিত্য', 1, 1, 1, '2020-02-08 13:42:47');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (3, 'বাংলাদেশের জাতীয় বিষয়াবলী', 1, 0, 1, '2020-01-27 18:57:37');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (4, 'আন্তর্জাতিক নিরাপত্তা ও  আন্তরাষ্ট্রীয় ক্ষমতা সম্পর্ক', 1, 0, 1, '2020-01-21 11:57:27');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (5, 'Language', 1, 0, 0, '2020-01-27 18:36:34');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (6, 'Literature', 1, 0, 0, '2020-01-27 18:36:56');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (7, 'Arithmetic', 1, 0, 0, '2020-01-27 18:39:59');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (8, 'Algebra', 1, 0, 0, '2020-01-27 18:40:04');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (10, 'ব্যাকরণ', 1, 0, 0, '2020-01-27 23:10:07');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (11, 'বাংলাদেশের জাতীয় অর্জন', 1, 0, 0, '2020-01-27 23:12:07');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (12, 'বাংলাদেশের অর্থনীতি', 1, 0, 0, '2020-01-27 23:12:58');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (13, 'বাংলাদেশের সংবিধান', 1, 0, 0, '2020-01-27 23:13:39');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (14, 'বাংলাদেশের সরকার বাবস্থা', 1, 0, 0, '2020-01-27 23:14:25');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (15, 'আন্তর্জাতিক সংগঠন', 1, 0, 0, '2020-01-27 23:15:31');
INSERT INTO `section` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (16, 'Geometry', 1, 0, 0, '2020-01-27 23:26:25');


#
# TABLE STRUCTURE FOR: section_assign
#

DROP TABLE IF EXISTS `section_assign`;

CREATE TABLE `section_assign` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `subject_id` smallint(3) NOT NULL,
  `section_id` smallint(3) NOT NULL,
  `updateby` smallint(3) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_subject_id` (`subject_id`),
  KEY `idx_section_id` (`section_id`),
  KEY `idx_updateby` (`updateby`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (4, 3, 3, 0, '2020-01-21 12:51:07');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (8, 8, 8, 0, '2020-01-27 18:41:19');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (9, 8, 7, 0, '2020-01-27 18:41:24');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (11, 4, 5, 0, '2020-01-27 18:41:54');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (12, 4, 6, 0, '2020-01-27 18:42:02');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (13, 2, 4, 0, '2020-01-27 18:42:09');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (14, 1, 10, 0, '2020-01-27 23:17:40');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (15, 1, 2, 0, '2020-01-27 23:17:47');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (16, 2, 15, 0, '2020-01-27 23:18:52');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (17, 3, 12, 0, '2020-01-27 23:18:57');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (18, 3, 11, 0, '2020-01-27 23:19:03');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (19, 3, 13, 0, '2020-01-27 23:19:14');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (20, 3, 14, 0, '2020-01-27 23:19:21');
INSERT INTO `section_assign` (`id`, `subject_id`, `section_id`, `updateby`, `updatetime`) VALUES (21, 8, 16, 0, '2020-01-27 23:27:08');


#
# TABLE STRUCTURE FOR: subject
#

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `position` tinyint(3) NOT NULL DEFAULT 0,
  `updateby` smallint(4) unsigned NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_subject_updateby` (`updateby`) USING BTREE,
  KEY `idx_subject_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `subject` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (1, 'বাংলা ভাষা ও সাহিত্য', 1, 0, 1, '2020-01-27 18:21:16');
INSERT INTO `subject` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (2, 'আন্তর্জাতিক বিষয়াবলী', 1, 0, 0, '2020-01-21 11:54:34');
INSERT INTO `subject` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (3, 'বাংলাদেশ বিষয়াবলী', 1, 0, 0, '2020-01-21 11:55:06');
INSERT INTO `subject` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (4, 'English Language and Literature', 1, 0, 0, '2020-01-27 18:21:44');
INSERT INTO `subject` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (8, 'গাণিতিক যুক্তি', 1, 1, 1, '2020-02-08 13:50:58');


#
# TABLE STRUCTURE FOR: subject_assign
#

DROP TABLE IF EXISTS `subject_assign`;

CREATE TABLE `subject_assign` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `category_id` smallint(3) NOT NULL,
  `subject_id` smallint(3) NOT NULL,
  `updateby` smallint(3) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_subject_id` (`subject_id`),
  KEY `idx_updateby` (`updateby`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;

INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (1, 2, 1, 0, '2020-01-21 12:47:40');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (2, 1, 1, 0, '2020-01-21 12:47:40');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (22, 2, 8, 0, '2020-01-27 18:33:09');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (23, 1, 8, 0, '2020-01-27 18:33:09');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (30, 1, 3, 0, '2020-01-27 18:35:02');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (31, 3, 3, 0, '2020-01-27 18:35:02');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (32, 5, 3, 0, '2020-01-27 18:35:02');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (33, 1, 2, 0, '2020-01-27 18:35:08');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (34, 3, 2, 0, '2020-01-27 18:35:08');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (35, 5, 2, 0, '2020-01-27 18:35:08');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (36, 2, 4, 0, '2020-02-05 21:59:43');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (37, 1, 4, 0, '2020-02-05 21:59:43');
INSERT INTO `subject_assign` (`id`, `category_id`, `subject_id`, `updateby`, `updatetime`) VALUES (38, 4, 4, 0, '2020-02-05 21:59:43');


#
# TABLE STRUCTURE FOR: topic
#

DROP TABLE IF EXISTS `topic`;

CREATE TABLE `topic` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `position` tinyint(3) NOT NULL DEFAULT 0,
  `updateby` smallint(4) unsigned NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_topic_updateby` (`updateby`) USING BTREE,
  KEY `idx_topic_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (1, 'উপসর্গ', 1, 1, 1, '2020-02-08 13:55:51');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (2, 'মহাকাব্য', 1, 0, 0, '2020-01-21 11:58:01');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (3, 'প্রাচীনকাল থেকে সমসাময়িক কালের ইতিহাস কৃষ্টি ও সংস্কৃতি', 1, 0, 1, '2020-01-27 18:57:09');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (4, 'আলোচিত বিপ্লব', 1, 0, 0, '2020-01-21 11:58:28');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (5, 'The Renaissance Period(1500-1660)', 1, 0, 0, '2020-01-27 19:05:05');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (6, 'Gender', 1, 0, 0, '2020-01-27 19:06:21');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (7, 'ঐকিক নিয়ম', 1, 0, 0, '2020-01-27 21:58:45');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (8, 'adverbal', 1, 0, 1, '2020-01-27 22:29:10');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (9, 'শতকরা', 1, 0, 0, '2020-01-27 23:21:14');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (10, 'সূচক ও লগারিদম', 1, 0, 0, '2020-01-27 23:21:55');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (11, 'ত্রিকোণমিতি', 1, 0, 0, '2020-01-27 23:22:46');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (12, 'হুমায়ন আহমেদ', 1, 0, 0, '2020-01-27 23:23:57');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (13, 'জাতিসংঘ', 1, 0, 0, '2020-01-27 23:24:54');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (14, 'সংশোধনী', 1, 0, 0, '2020-01-27 23:40:46');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (15, 'সিন্ধু সভ্যতা', 1, 0, 0, '2020-01-28 10:10:01');
INSERT INTO `topic` (`id`, `name`, `status`, `position`, `updateby`, `updatetime`) VALUES (16, 'বাংলার প্রাচীন জনপদ', 1, 0, 0, '2020-01-28 10:18:44');


#
# TABLE STRUCTURE FOR: topic_assign
#

DROP TABLE IF EXISTS `topic_assign`;

CREATE TABLE `topic_assign` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `section_id` smallint(3) NOT NULL,
  `topic_id` smallint(3) NOT NULL,
  `updateby` smallint(3) NOT NULL,
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_section_id` (`section_id`),
  KEY `idx_topic_id` (`topic_id`),
  KEY `idx_updateby` (`updateby`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (6, 2, 2, 0, '2020-01-21 13:30:13');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (7, 3, 3, 0, '2020-01-21 13:30:29');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (8, 4, 4, 0, '2020-01-21 13:30:53');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (9, 5, 6, 0, '2020-01-27 19:07:44');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (10, 6, 5, 0, '2020-01-27 19:08:40');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (11, 7, 7, 0, '2020-01-27 21:59:26');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (12, 5, 8, 0, '2020-01-27 22:32:15');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (13, 2, 12, 0, '2020-01-27 23:25:28');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (14, 15, 13, 0, '2020-01-27 23:25:52');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (15, 16, 11, 0, '2020-01-27 23:27:41');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (16, 7, 9, 0, '2020-01-27 23:28:04');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (17, 8, 10, 0, '2020-01-27 23:28:14');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (18, 13, 14, 0, '2020-01-27 23:41:01');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (19, 10, 1, 0, '2020-01-28 04:27:35');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (20, 11, 15, 0, '2020-01-28 10:10:39');
INSERT INTO `topic_assign` (`id`, `section_id`, `topic_id`, `updateby`, `updatetime`) VALUES (21, 14, 16, 0, '2020-01-28 10:19:16');


#
# TABLE STRUCTURE FOR: topic_library
#

DROP TABLE IF EXISTS `topic_library`;

CREATE TABLE `topic_library` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `library_id` smallint(3) NOT NULL,
  `topic_id` smallint(3) NOT NULL,
  `category_id` smallint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_library_id` (`library_id`),
  KEY `idx_topic_id` (`topic_id`),
  KEY `idx_category_id` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;

INSERT INTO `topic_library` (`id`, `library_id`, `topic_id`, `category_id`, `created_at`) VALUES (23, 32, 1, 2, '2020-02-08 14:20:11');
INSERT INTO `topic_library` (`id`, `library_id`, `topic_id`, `category_id`, `created_at`) VALUES (24, 32, 1, 1, '2020-02-08 14:20:11');


#
# TABLE STRUCTURE FOR: topics_questions
#

DROP TABLE IF EXISTS `topics_questions`;

CREATE TABLE `topics_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(7) NOT NULL,
  `topic_id` smallint(4) NOT NULL,
  `category_id` smallint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_question_id` (`question_id`),
  KEY `idx_topic_id` (`topic_id`),
  KEY `idx_category_id` (`category_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4;

INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (46, 1, 9, 2, '2020-02-05 15:43:09');
INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (47, 1, 9, 1, '2020-02-05 15:43:09');
INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (50, 9, 11, 2, '2020-02-05 18:55:04');
INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (51, 9, 11, 1, '2020-02-05 18:55:04');
INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (59, 8, 10, 2, '2020-02-05 22:02:41');
INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (60, 8, 10, 1, '2020-02-05 22:02:41');
INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (61, 8, 11, 2, '2020-02-05 22:02:41');
INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (89, 17, 9, 2, '2020-02-08 14:10:13');
INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (90, 17, 9, 1, '2020-02-08 14:10:13');
INSERT INTO `topics_questions` (`id`, `question_id`, `topic_id`, `category_id`, `created_at`) VALUES (91, 17, 10, 2, '2020-02-08 14:10:13');


