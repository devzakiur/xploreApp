<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-10 07:15:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-10 07:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-10 07:15:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-10 07:15:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-10 12:15:32 --> Total execution time: 0.2428
DEBUG - 2020-03-10 07:15:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-10 07:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-10 07:15:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-10 07:15:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-10 12:15:47 --> Total execution time: 0.1415
DEBUG - 2020-03-10 07:16:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-10 07:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-10 07:16:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-10 07:16:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-10 12:16:01 --> Total execution time: 0.1076
