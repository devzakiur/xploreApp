   <tr>
		<td class="text-center"><?php echo $category_name; ?></td>
		<td class="text-center"><?php echo $subject_name; ?></td>
		<td class="text-center"><?php echo $section_name; ?></td>
	</tr>
