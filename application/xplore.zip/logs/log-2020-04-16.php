<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-04-16 13:34:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-16 13:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-16 13:34:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-16 13:35:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-16 13:35:01 --> Total execution time: 5.2224
DEBUG - 2020-04-16 13:35:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-16 13:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-16 13:35:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-16 13:35:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-16 13:35:05 --> Total execution time: 0.6292
DEBUG - 2020-04-16 13:35:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-16 13:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-16 17:35:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-16 17:35:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-16 17:35:20 --> Total execution time: 5.4366
