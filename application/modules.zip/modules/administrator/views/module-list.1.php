<div class="content">
    <?php $data['msg']="Welcome To Module List"; ?>
    <?php $this->load->view("message",$data) ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                <div class="panel panel-border panel-info">
                        <div class="panel-body">
                            <ul>
                                <li>Module</li>
                                <li>Dashboard</li>
                                <li>Administrator
                                    <ul>
                                        <li>Role Permission</li>
                                        <li>General </li>
                                    </ul>
                                </li>
                                <li>Administrator</li>
                            </ul>
                        </div> <!-- panel-body -->
                    </div> <!-- panel -->
                </div>
            </div>
        </div> <!-- container -->
                    
    </div>