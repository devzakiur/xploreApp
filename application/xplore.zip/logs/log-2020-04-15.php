<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-04-15 07:13:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:10 --> No URI present. Default controller set.
DEBUG - 2020-04-15 07:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:13:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-15 07:13:13 --> Total execution time: 3.5053
DEBUG - 2020-04-15 07:13:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:13:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:13:13 --> Total execution time: 0.1301
DEBUG - 2020-04-15 07:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:13:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:13:14 --> Total execution time: 0.0604
DEBUG - 2020-04-15 07:13:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:13:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:13:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 11:13:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 11:13:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:13:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:13:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:13:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:13:18 --> Total execution time: 0.2777
DEBUG - 2020-04-15 07:13:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:13:19 --> Total execution time: 0.0701
DEBUG - 2020-04-15 07:13:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:13:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 11:13:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-04-15 11:13:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:13:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:13:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:13:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:13:24 --> Total execution time: 0.2697
DEBUG - 2020-04-15 07:13:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:13:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:13:24 --> Total execution time: 0.0828
DEBUG - 2020-04-15 07:13:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:13:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 11:13:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-04-15 07:13:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:13:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:13:28 --> Total execution time: 0.1298
DEBUG - 2020-04-15 07:13:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:13:36 --> Total execution time: 0.1088
DEBUG - 2020-04-15 07:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:13:39 --> Total execution time: 0.0608
DEBUG - 2020-04-15 07:13:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:13:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 07:13:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:13:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:13:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 11:13:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-04-15 07:31:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:31:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:31:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 11:31:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-04-15 11:31:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:31:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:31:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:31:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:31:41 --> Total execution time: 0.1867
DEBUG - 2020-04-15 07:31:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:31:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:31:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:31:41 --> Total execution time: 0.0721
DEBUG - 2020-04-15 07:31:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:31:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:31:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 11:31:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-04-15 07:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:34:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:34:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 11:34:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-15 11:34:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:34:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:34:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:34:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:34:26 --> Total execution time: 0.0999
DEBUG - 2020-04-15 07:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:34:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:34:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:34:26 --> Total execution time: 0.0603
DEBUG - 2020-04-15 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:34:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:34:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 11:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-15 07:40:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:40:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 11:40:20 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 371
ERROR - 2020-04-15 11:40:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 371
ERROR - 2020-04-15 11:40:20 --> Severity: Notice --> Undefined variable: users D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 424
ERROR - 2020-04-15 11:40:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 424
DEBUG - 2020-04-15 11:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 11:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:40:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:40:20 --> Total execution time: 0.1747
DEBUG - 2020-04-15 07:40:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:40:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:40:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:40:21 --> Total execution time: 0.0765
DEBUG - 2020-04-15 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:40:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:40:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-15 11:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-15 07:41:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 11:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-15 11:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:41:34 --> Total execution time: 0.2183
DEBUG - 2020-04-15 07:41:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:41:34 --> Total execution time: 0.0831
DEBUG - 2020-04-15 07:41:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:41:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 11:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-15 07:41:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:41:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 11:41:37 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 371
ERROR - 2020-04-15 11:41:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 371
ERROR - 2020-04-15 11:41:37 --> Severity: Notice --> Undefined variable: users D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 424
ERROR - 2020-04-15 11:41:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 424
DEBUG - 2020-04-15 11:41:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 11:41:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:41:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:41:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:41:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:41:37 --> Total execution time: 0.1920
DEBUG - 2020-04-15 07:41:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:41:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:41:37 --> Total execution time: 0.0762
DEBUG - 2020-04-15 07:41:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:41:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:41:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-15 11:41:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-15 07:41:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:41:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 11:41:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-15 11:41:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:41:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:41:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:41:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:41:51 --> Total execution time: 0.0712
DEBUG - 2020-04-15 07:41:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:41:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:41:51 --> Total execution time: 0.0830
DEBUG - 2020-04-15 07:41:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:41:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:41:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:41:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 11:41:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-15 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:42:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 11:42:15 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 371
ERROR - 2020-04-15 11:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 371
ERROR - 2020-04-15 11:42:15 --> Severity: Notice --> Undefined variable: users D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 424
ERROR - 2020-04-15 11:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 424
DEBUG - 2020-04-15 11:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 11:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:42:15 --> Total execution time: 0.0780
DEBUG - 2020-04-15 07:42:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:42:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:42:15 --> Total execution time: 0.0872
DEBUG - 2020-04-15 07:42:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:42:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:42:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:42:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:42:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-15 11:42:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-15 07:42:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:42:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 11:42:43 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 11:42:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 11:42:43 --> Severity: Notice --> Undefined variable: users D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 399
ERROR - 2020-04-15 11:42:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 399
DEBUG - 2020-04-15 11:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 11:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:42:43 --> Total execution time: 0.1174
DEBUG - 2020-04-15 07:42:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:42:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:42:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:42:44 --> Total execution time: 0.0780
DEBUG - 2020-04-15 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:42:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:42:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:42:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-15 11:42:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-15 07:46:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:46:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 11:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-15 11:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:46:04 --> Total execution time: 0.1497
DEBUG - 2020-04-15 07:46:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:46:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:46:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:46:05 --> Total execution time: 0.0600
DEBUG - 2020-04-15 07:46:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:46:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:46:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:46:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:46:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 11:46:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-15 07:46:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:46:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:46:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 11:46:06 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 11:46:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 11:46:06 --> Severity: Notice --> Undefined variable: users D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 399
ERROR - 2020-04-15 11:46:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 399
DEBUG - 2020-04-15 11:46:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 11:46:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:46:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:46:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:46:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:46:06 --> Total execution time: 0.0837
DEBUG - 2020-04-15 07:46:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:46:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:46:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:46:07 --> Total execution time: 0.0593
DEBUG - 2020-04-15 07:46:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:46:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-15 11:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-15 07:46:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:46:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:46:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 11:46:49 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 11:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 11:46:49 --> Severity: Notice --> Undefined variable: users D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 399
ERROR - 2020-04-15 11:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 399
DEBUG - 2020-04-15 11:46:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 11:46:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:46:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:46:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:46:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:46:49 --> Total execution time: 0.0789
DEBUG - 2020-04-15 07:46:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:46:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:46:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:46:49 --> Total execution time: 0.0759
DEBUG - 2020-04-15 07:46:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:46:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:46:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-15 11:46:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-15 07:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:47:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:47:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 11:47:13 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 11:47:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 11:47:13 --> Severity: Notice --> Undefined variable: users D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 399
ERROR - 2020-04-15 11:47:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 399
DEBUG - 2020-04-15 11:47:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 11:47:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:47:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:47:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:47:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:47:13 --> Total execution time: 0.1674
DEBUG - 2020-04-15 07:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:47:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:47:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:47:13 --> Total execution time: 0.0959
DEBUG - 2020-04-15 07:47:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:47:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:47:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-15 11:47:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-15 07:47:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:47:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:47:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 11:47:16 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 11:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 11:47:16 --> Severity: Notice --> Undefined variable: users D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 399
ERROR - 2020-04-15 11:47:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 399
DEBUG - 2020-04-15 11:47:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 11:47:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 11:47:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 11:47:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 11:47:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 11:47:16 --> Total execution time: 0.1972
DEBUG - 2020-04-15 07:47:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:47:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 07:47:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 07:47:17 --> Total execution time: 0.1048
DEBUG - 2020-04-15 07:47:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 07:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 07:47:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 11:47:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-15 11:47:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-15 08:16:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:16:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 12:16:42 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 12:16:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
DEBUG - 2020-04-15 12:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:16:42 --> Total execution time: 0.1504
DEBUG - 2020-04-15 08:16:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:16:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:16:42 --> Total execution time: 0.0872
DEBUG - 2020-04-15 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:16:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:16:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:16:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:16:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:16:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:16:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:16:47 --> Total execution time: 0.1419
DEBUG - 2020-04-15 08:16:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:16:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:16:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 12:16:51 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 12:16:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
DEBUG - 2020-04-15 12:16:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:16:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:16:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:16:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:16:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:16:51 --> Total execution time: 0.1073
DEBUG - 2020-04-15 08:16:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:16:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:16:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:16:52 --> Total execution time: 0.1286
DEBUG - 2020-04-15 08:16:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:16:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:16:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:16:53 --> Total execution time: 0.0659
DEBUG - 2020-04-15 08:16:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:16:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:16:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:16:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:17:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:17:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:17:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 12:17:41 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 12:17:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
DEBUG - 2020-04-15 12:17:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:17:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:17:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:17:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:17:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:17:41 --> Total execution time: 0.1167
DEBUG - 2020-04-15 08:17:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:17:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:17:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:17:41 --> Total execution time: 0.0823
DEBUG - 2020-04-15 08:17:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:17:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:17:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:17:43 --> Total execution time: 0.0677
DEBUG - 2020-04-15 08:17:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:17:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:17:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:17:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:18:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 12:18:02 --> Severity: Notice --> Undefined variable: category_list D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
ERROR - 2020-04-15 12:18:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 346
DEBUG - 2020-04-15 12:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:18:02 --> Total execution time: 0.0998
DEBUG - 2020-04-15 08:18:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:18:02 --> Total execution time: 0.1042
DEBUG - 2020-04-15 08:18:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:18:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:18:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:18:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:18:34 --> Total execution time: 0.1256
DEBUG - 2020-04-15 08:18:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:18:34 --> Total execution time: 0.1211
DEBUG - 2020-04-15 08:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:18:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:18:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:18:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:18:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:18:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:18:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:18:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:18:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:18:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:18:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:18:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:18:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:18:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:18:52 --> Total execution time: 0.0774
DEBUG - 2020-04-15 08:18:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:18:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:18:52 --> Total execution time: 0.1123
DEBUG - 2020-04-15 08:18:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:18:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:18:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:18:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:20:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:20:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:20:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:20:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:20:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:20:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:20:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:20:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:20:30 --> Total execution time: 0.1098
DEBUG - 2020-04-15 08:20:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:20:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:20:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:20:30 --> Total execution time: 0.0814
DEBUG - 2020-04-15 08:20:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:20:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:20:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:20:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:21:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:21:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:21:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:21:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:21:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:21:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:21:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:21:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:21:13 --> Total execution time: 0.1327
DEBUG - 2020-04-15 08:21:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:21:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:21:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:21:13 --> Total execution time: 0.0915
DEBUG - 2020-04-15 08:21:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:21:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:21:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:21:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:22:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:22:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:22:36 --> Total execution time: 0.1375
DEBUG - 2020-04-15 08:22:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:22:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:22:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:22:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:22:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:22:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:22:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:22:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:22:39 --> Total execution time: 0.0734
DEBUG - 2020-04-15 08:22:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:22:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:22:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:22:39 --> Total execution time: 0.1018
DEBUG - 2020-04-15 08:22:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:22:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:22:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:22:40 --> Total execution time: 0.0758
DEBUG - 2020-04-15 08:22:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:22:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:22:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:22:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:23:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:23:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:23:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:23:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:23:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 12:23:47 --> Query error: Unknown column 'cover_image' in 'field list' - Invalid query: INSERT INTO `news` (`title`, `category_id`, `is_popular`, `details`, `cover_image`) VALUES ('test', '2', '1', '&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus vestibulum dapibus iaculis. Nullam euismod risus at nisl condimentum, vitae posuere velit ornare. Nunc dolor lectus, aliquet in velit at, tempus volutpat velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur vel luctus turpis, eu dignissim nisi. Fusce a nulla vitae ipsum lobortis auctor. Sed semper, nulla semper fermentum ultrices, diam leo egestas velit, at vulputate nunc felis at quam. Duis consectetur accumsan est.&lt;br&gt;&lt;/p&gt;', 'uploads/news/coverimage/Xplore_1586931827C.jpg')
DEBUG - 2020-04-15 12:23:47 --> DB Transaction Failure
DEBUG - 2020-04-15 08:23:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:23:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:23:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:23:50 --> Total execution time: 0.0991
DEBUG - 2020-04-15 08:23:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:23:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:23:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 12:23:55 --> Query error: Unknown column 'cover_image' in 'field list' - Invalid query: INSERT INTO `news` (`title`, `category_id`, `is_popular`, `details`, `cover_image`) VALUES ('test', '2', '1', '&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus vestibulum dapibus iaculis. Nullam euismod risus at nisl condimentum, vitae posuere velit ornare. Nunc dolor lectus, aliquet in velit at, tempus volutpat velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Curabitur vel luctus turpis, eu dignissim nisi. Fusce a nulla vitae ipsum lobortis auctor. Sed semper, nulla semper fermentum ultrices, diam leo egestas velit, at vulputate nunc felis at quam. Duis consectetur accumsan est.&lt;br&gt;&lt;/p&gt;', 'uploads/news/coverimage/Xplore_1586931835C.jpg')
DEBUG - 2020-04-15 12:23:55 --> DB Transaction Failure
DEBUG - 2020-04-15 08:24:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:24:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:24:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 08:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:24:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:24:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:24:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:24:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:24:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:24:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:24:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:24:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:24:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:24:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:24:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:24:32 --> Total execution time: 0.0744
DEBUG - 2020-04-15 08:24:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:24:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:24:33 --> Total execution time: 0.0827
DEBUG - 2020-04-15 08:24:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:24:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:24:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:24:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:25:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:25:16 --> Total execution time: 0.0757
DEBUG - 2020-04-15 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:25:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:25:16 --> Total execution time: 0.0822
DEBUG - 2020-04-15 08:25:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:25:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:25:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:25:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:25:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:25:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:25:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:25:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:25:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:25:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:25:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:25:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:25:35 --> Total execution time: 0.1058
DEBUG - 2020-04-15 08:25:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:25:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:25:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:25:35 --> Total execution time: 0.0779
DEBUG - 2020-04-15 08:25:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:25:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:25:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:25:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:25:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:25:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:25:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:25:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:25:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:25:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:25:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:25:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:25:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:25:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:25:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:25:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:25:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:25:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:25:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:25:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:25:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:25:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:25:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:26:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:26:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:26:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:26:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:26:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:26:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:26:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:26:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:26:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:26:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:26:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:26:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:26:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:26:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:26:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:28:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:28:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:28:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:28:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:28:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:28:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:28:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:28:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:28:14 --> Total execution time: 0.1147
DEBUG - 2020-04-15 08:28:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:28:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:28:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:28:14 --> Total execution time: 0.0790
DEBUG - 2020-04-15 08:28:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:28:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:28:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:28:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:37:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:37:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:37:24 --> Total execution time: 0.1142
DEBUG - 2020-04-15 08:37:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:37:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:37:24 --> Total execution time: 0.0947
DEBUG - 2020-04-15 08:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:37:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:37:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:37:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:39:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:39:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:39:01 --> Total execution time: 0.1189
DEBUG - 2020-04-15 08:39:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:39:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:39:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:39:01 --> Total execution time: 0.0883
DEBUG - 2020-04-15 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:39:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:39:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:39:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:40:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:40:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:40:11 --> Total execution time: 0.0790
DEBUG - 2020-04-15 08:40:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:40:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:40:11 --> Total execution time: 0.0709
DEBUG - 2020-04-15 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:40:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:40:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:40:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:41:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:41:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:41:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:41:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:41:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:41:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:41:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:41:01 --> Total execution time: 0.0791
DEBUG - 2020-04-15 08:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:41:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:41:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:41:01 --> Total execution time: 0.0758
DEBUG - 2020-04-15 08:41:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:41:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:41:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:41:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:42:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:42:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:42:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:42:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:42:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:42:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:42:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:42:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:42:26 --> Total execution time: 0.1278
DEBUG - 2020-04-15 08:42:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:42:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:42:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:42:26 --> Total execution time: 0.0848
DEBUG - 2020-04-15 08:42:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:42:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:42:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:42:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:45:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:45:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:45:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:45:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:45:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:45:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:45:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:45:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:45:02 --> Total execution time: 0.0753
DEBUG - 2020-04-15 08:45:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:45:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:45:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:45:03 --> Total execution time: 0.1167
DEBUG - 2020-04-15 08:45:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:45:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:45:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:45:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:45:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:45:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:45:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:45:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:45:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:45:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:45:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:45:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:45:30 --> Total execution time: 0.0766
DEBUG - 2020-04-15 08:45:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:45:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:45:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:45:31 --> Total execution time: 0.0925
DEBUG - 2020-04-15 08:45:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:45:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:45:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:45:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:46:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:46:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:46:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:46:33 --> Total execution time: 0.0816
DEBUG - 2020-04-15 08:46:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:46:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:46:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:46:34 --> Total execution time: 0.0922
DEBUG - 2020-04-15 08:46:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:46:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:46:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:46:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:46:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:46:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:46:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:46:40 --> Total execution time: 0.1291
DEBUG - 2020-04-15 08:46:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:46:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:46:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:46:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:46:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:46:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:46:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:46:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:46:46 --> Total execution time: 0.0781
DEBUG - 2020-04-15 08:46:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:46:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:46:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:46:46 --> Total execution time: 0.0866
DEBUG - 2020-04-15 08:46:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:46:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:46:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:46:47 --> Total execution time: 0.0617
DEBUG - 2020-04-15 08:46:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:46:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:46:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:46:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:47:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:47:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:47:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:47:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:47:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:47:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:47:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:47:27 --> Total execution time: 0.1096
DEBUG - 2020-04-15 08:47:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:47:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:47:27 --> Total execution time: 0.1061
DEBUG - 2020-04-15 08:47:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:47:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:47:29 --> Total execution time: 0.0680
DEBUG - 2020-04-15 08:47:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:47:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:47:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:47:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:47:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:47:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:47:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:47:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:47:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:47:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:47:43 --> Total execution time: 0.1297
DEBUG - 2020-04-15 08:47:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:47:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:47:44 --> Total execution time: 0.0892
DEBUG - 2020-04-15 08:47:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:47:45 --> Total execution time: 0.0616
DEBUG - 2020-04-15 08:47:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:47:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:47:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:47:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:47:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:47:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:47:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:47:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:47:51 --> Total execution time: 0.1149
DEBUG - 2020-04-15 08:47:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:47:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:47:52 --> Total execution time: 0.0925
DEBUG - 2020-04-15 08:47:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:47:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:47:53 --> Total execution time: 0.0585
DEBUG - 2020-04-15 08:47:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:47:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:47:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:47:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:48:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:48:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:48:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:48:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:48:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:48:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:48:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:48:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:48:58 --> Total execution time: 0.0786
DEBUG - 2020-04-15 08:48:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:48:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:48:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:48:59 --> Total execution time: 0.1353
DEBUG - 2020-04-15 08:49:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:49:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:49:00 --> Total execution time: 0.0712
DEBUG - 2020-04-15 08:49:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:49:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:49:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:49:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:49:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 08:49:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:49:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:49:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:49:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 12:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 12:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:49:40 --> Total execution time: 0.1385
DEBUG - 2020-04-15 08:49:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:49:40 --> Total execution time: 0.1008
DEBUG - 2020-04-15 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:49:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:49:41 --> Total execution time: 0.0964
DEBUG - 2020-04-15 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:49:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:49:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:49:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:49:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:49:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:49:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:49:46 --> Total execution time: 0.0734
DEBUG - 2020-04-15 08:49:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:49:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:49:47 --> Total execution time: 0.1004
DEBUG - 2020-04-15 08:49:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:49:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:49:48 --> Total execution time: 0.0600
DEBUG - 2020-04-15 08:49:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:49:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:49:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:49:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:49:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:49:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 08:50:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:50:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:50:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:50:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:55:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:55:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:55:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:55:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:55:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:55:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:55:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:55:39 --> Total execution time: 0.1413
DEBUG - 2020-04-15 08:55:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:55:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:55:40 --> Total execution time: 0.0922
DEBUG - 2020-04-15 08:55:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:55:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:55:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:55:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:55:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 08:55:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:55:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:55:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:55:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:55:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:55:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:55:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:55:47 --> Total execution time: 0.0788
DEBUG - 2020-04-15 08:55:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:55:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:55:48 --> Total execution time: 0.0772
DEBUG - 2020-04-15 08:55:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:55:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:55:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:55:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 08:55:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:55:51 --> Total execution time: 0.0801
DEBUG - 2020-04-15 08:55:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:55:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:55:52 --> Total execution time: 0.0812
DEBUG - 2020-04-15 08:55:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:55:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:55:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:55:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:55:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:55:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:55:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:55:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:55:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:55:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:55:55 --> Total execution time: 0.0821
DEBUG - 2020-04-15 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:55:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:55:55 --> Total execution time: 0.0867
DEBUG - 2020-04-15 08:55:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:55:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:55:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:55:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:56:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:56:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:56:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:56:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:56:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:56:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:56:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:56:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:56:22 --> Total execution time: 0.0800
DEBUG - 2020-04-15 08:56:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:56:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:56:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:56:22 --> Total execution time: 0.0903
DEBUG - 2020-04-15 08:56:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:56:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:56:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:56:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:57:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:57:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:57:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:57:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:57:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:57:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:57:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:57:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:57:51 --> Total execution time: 0.0927
DEBUG - 2020-04-15 08:57:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:57:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:57:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:57:51 --> Total execution time: 0.0815
DEBUG - 2020-04-15 08:57:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:57:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:57:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:57:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:57:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:57:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:57:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:57:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:57:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:57:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:57:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:57:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:57:56 --> Total execution time: 0.0729
DEBUG - 2020-04-15 08:57:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:57:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:57:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:57:57 --> Total execution time: 0.0769
DEBUG - 2020-04-15 08:57:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:57:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:57:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:57:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:58:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:58:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:58:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:58:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:58:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:58:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:58:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:58:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:58:47 --> Total execution time: 0.0738
DEBUG - 2020-04-15 08:58:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:58:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:58:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:58:47 --> Total execution time: 0.0967
DEBUG - 2020-04-15 08:58:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:58:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:58:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:58:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:59:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:59:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:59:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:59:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:59:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:59:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:59:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:59:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:59:03 --> Total execution time: 0.1335
DEBUG - 2020-04-15 08:59:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:59:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:59:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:59:03 --> Total execution time: 0.0917
DEBUG - 2020-04-15 08:59:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:59:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:59:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:59:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 08:59:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:59:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:59:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:59:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 12:59:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 12:59:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 12:59:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 12:59:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 12:59:43 --> Total execution time: 0.1106
DEBUG - 2020-04-15 08:59:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:59:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 08:59:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 08:59:44 --> Total execution time: 0.0944
DEBUG - 2020-04-15 08:59:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 08:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 08:59:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:59:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 12:59:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:00:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:00:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:00:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:00:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:00:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:00:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:00:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:00:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:00:10 --> Total execution time: 0.0975
DEBUG - 2020-04-15 09:00:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:00:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:00:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:00:11 --> Total execution time: 0.0844
DEBUG - 2020-04-15 09:00:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:00:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:00:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:00:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:01:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:01:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:01:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:01:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:01:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:01:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:01:27 --> Total execution time: 0.1252
DEBUG - 2020-04-15 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:01:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:01:27 --> Total execution time: 0.0834
DEBUG - 2020-04-15 09:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:01:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:01:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:01:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:01:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:01:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:01:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:01:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:01:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:01:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:01:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:01:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:01:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:01:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:01:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:01:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:01:34 --> Total execution time: 0.0801
DEBUG - 2020-04-15 09:01:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:01:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:01:35 --> Total execution time: 0.0888
DEBUG - 2020-04-15 09:01:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:01:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:01:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:01:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:01:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:01:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:01:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:01:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:01:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:01:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:01:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:01:49 --> Total execution time: 0.1593
DEBUG - 2020-04-15 09:01:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:01:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:01:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:01:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:01:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:01:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:02:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:02:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:02:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:02:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:03:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:03:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:03:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:03:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:03:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:03:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:03:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:03:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:03:16 --> Total execution time: 0.0986
DEBUG - 2020-04-15 09:03:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:03:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:03:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:03:16 --> Total execution time: 0.1183
DEBUG - 2020-04-15 09:03:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:03:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:03:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:03:17 --> Total execution time: 0.0672
DEBUG - 2020-04-15 09:03:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:03:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:03:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:03:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:03:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:03:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:03:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:03:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:03:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:03:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:03:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:03:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:03:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:03:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:03:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:03:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:03:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:03:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:03:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:03:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:04:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:04:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:04:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:04:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:04:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:04:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:04:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:04:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:04:16 --> Total execution time: 0.0945
DEBUG - 2020-04-15 09:04:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:04:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:04:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:04:17 --> Total execution time: 0.1345
DEBUG - 2020-04-15 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:04:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:04:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:04:18 --> Total execution time: 0.0779
DEBUG - 2020-04-15 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:04:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:04:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:04:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:04:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:04:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:04:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:04:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:06:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:06:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:06:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:06:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:06:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:06:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:06:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:06:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:06:50 --> Total execution time: 0.1317
DEBUG - 2020-04-15 09:06:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:06:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:06:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:06:51 --> Total execution time: 0.0945
DEBUG - 2020-04-15 09:06:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:06:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:06:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:06:52 --> Total execution time: 0.0780
DEBUG - 2020-04-15 09:06:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:06:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:06:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:06:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:06:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:06:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:06:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:06:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:06:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:06:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:06:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:06:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:07:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:07:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:07:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:11:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:11:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:11:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:11:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:11:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:11:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:11:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:11:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:11:00 --> Total execution time: 0.0777
DEBUG - 2020-04-15 09:11:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:11:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:11:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:11:01 --> Total execution time: 0.0948
DEBUG - 2020-04-15 09:11:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:11:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:11:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:11:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:11:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:11:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:11:03 --> Severity: Notice --> Undefined variable: category_name D:\shipan7.2\htdocs\xplore\application\modules\news\views\news-details.php 4
ERROR - 2020-04-15 13:11:03 --> Severity: Notice --> Undefined variable: title D:\shipan7.2\htdocs\xplore\application\modules\news\views\news-details.php 8
ERROR - 2020-04-15 13:11:03 --> Severity: Notice --> Undefined variable: cover_image D:\shipan7.2\htdocs\xplore\application\modules\news\views\news-details.php 10
ERROR - 2020-04-15 13:11:03 --> Severity: Notice --> Undefined variable: details D:\shipan7.2\htdocs\xplore\application\modules\news\views\news-details.php 19
DEBUG - 2020-04-15 13:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-details.php
DEBUG - 2020-04-15 09:12:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:12:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:12:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:12:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:12:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:12:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:12:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:12:00 --> Total execution time: 0.1305
DEBUG - 2020-04-15 09:12:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:12:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:12:01 --> Total execution time: 0.0860
DEBUG - 2020-04-15 09:12:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:12:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:12:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:12:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:12:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:12:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:12:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:12:06 --> Total execution time: 0.1277
DEBUG - 2020-04-15 09:12:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:12:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:12:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:12:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:12:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:12:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:12:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:12:19 --> Total execution time: 0.0812
DEBUG - 2020-04-15 09:12:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:12:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:12:20 --> Total execution time: 0.1656
DEBUG - 2020-04-15 09:12:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:12:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:12:21 --> Total execution time: 0.0835
DEBUG - 2020-04-15 09:12:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:12:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:12:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:12:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:12:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:12:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:12:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:12:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:12:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:12:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:12:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:12:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:12:42 --> Total execution time: 0.0936
DEBUG - 2020-04-15 09:12:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:12:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:12:42 --> Total execution time: 0.1072
DEBUG - 2020-04-15 09:12:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:12:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:12:43 --> Total execution time: 0.0624
DEBUG - 2020-04-15 09:12:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:12:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:12:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:12:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:12:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:12:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:13:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:13:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:13:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:13:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-details.php
DEBUG - 2020-04-15 09:13:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:13:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:13:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:13:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-details.php
DEBUG - 2020-04-15 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:13:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-details.php
DEBUG - 2020-04-15 09:13:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:13:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:13:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:13:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-details.php
DEBUG - 2020-04-15 09:13:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:13:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:13:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:13:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-details.php
DEBUG - 2020-04-15 09:13:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:13:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:13:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:13:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-details.php
DEBUG - 2020-04-15 09:13:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:13:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:13:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:13:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:13:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:13:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:13:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:13:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:13:50 --> Total execution time: 0.0852
DEBUG - 2020-04-15 09:13:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:13:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:13:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:13:50 --> Total execution time: 0.0831
DEBUG - 2020-04-15 09:13:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:13:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:13:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:13:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:13:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:13:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:13:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:13:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-details.php
DEBUG - 2020-04-15 09:13:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:13:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:13:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:13:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-details.php
DEBUG - 2020-04-15 09:14:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:14:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:14:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:14:31 --> Severity: Notice --> Undefined property: News::$category D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 482
ERROR - 2020-04-15 13:14:31 --> Severity: error --> Exception: Call to a member function duplicate_check() on null D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 482
DEBUG - 2020-04-15 09:14:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:14:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:14:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:14:37 --> Total execution time: 0.0996
DEBUG - 2020-04-15 09:14:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:14:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:14:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:14:41 --> Severity: Notice --> Undefined property: News::$category D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 482
ERROR - 2020-04-15 13:14:41 --> Severity: error --> Exception: Call to a member function duplicate_check() on null D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 482
DEBUG - 2020-04-15 09:15:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:15:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:15:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:15:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:15:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:15:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:15:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:15:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:15:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:15:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:15:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:15:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:15:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:15:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:15:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-details.php
DEBUG - 2020-04-15 09:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:24:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:24:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:24:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:24:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:24:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:24:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:24:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:24:29 --> Total execution time: 0.1405
DEBUG - 2020-04-15 09:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:24:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:24:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:24:29 --> Total execution time: 0.0898
DEBUG - 2020-04-15 09:24:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:24:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:24:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:24:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:24:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:24:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:24:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:24:32 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 145
DEBUG - 2020-04-15 09:25:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:25:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:25:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:25:07 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 192
DEBUG - 2020-04-15 09:25:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:25:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:25:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:25:22 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 09:25:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:25:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:25:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:25:42 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 09:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:26:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:26:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:26:39 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 09:26:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:26:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:26:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:26:48 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 09:27:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:27:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:27:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:27:34 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 513
DEBUG - 2020-04-15 09:27:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:27:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:27:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:27:36 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 513
DEBUG - 2020-04-15 09:27:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:27:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:27:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:27:38 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 513
DEBUG - 2020-04-15 09:27:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:27:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:27:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:27:45 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 09:28:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:28:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:28:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:29:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:29:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:29:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:29:21 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 09:29:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:29:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:29:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:29:32 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 09:29:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:29:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:29:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:29:54 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 09:29:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:29:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:29:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:29:56 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:30:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:30:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:30:08 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 09:30:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:30:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:30:32 --> Severity: Notice --> Undefined property: News::$data D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 225
ERROR - 2020-04-15 13:30:32 --> Severity: Notice --> Undefined variable: category D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 333
ERROR - 2020-04-15 13:30:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 333
DEBUG - 2020-04-15 13:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:30:32 --> Total execution time: 0.0822
DEBUG - 2020-04-15 09:30:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:30:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:30:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 145
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Trying to get property 'id' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 145
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: category D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 152
ERROR - 2020-04-15 13:30:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 152
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 163
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Trying to get property 'title' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 163
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 164
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Trying to get property 'id' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 164
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 170
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Trying to get property 'date' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 170
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 176
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Trying to get property 'cover_image' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 176
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 184
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Trying to get property 'is_popular' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 184
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 185
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Trying to get property 'is_popular' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 185
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 192
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Trying to get property 'details' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 192
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: category D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 333
ERROR - 2020-04-15 13:30:55 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 333
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: video_code D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 623
ERROR - 2020-04-15 13:30:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 623
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: image_slide D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 676
ERROR - 2020-04-15 13:30:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 676
ERROR - 2020-04-15 13:30:55 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 13:30:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:30:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:30:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:30:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:30:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:30:55 --> Total execution time: 0.1473
DEBUG - 2020-04-15 09:31:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:31:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:31:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 145
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Trying to get property 'id' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 145
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: category D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 152
ERROR - 2020-04-15 13:31:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 152
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 163
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Trying to get property 'title' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 163
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 164
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Trying to get property 'id' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 164
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 170
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Trying to get property 'date' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 170
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 176
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Trying to get property 'cover_image' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 176
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 184
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Trying to get property 'is_popular' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 184
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 185
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Trying to get property 'is_popular' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 185
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 192
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Trying to get property 'details' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 192
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: category D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 333
ERROR - 2020-04-15 13:31:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 333
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: video_code D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 623
ERROR - 2020-04-15 13:31:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 623
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: image_slide D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 676
ERROR - 2020-04-15 13:31:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 676
ERROR - 2020-04-15 13:31:04 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 13:31:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:31:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:31:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:31:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:31:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:31:04 --> Total execution time: 0.2138
DEBUG - 2020-04-15 09:31:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:31:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:31:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:31:05 --> Total execution time: 0.0964
DEBUG - 2020-04-15 09:31:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:31:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:31:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:31:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:31:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:31:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:31:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 145
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Trying to get property 'id' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 145
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: category D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 152
ERROR - 2020-04-15 13:31:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 152
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 163
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Trying to get property 'title' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 163
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 164
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Trying to get property 'id' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 164
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 170
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Trying to get property 'date' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 170
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 176
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Trying to get property 'cover_image' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 176
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 184
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Trying to get property 'is_popular' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 184
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 185
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Trying to get property 'is_popular' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 185
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 192
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Trying to get property 'details' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 192
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: category D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 333
ERROR - 2020-04-15 13:31:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 333
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: video_code D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 623
ERROR - 2020-04-15 13:31:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 623
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: image_slide D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 676
ERROR - 2020-04-15 13:31:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 676
ERROR - 2020-04-15 13:31:12 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 13:31:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:31:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:31:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:31:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:31:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:31:12 --> Total execution time: 0.1085
DEBUG - 2020-04-15 09:31:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:31:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:31:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:31:13 --> Total execution time: 0.0980
DEBUG - 2020-04-15 09:31:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:31:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:31:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:31:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:31:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:31:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:31:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:31:19 --> Severity: Notice --> Undefined variable: category D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 152
ERROR - 2020-04-15 13:31:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 152
ERROR - 2020-04-15 13:31:19 --> Severity: Notice --> Undefined variable: category D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 333
ERROR - 2020-04-15 13:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 333
ERROR - 2020-04-15 13:31:19 --> Severity: Notice --> Undefined variable: video_code D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 623
ERROR - 2020-04-15 13:31:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 623
ERROR - 2020-04-15 13:31:19 --> Severity: Notice --> Undefined variable: image_slide D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 676
ERROR - 2020-04-15 13:31:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 676
ERROR - 2020-04-15 13:31:19 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 09:31:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:31:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:31:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 145
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Trying to get property 'id' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 145
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 154
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Trying to get property 'category_id' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 154
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 163
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Trying to get property 'title' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 163
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 164
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Trying to get property 'id' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 164
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 170
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Trying to get property 'date' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 170
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 176
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Trying to get property 'cover_image' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 176
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 184
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Trying to get property 'is_popular' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 184
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 185
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Trying to get property 'is_popular' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 185
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 192
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Trying to get property 'details' of non-object D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 192
ERROR - 2020-04-15 13:31:29 --> Severity: Notice --> Undefined variable: single D:\shipan7.2\htdocs\xplore\application\modules\news\views\index.php 703
DEBUG - 2020-04-15 13:31:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:31:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:31:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:31:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:31:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:31:29 --> Total execution time: 0.1579
DEBUG - 2020-04-15 09:31:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:31:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:31:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:31:29 --> Total execution time: 0.1073
DEBUG - 2020-04-15 09:31:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:31:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:31:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:31:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:32:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:32:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:32:07 --> Total execution time: 0.0834
DEBUG - 2020-04-15 09:32:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:32:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:32:07 --> Total execution time: 0.0828
DEBUG - 2020-04-15 09:32:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:32:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:32:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:32:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:32:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:32:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:32:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:32:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:32:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:32:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:32:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:32:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:32:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:32:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:32:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:32:37 --> Total execution time: 0.0843
DEBUG - 2020-04-15 09:32:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:32:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:32:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:32:37 --> Total execution time: 0.1058
DEBUG - 2020-04-15 09:32:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:32:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:32:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:32:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:33:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:33:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:33:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:33:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:33:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:33:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:33:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:33:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:33:51 --> Total execution time: 0.0859
DEBUG - 2020-04-15 09:33:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:33:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:33:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:33:51 --> Total execution time: 0.0883
DEBUG - 2020-04-15 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:33:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:33:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:33:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:33:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:33:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:34:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:34:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:34:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:34:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:34:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:34:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:34:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:34:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:34:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:34:01 --> Total execution time: 0.0738
DEBUG - 2020-04-15 09:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:34:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:34:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:34:01 --> Total execution time: 0.0866
DEBUG - 2020-04-15 09:34:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:34:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:34:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:34:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:35:23 --> Total execution time: 0.1463
DEBUG - 2020-04-15 09:35:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:35:23 --> Total execution time: 0.0867
DEBUG - 2020-04-15 09:35:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:35:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:35:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:35:35 --> Total execution time: 0.0883
DEBUG - 2020-04-15 09:35:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:35:35 --> Total execution time: 0.0725
DEBUG - 2020-04-15 09:35:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:35:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:35:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:35:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:35:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:35:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:35:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:35:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:35:39 --> Total execution time: 0.0800
DEBUG - 2020-04-15 09:35:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:35:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:35:39 --> Total execution time: 0.0831
DEBUG - 2020-04-15 09:35:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:35:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:35:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:35:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:35:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:35:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:35:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:35:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:35:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:35:46 --> Total execution time: 0.0828
DEBUG - 2020-04-15 09:35:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:35:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:35:47 --> Total execution time: 0.0987
DEBUG - 2020-04-15 09:35:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:35:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:35:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:35:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:35:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:35:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:35:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:35:50 --> Total execution time: 0.0872
DEBUG - 2020-04-15 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:35:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:35:50 --> Total execution time: 0.1030
DEBUG - 2020-04-15 09:35:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:35:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:35:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:35:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:36:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:36:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:36:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:36:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:36:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:36:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:36:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:36:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:36:43 --> Total execution time: 0.1040
DEBUG - 2020-04-15 09:36:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:36:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:36:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:36:43 --> Total execution time: 0.0874
DEBUG - 2020-04-15 09:36:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:36:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:36:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:36:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:37:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:37:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:37:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:37:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:37:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:37:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:37:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:37:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:37:10 --> Total execution time: 0.0894
DEBUG - 2020-04-15 09:37:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:37:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:37:10 --> Total execution time: 0.0937
DEBUG - 2020-04-15 09:37:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:37:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:37:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:37:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:37:31 --> Total execution time: 0.1105
DEBUG - 2020-04-15 09:37:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:37:31 --> Total execution time: 0.1301
DEBUG - 2020-04-15 09:37:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:37:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:37:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:37:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:37:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:37:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:37:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:37:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:37:37 --> Total execution time: 0.0855
DEBUG - 2020-04-15 09:37:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:37:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:37:37 --> Total execution time: 0.1047
DEBUG - 2020-04-15 09:37:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:37:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:37:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:37:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:37:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:37:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:37:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:37:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:37:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:37:48 --> Total execution time: 0.1489
DEBUG - 2020-04-15 09:37:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:37:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:37:48 --> Total execution time: 0.0948
DEBUG - 2020-04-15 09:37:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:37:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:37:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:37:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:37:53 --> Total execution time: 0.0810
DEBUG - 2020-04-15 09:37:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:37:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:37:54 --> Total execution time: 0.0991
DEBUG - 2020-04-15 09:37:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:37:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:37:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:37:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:38:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:38:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:38:11 --> Total execution time: 0.1259
DEBUG - 2020-04-15 09:38:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:38:11 --> Total execution time: 0.0645
DEBUG - 2020-04-15 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:38:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:38:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:38:15 --> Total execution time: 0.1071
DEBUG - 2020-04-15 09:38:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:38:15 --> Total execution time: 0.1000
DEBUG - 2020-04-15 09:38:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:38:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:38:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:38:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:38:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:38:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:38:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:38:21 --> Total execution time: 0.0812
DEBUG - 2020-04-15 09:38:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:38:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:38:21 --> Total execution time: 0.0848
DEBUG - 2020-04-15 09:38:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:38:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:38:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 09:38:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:38:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:38:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:38:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:38:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:38:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:38:27 --> Total execution time: 0.0835
DEBUG - 2020-04-15 09:38:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:38:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:38:28 --> Total execution time: 0.0959
DEBUG - 2020-04-15 09:38:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:38:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:38:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:38:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:38:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:38:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:38:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:38:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:38:54 --> Total execution time: 0.0911
DEBUG - 2020-04-15 09:38:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:38:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:38:54 --> Total execution time: 0.0857
DEBUG - 2020-04-15 09:38:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:38:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:38:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:38:59 --> Total execution time: 0.0722
DEBUG - 2020-04-15 09:38:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:38:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:38:59 --> Total execution time: 0.0898
DEBUG - 2020-04-15 09:39:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:39:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:39:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:39:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:39:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:39:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-15 13:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:39:02 --> Total execution time: 0.0791
DEBUG - 2020-04-15 09:39:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:39:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:39:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:39:03 --> Total execution time: 0.0891
DEBUG - 2020-04-15 09:39:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:39:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:39:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:39:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:39:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:39:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-15 09:39:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:39:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:39:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:39:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 13:39:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:39:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:39:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:39:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:39:08 --> Total execution time: 0.0780
DEBUG - 2020-04-15 09:39:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:39:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:39:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:39:08 --> Total execution time: 0.0807
DEBUG - 2020-04-15 09:39:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:39:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:39:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 13:39:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 09:54:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:54:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 13:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 13:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:54:54 --> Total execution time: 0.1630
DEBUG - 2020-04-15 09:54:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:54:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:54:54 --> Total execution time: 0.1010
DEBUG - 2020-04-15 09:54:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:54:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:54:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 13:54:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-04-15 13:54:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:54:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:54:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:54:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:54:57 --> Total execution time: 0.1478
DEBUG - 2020-04-15 09:54:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:54:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:54:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:54:57 --> Total execution time: 0.0904
DEBUG - 2020-04-15 09:54:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:54:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:54:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 13:54:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-04-15 09:55:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:55:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:55:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:55:00 --> Total execution time: 0.1436
DEBUG - 2020-04-15 09:55:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:55:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:55:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 09:55:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:55:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:55:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 13:55:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-04-15 09:55:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:55:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:55:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 09:55:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:55:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:55:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 13:55:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-04-15 09:55:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:55:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:55:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 09:55:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:55:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:55:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 13:55:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-04-15 09:55:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:55:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:55:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 09:55:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:55:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:55:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 13:55:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-04-15 09:55:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:55:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:55:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:55:25 --> Total execution time: 0.1193
DEBUG - 2020-04-15 09:57:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 13:57:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-04-15 13:57:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:57:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:57:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:57:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:57:18 --> Total execution time: 0.1140
DEBUG - 2020-04-15 09:57:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:57:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:57:18 --> Total execution time: 0.0939
DEBUG - 2020-04-15 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 13:57:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 09:57:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:57:20 --> Total execution time: 0.2166
DEBUG - 2020-04-15 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:22 --> Total execution time: 0.0764
DEBUG - 2020-04-15 09:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 09:57:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 13:57:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 09:57:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 09:57:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 13:57:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 09:57:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:30 --> Total execution time: 0.0738
DEBUG - 2020-04-15 09:57:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/index.php
DEBUG - 2020-04-15 13:57:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:57:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:57:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:57:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:57:38 --> Total execution time: 0.0864
DEBUG - 2020-04-15 09:57:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:57:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:57:38 --> Total execution time: 0.0837
DEBUG - 2020-04-15 09:57:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:57:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-04-15 09:57:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 13:57:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-04-15 13:57:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:57:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:57:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:57:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:57:45 --> Total execution time: 0.1244
DEBUG - 2020-04-15 09:57:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:57:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:57:46 --> Total execution time: 0.0956
DEBUG - 2020-04-15 09:57:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 13:57:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-04-15 09:57:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 13:57:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-04-15 13:57:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 13:57:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 13:57:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 13:57:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 13:57:47 --> Total execution time: 0.0926
DEBUG - 2020-04-15 09:57:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 09:57:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 09:57:47 --> Total execution time: 0.0888
DEBUG - 2020-04-15 09:57:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 09:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 09:57:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 13:57:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 13:57:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 10:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:12:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:12:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:12:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-04-15 14:12:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:12:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:12:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:12:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:12:39 --> Total execution time: 0.1256
DEBUG - 2020-04-15 10:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:12:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:12:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:12:39 --> Total execution time: 0.0922
DEBUG - 2020-04-15 10:12:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:12:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:12:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:12:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 10:13:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-04-15 14:13:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:13:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:13:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:13:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:13:15 --> Total execution time: 0.0859
DEBUG - 2020-04-15 10:13:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:13:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:13:15 --> Total execution time: 0.0871
DEBUG - 2020-04-15 10:13:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 10:13:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-04-15 14:13:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:13:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:13:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:13:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:13:34 --> Total execution time: 0.0831
DEBUG - 2020-04-15 10:13:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:13:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:13:34 --> Total execution time: 0.1042
DEBUG - 2020-04-15 10:13:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/index.php
DEBUG - 2020-04-15 14:13:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:13:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:13:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:13:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:13:37 --> Total execution time: 0.0984
DEBUG - 2020-04-15 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:13:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:13:37 --> Total execution time: 0.0823
DEBUG - 2020-04-15 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:13:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-view.php
DEBUG - 2020-04-15 10:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-04-15 14:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:13:39 --> Total execution time: 0.0822
DEBUG - 2020-04-15 10:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:13:39 --> Total execution time: 0.1077
DEBUG - 2020-04-15 10:13:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 10:13:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 14:13:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 14:13:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:13:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:13:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:13:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:13:45 --> Total execution time: 0.0781
DEBUG - 2020-04-15 10:13:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:13:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:13:45 --> Total execution time: 0.0927
DEBUG - 2020-04-15 10:13:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 14:13:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-04-15 14:13:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:13:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:13:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:13:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:13:49 --> Total execution time: 0.0750
DEBUG - 2020-04-15 10:13:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:13:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:13:49 --> Total execution time: 0.0900
DEBUG - 2020-04-15 10:13:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-15 14:13:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-04-15 10:13:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-04-15 14:13:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:13:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:13:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:13:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:13:51 --> Total execution time: 0.0900
DEBUG - 2020-04-15 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:13:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:13:52 --> Total execution time: 0.0891
DEBUG - 2020-04-15 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 10:13:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:55 --> Total execution time: 0.0538
DEBUG - 2020-04-15 10:13:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 10:13:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 10:13:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:13:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:13:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-04-15 14:13:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:13:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:13:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:13:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:13:59 --> Total execution time: 0.0733
DEBUG - 2020-04-15 10:13:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:13:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:13:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:13:59 --> Total execution time: 0.0945
DEBUG - 2020-04-15 10:14:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:14:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:14:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:14:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 10:14:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:14:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:14:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/models/Batch_model.php
DEBUG - 2020-04-15 14:14:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/views/index.php
DEBUG - 2020-04-15 14:14:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:14:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:14:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:14:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:14:08 --> Total execution time: 0.1129
DEBUG - 2020-04-15 10:14:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:14:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:14:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:14:08 --> Total execution time: 0.0896
DEBUG - 2020-04-15 10:14:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:14:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:14:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/models/Batch_model.php
DEBUG - 2020-04-15 14:14:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/views/batch-view.php
DEBUG - 2020-04-15 10:14:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:14:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-04-15 14:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:14:10 --> Total execution time: 0.0848
DEBUG - 2020-04-15 10:14:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:14:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:14:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:14:11 --> Total execution time: 0.1047
DEBUG - 2020-04-15 10:14:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:14:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:14:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-15 14:14:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-04-15 10:17:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:17:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:17:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 14:17:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 14:17:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:17:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:17:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:17:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:17:54 --> Total execution time: 0.1194
DEBUG - 2020-04-15 10:17:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:17:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:17:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:17:54 --> Total execution time: 0.0912
DEBUG - 2020-04-15 10:18:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:18:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 14:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 14:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:18:17 --> Total execution time: 0.0914
DEBUG - 2020-04-15 10:18:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:18:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:18:17 --> Total execution time: 0.1151
DEBUG - 2020-04-15 10:20:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 14:20:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 14:20:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:20:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:20:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:20:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:20:31 --> Total execution time: 0.0863
DEBUG - 2020-04-15 10:20:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:20:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:20:31 --> Total execution time: 0.0876
DEBUG - 2020-04-15 10:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:20:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-15 14:20:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-15 14:20:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:20:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:20:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:20:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:20:34 --> Total execution time: 0.3127
DEBUG - 2020-04-15 10:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:20:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:20:35 --> Total execution time: 0.0890
DEBUG - 2020-04-15 10:20:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:20:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-15 10:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:20:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-04-15 14:20:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:20:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:20:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:20:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:20:37 --> Total execution time: 0.1426
DEBUG - 2020-04-15 10:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:20:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:20:37 --> Total execution time: 0.0906
DEBUG - 2020-04-15 10:20:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:20:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-04-15 10:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:20:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-15 14:20:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-15 14:20:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:20:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:20:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:20:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:20:39 --> Total execution time: 0.1783
DEBUG - 2020-04-15 10:20:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:20:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:20:39 --> Total execution time: 0.0930
DEBUG - 2020-04-15 10:20:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:20:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:20:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-15 10:20:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:20:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-04-15 10:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:20:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-04-15 10:20:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:20:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-04-15 10:20:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:20:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-15 10:20:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:20:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:20:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:20:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-04-15 10:21:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:21:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:21:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:21:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-04-15 10:21:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:21:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:21:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:21:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-15 10:21:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:21:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 14:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 14:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:21:38 --> Total execution time: 0.1255
DEBUG - 2020-04-15 10:21:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:21:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:21:38 --> Total execution time: 0.1072
DEBUG - 2020-04-15 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:21:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:21:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 14:21:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 14:21:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:21:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:21:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:21:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:21:40 --> Total execution time: 0.0858
DEBUG - 2020-04-15 10:21:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:21:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:21:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:21:41 --> Total execution time: 0.0991
DEBUG - 2020-04-15 10:21:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:21:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/social/views/social.php
DEBUG - 2020-04-15 14:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:21:56 --> Total execution time: 0.1143
DEBUG - 2020-04-15 10:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:21:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:21:56 --> Total execution time: 0.1073
DEBUG - 2020-04-15 10:21:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:21:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:21:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:21:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-15 14:21:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-15 14:21:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:21:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:21:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:21:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:21:59 --> Total execution time: 0.1185
DEBUG - 2020-04-15 10:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:22:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:22:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:22:00 --> Total execution time: 0.0861
DEBUG - 2020-04-15 10:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:22:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:22:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:22:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 14:22:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-15 10:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:22:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:22:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 14:22:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 14:22:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:22:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:22:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:22:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:22:47 --> Total execution time: 0.1003
DEBUG - 2020-04-15 10:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:22:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:22:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:22:47 --> Total execution time: 0.0984
DEBUG - 2020-04-15 10:23:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:23:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:23:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 14:23:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 14:23:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:23:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:23:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:23:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:23:08 --> Total execution time: 0.1478
DEBUG - 2020-04-15 10:23:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:23:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:23:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:23:08 --> Total execution time: 0.0970
DEBUG - 2020-04-15 10:23:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:23:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:23:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 14:23:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 10:23:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:23:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:23:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 14:23:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 14:23:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:23:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:23:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:23:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:23:53 --> Total execution time: 0.0831
DEBUG - 2020-04-15 10:23:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:23:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:23:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:23:54 --> Total execution time: 0.1122
DEBUG - 2020-04-15 10:23:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:23:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:23:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 14:23:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 10:23:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:23:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:23:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 14:23:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-15 14:23:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 14:23:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 14:23:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 14:23:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 14:23:56 --> Total execution time: 0.0785
DEBUG - 2020-04-15 10:23:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:23:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:23:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 10:23:56 --> Total execution time: 0.0960
DEBUG - 2020-04-15 10:23:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:23:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 10:23:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 10:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 10:23:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:23:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 14:23:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-15 12:29:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 12:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 12:29:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:29:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 12:29:25 --> No URI present. Default controller set.
DEBUG - 2020-04-15 12:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 12:29:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:29:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-15 12:29:25 --> Total execution time: 0.0948
DEBUG - 2020-04-15 12:29:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 12:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 12:29:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 12:29:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 12:29:25 --> Total execution time: 0.1342
DEBUG - 2020-04-15 13:30:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 13:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 17:30:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 17:30:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-04-15 17:30:28 --> Total execution time: 1.1011
DEBUG - 2020-04-15 14:32:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:32:41 --> No URI present. Default controller set.
DEBUG - 2020-04-15 14:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:32:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:32:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-15 14:32:41 --> Total execution time: 0.4511
DEBUG - 2020-04-15 14:32:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:32:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:32:44 --> Total execution time: 0.1173
DEBUG - 2020-04-15 14:33:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:33:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:33:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:33:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:33:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-15 14:33:08 --> Total execution time: 0.0569
DEBUG - 2020-04-15 14:33:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:33:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:33:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:33:09 --> Total execution time: 0.0665
DEBUG - 2020-04-15 14:33:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:33:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:33:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:33:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 18:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 18:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:33:17 --> Total execution time: 0.2780
DEBUG - 2020-04-15 14:33:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:33:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:33:17 --> Total execution time: 0.0623
DEBUG - 2020-04-15 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:33:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:33:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/setting/models/Setting_model.php
DEBUG - 2020-04-15 18:33:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/setting/views/reset-profile.php
DEBUG - 2020-04-15 18:33:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:33:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:33:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:33:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:33:21 --> Total execution time: 0.1218
DEBUG - 2020-04-15 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:33:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:33:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:33:21 --> Total execution time: 0.0888
DEBUG - 2020-04-15 14:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:33:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:33:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/setting/models/Setting_model.php
DEBUG - 2020-04-15 14:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:33:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:33:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/setting/models/Setting_model.php
DEBUG - 2020-04-15 18:33:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/setting/views/reset-profile.php
DEBUG - 2020-04-15 18:33:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:33:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:33:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:33:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:33:26 --> Total execution time: 0.0929
DEBUG - 2020-04-15 14:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:33:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:33:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:33:26 --> Total execution time: 0.0762
DEBUG - 2020-04-15 14:53:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:53:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:53:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 18:53:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 18:53:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:53:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:53:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:53:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:53:47 --> Total execution time: 1.5223
DEBUG - 2020-04-15 14:53:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:53:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:53:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:53:48 --> Total execution time: 0.1309
DEBUG - 2020-04-15 14:53:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:53:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:53:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-04-15 18:53:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-04-15 18:53:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:53:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:53:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:53:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:53:52 --> Total execution time: 0.2601
DEBUG - 2020-04-15 14:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:53:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:53:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:53:53 --> Total execution time: 0.3515
DEBUG - 2020-04-15 14:53:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:53:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:53:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-04-15 18:53:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-04-15 14:53:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:53:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:53:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-15 18:53:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:53:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:53:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:53:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:53:55 --> Total execution time: 0.2073
DEBUG - 2020-04-15 14:53:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:53:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:53:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:53:56 --> Total execution time: 0.1096
DEBUG - 2020-04-15 14:53:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:53:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:53:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 18:53:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-15 18:53:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:53:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:53:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:53:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:53:59 --> Total execution time: 0.2009
DEBUG - 2020-04-15 14:53:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:53:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:54:00 --> Total execution time: 0.0980
DEBUG - 2020-04-15 14:54:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 18:54:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-15 14:54:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 18:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 18:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:54:02 --> Total execution time: 0.1398
DEBUG - 2020-04-15 14:54:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:54:02 --> Total execution time: 0.0875
DEBUG - 2020-04-15 14:54:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 18:54:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 14:54:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-15 18:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-04-15 18:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:54:08 --> Total execution time: 0.3370
DEBUG - 2020-04-15 14:54:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:54:08 --> Total execution time: 0.0942
DEBUG - 2020-04-15 14:54:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-04-15 18:54:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-04-15 14:54:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 18:54:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-15 18:54:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-15 18:54:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:54:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:54:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:54:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:54:11 --> Total execution time: 0.1733
DEBUG - 2020-04-15 14:54:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:54:11 --> Total execution time: 0.0921
DEBUG - 2020-04-15 14:54:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-15 18:54:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-15 14:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 18:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-04-15 18:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:54:22 --> Total execution time: 0.2327
DEBUG - 2020-04-15 14:54:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:54:22 --> Total execution time: 0.0898
DEBUG - 2020-04-15 14:54:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 14:54:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-04-15 18:54:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 18:54:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-04-15 18:54:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:54:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:54:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:54:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:54:30 --> Total execution time: 5.4414
DEBUG - 2020-04-15 14:54:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:54:30 --> Total execution time: 0.0814
DEBUG - 2020-04-15 14:54:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-15 18:54:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-04-15 14:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-04-15 18:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:54:50 --> Total execution time: 0.1227
DEBUG - 2020-04-15 14:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:54:50 --> Total execution time: 0.1188
DEBUG - 2020-04-15 14:54:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-15 18:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:54:54 --> Total execution time: 0.0789
DEBUG - 2020-04-15 14:54:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:54:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:54:54 --> Total execution time: 0.1364
DEBUG - 2020-04-15 14:55:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:55:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-15 18:55:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-15 18:55:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:55:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:55:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:55:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:55:18 --> Total execution time: 0.0952
DEBUG - 2020-04-15 14:55:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:55:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:55:19 --> Total execution time: 0.1201
DEBUG - 2020-04-15 14:55:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:55:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 18:55:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-15 18:55:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:55:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:55:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:55:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:55:25 --> Total execution time: 0.0843
DEBUG - 2020-04-15 14:55:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:55:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:55:25 --> Total execution time: 0.0828
DEBUG - 2020-04-15 14:55:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:55:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:55:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 18:55:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-15 14:55:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:55:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 18:55:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/index.php
DEBUG - 2020-04-15 18:55:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:55:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:55:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:55:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:55:27 --> Total execution time: 0.0850
DEBUG - 2020-04-15 14:55:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:55:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:55:28 --> Total execution time: 0.1010
DEBUG - 2020-04-15 14:55:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:55:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 18:55:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-view.php
DEBUG - 2020-04-15 14:55:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:55:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 18:55:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-15 18:55:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-15 18:55:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-15 18:55:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-15 18:55:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-15 18:55:30 --> Total execution time: 0.0901
DEBUG - 2020-04-15 14:55:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:55:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-15 14:55:30 --> Total execution time: 0.1036
DEBUG - 2020-04-15 14:55:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 14:55:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-15 14:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-15 14:55:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-15 18:55:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-15 18:55:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
