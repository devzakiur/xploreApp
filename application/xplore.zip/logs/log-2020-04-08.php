<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-04-08 08:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-08 08:36:13 --> No URI present. Default controller set.
DEBUG - 2020-04-08 08:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-08 08:36:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-08 08:36:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-08 08:36:13 --> Total execution time: 0.3656
DEBUG - 2020-04-08 08:36:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-08 08:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-08 08:36:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-08 08:36:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-08 08:36:14 --> Total execution time: 0.1077
DEBUG - 2020-04-08 08:36:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-08 08:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-08 08:36:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-08 08:36:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-08 08:36:15 --> Total execution time: 0.0795
