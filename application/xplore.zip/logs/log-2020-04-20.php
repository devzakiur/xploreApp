<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-04-20 13:47:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:47:40 --> No URI present. Default controller set.
DEBUG - 2020-04-20 13:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:47:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:47:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-20 13:47:40 --> Total execution time: 0.9053
DEBUG - 2020-04-20 13:47:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:47:40 --> No URI present. Default controller set.
DEBUG - 2020-04-20 13:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:47:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:47:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-20 13:47:40 --> Total execution time: 0.1065
DEBUG - 2020-04-20 13:47:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:47:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:47:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 13:47:41 --> Total execution time: 0.1892
DEBUG - 2020-04-20 13:47:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:47:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:47:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 13:47:41 --> Total execution time: 0.0737
DEBUG - 2020-04-20 13:47:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:47:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:47:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 13:47:42 --> Total execution time: 0.0590
DEBUG - 2020-04-20 13:47:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:47:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:47:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:47:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-20 17:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-20 17:47:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 17:47:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 17:47:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 17:47:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 17:47:46 --> Total execution time: 0.3073
DEBUG - 2020-04-20 13:47:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:47:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:47:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 13:47:46 --> Total execution time: 0.1103
DEBUG - 2020-04-20 13:49:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:49:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-20 17:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-20 17:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 17:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 17:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 17:49:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 17:49:40 --> Total execution time: 0.0932
DEBUG - 2020-04-20 13:49:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:49:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:49:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 13:49:41 --> Total execution time: 0.1151
DEBUG - 2020-04-20 13:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:49:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 17:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 17:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 17:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 17:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 17:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 17:49:44 --> Total execution time: 0.0962
DEBUG - 2020-04-20 13:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:49:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:49:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 13:49:45 --> Total execution time: 0.1077
DEBUG - 2020-04-20 13:49:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:49:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:49:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:49:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 17:49:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 13:51:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:51:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:51:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 17:51:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 17:51:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 17:51:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 17:51:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 17:51:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 17:51:40 --> Total execution time: 0.0771
DEBUG - 2020-04-20 13:51:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:51:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:51:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 13:51:40 --> Total execution time: 0.0689
DEBUG - 2020-04-20 13:51:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:51:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:51:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:51:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 17:51:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 13:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:54:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:54:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 17:54:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 17:54:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 17:54:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 17:54:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 17:54:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 17:54:48 --> Total execution time: 0.1234
DEBUG - 2020-04-20 13:54:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:54:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:54:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 13:54:48 --> Total execution time: 0.0905
DEBUG - 2020-04-20 13:54:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:54:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 13:54:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 13:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 13:54:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 17:54:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:03:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:03:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:03:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:03:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:03:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:03:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:03:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:03:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:03:38 --> Total execution time: 0.1547
DEBUG - 2020-04-20 14:03:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:03:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:03:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:03:39 --> Total execution time: 0.1103
DEBUG - 2020-04-20 14:03:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:03:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:03:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:03:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:03:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:06:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:06:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:06:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:06:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:06:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:06:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:06:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:06:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:06:01 --> Total execution time: 0.1052
DEBUG - 2020-04-20 14:06:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:06:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:06:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:06:02 --> Total execution time: 0.0897
DEBUG - 2020-04-20 14:06:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:06:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:06:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:06:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:06:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:07:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:07:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:07:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:07:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:07:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:07:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:07:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:07:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:07:40 --> Total execution time: 0.0735
DEBUG - 2020-04-20 14:07:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:07:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:07:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:07:40 --> Total execution time: 0.0757
DEBUG - 2020-04-20 14:07:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:07:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:07:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:08:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:08:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:08:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:08:14 --> Total execution time: 0.0823
DEBUG - 2020-04-20 14:08:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:08:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:08:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:08:14 --> Total execution time: 0.1185
DEBUG - 2020-04-20 14:08:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:08:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:08:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:10:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:10:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:10:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:10:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:10:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:10:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:10:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:10:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:10:21 --> Total execution time: 0.1279
DEBUG - 2020-04-20 14:10:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:10:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:10:22 --> Total execution time: 0.1174
DEBUG - 2020-04-20 14:10:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:10:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:10:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:14:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:14:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:14:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:14:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:14:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:14:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:14:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:14:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:14:58 --> Total execution time: 0.1202
DEBUG - 2020-04-20 14:14:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:14:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:14:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:14:58 --> Total execution time: 0.1072
DEBUG - 2020-04-20 14:15:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:15:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:15:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:16:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:16:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:16:11 --> Total execution time: 0.1101
DEBUG - 2020-04-20 14:16:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:16:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:16:11 --> Total execution time: 0.1033
DEBUG - 2020-04-20 14:16:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:16:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:16:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:16:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:16:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:16:14 --> Total execution time: 0.1868
ERROR - 2020-04-20 18:16:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:16:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:16:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:16:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:16:20 --> Total execution time: 0.0782
DEBUG - 2020-04-20 14:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:16:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:16:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:16:34 --> Total execution time: 0.1517
ERROR - 2020-04-20 18:16:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:17:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:17:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:17:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:17:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:17:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:17:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:17:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:17:46 --> Total execution time: 0.0998
DEBUG - 2020-04-20 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:17:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:17:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:17:46 --> Total execution time: 0.1418
DEBUG - 2020-04-20 14:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:17:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:17:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:17:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:17:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:17:47 --> Total execution time: 0.1304
DEBUG - 2020-04-20 14:17:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:17:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:17:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:17:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:17:53 --> Total execution time: 0.1298
ERROR - 2020-04-20 18:17:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:18:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:18:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:18:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:18:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:18:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:18:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:18:04 --> Total execution time: 0.0779
DEBUG - 2020-04-20 14:18:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:18:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:18:04 --> Total execution time: 0.0833
DEBUG - 2020-04-20 14:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:18:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:18:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:18:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:18:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:18:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:18:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:18:14 --> Total execution time: 0.1549
DEBUG - 2020-04-20 14:18:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:18:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:18:15 --> Total execution time: 0.1093
DEBUG - 2020-04-20 14:18:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:18:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:18:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:18:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:18:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:18:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:18:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:18:29 --> Total execution time: 0.1229
DEBUG - 2020-04-20 14:18:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:18:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:18:29 --> Total execution time: 0.1358
DEBUG - 2020-04-20 14:18:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:18:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:18:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:18:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:18:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 18:18:34 --> Total execution time: 0.2612
DEBUG - 2020-04-20 14:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:18:38 --> Total execution time: 0.0773
DEBUG - 2020-04-20 14:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:18:38 --> Total execution time: 0.0811
DEBUG - 2020-04-20 14:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:18:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:18:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:18:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:18:42 --> Total execution time: 0.0823
DEBUG - 2020-04-20 14:18:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:18:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:18:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:48 --> Total execution time: 0.1362
ERROR - 2020-04-20 18:18:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:20:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:20:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:20:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:20:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:20:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:20:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:20:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:20:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:20:02 --> Total execution time: 0.1245
DEBUG - 2020-04-20 14:20:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:20:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:20:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:20:02 --> Total execution time: 0.1330
DEBUG - 2020-04-20 14:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:20:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:20:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:20:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:20:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:20:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 18:20:06 --> Total execution time: 0.1872
DEBUG - 2020-04-20 14:20:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:20:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:20:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:20:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:20:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:20:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:20:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:20:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:20:15 --> Total execution time: 0.1250
DEBUG - 2020-04-20 14:20:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:20:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:20:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:20:15 --> Total execution time: 0.1667
DEBUG - 2020-04-20 14:20:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:20:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:20:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:20:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:20:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:20:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 18:20:18 --> Total execution time: 0.1178
DEBUG - 2020-04-20 14:22:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:22:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:22:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:22:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:22:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:22:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:22:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:22:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:22:23 --> Total execution time: 0.1239
DEBUG - 2020-04-20 14:22:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:22:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:22:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:22:23 --> Total execution time: 0.1057
DEBUG - 2020-04-20 14:22:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:22:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:22:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:22:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:22:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:22:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:22:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:22:26 --> Total execution time: 0.1093
ERROR - 2020-04-20 18:22:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:22:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:22:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:22:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:22:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:22:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:22:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:22:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:22:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:22:31 --> Total execution time: 0.0786
DEBUG - 2020-04-20 14:22:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:22:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:22:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:22:31 --> Total execution time: 0.1041
DEBUG - 2020-04-20 14:22:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:22:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:22:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:22:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:22:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:22:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:22:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 18:22:35 --> Total execution time: 0.1273
DEBUG - 2020-04-20 14:23:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:23:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:23:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:23:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:23:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:23:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:23:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:23:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:23:01 --> Total execution time: 0.0917
DEBUG - 2020-04-20 14:23:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:23:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:23:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:23:01 --> Total execution time: 0.0759
DEBUG - 2020-04-20 14:23:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:23:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:23:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:23:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:23:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:23:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:23:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:23:05 --> Total execution time: 0.0889
ERROR - 2020-04-20 18:23:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:24:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:24:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:24:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:24:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:24:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:24:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:24:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:24:22 --> Total execution time: 0.0782
DEBUG - 2020-04-20 14:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:24:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:24:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:24:22 --> Total execution time: 0.0787
DEBUG - 2020-04-20 14:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:24:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:24:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:25:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:25:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:25:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:25:58 --> Total execution time: 0.1679
DEBUG - 2020-04-20 14:25:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:25:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:25:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:25:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:25:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:26:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:26:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:26:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:26:00 --> Total execution time: 0.4631
DEBUG - 2020-04-20 14:26:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:26:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:26:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:26:00 --> Total execution time: 0.0912
DEBUG - 2020-04-20 14:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:26:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:26:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:26:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:26:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:26:01 --> Total execution time: 0.1256
DEBUG - 2020-04-20 14:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:26:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:26:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:26:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:26:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 18:26:19 --> Total execution time: 0.2560
DEBUG - 2020-04-20 14:26:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:26:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:26:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:27:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:27:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:27:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:36:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:36:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:36:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:36:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:36:30 --> Total execution time: 0.1206
DEBUG - 2020-04-20 14:36:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:36:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:36:30 --> Total execution time: 0.1093
DEBUG - 2020-04-20 14:36:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:36:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:36:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:36:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 18:36:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-20 18:36:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-20 18:36:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:36:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:36:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:36:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:36:36 --> Total execution time: 0.2638
DEBUG - 2020-04-20 14:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:36:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:36:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:36:36 --> Total execution time: 0.0872
DEBUG - 2020-04-20 14:36:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:36:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:36:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:36:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 18:36:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 14:44:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:06 --> No URI present. Default controller set.
DEBUG - 2020-04-20 14:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-20 14:44:06 --> Total execution time: 0.1904
DEBUG - 2020-04-20 14:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:44:06 --> Total execution time: 0.1465
DEBUG - 2020-04-20 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-20 14:44:14 --> Total execution time: 0.0743
DEBUG - 2020-04-20 14:44:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:44:14 --> Total execution time: 0.0896
DEBUG - 2020-04-20 14:44:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:44:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-20 18:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-20 18:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:44:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:44:25 --> Total execution time: 0.7189
DEBUG - 2020-04-20 14:44:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:44:26 --> Total execution time: 0.2048
DEBUG - 2020-04-20 14:44:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:44:29 --> Total execution time: 0.1722
DEBUG - 2020-04-20 14:44:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:44:29 --> Total execution time: 0.1401
DEBUG - 2020-04-20 14:44:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:44:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:44:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:44:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 18:44:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-20 18:44:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-20 18:44:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:44:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:44:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:44:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:44:32 --> Total execution time: 0.2652
DEBUG - 2020-04-20 14:44:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:44:32 --> Total execution time: 0.1260
DEBUG - 2020-04-20 14:44:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 18:44:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 14:44:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:44:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 18:44:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 14:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:44:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 18:44:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 14:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:44:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:44:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:44:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:44:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:44:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:44:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:44:45 --> Total execution time: 0.1145
DEBUG - 2020-04-20 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:44:46 --> Total execution time: 0.2248
DEBUG - 2020-04-20 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:44:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:44:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:44:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:44:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:44:51 --> Total execution time: 0.1027
DEBUG - 2020-04-20 14:45:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:45:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:45:19 --> Total execution time: 0.1311
DEBUG - 2020-04-20 14:45:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:45:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:45:20 --> Total execution time: 0.1055
DEBUG - 2020-04-20 14:45:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:45:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:45:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:46:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:46:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:46:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:48:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:48:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:48:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:48:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:48:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:48:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:49:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:49:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:49:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:49:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:49:26 --> No URI present. Default controller set.
DEBUG - 2020-04-20 14:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:49:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:49:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:49:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:49:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-20 18:49:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-20 18:49:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:49:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:49:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:49:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:49:27 --> Total execution time: 0.1211
DEBUG - 2020-04-20 14:49:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:49:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:49:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:49:28 --> Total execution time: 0.1238
DEBUG - 2020-04-20 14:49:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:49:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:49:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 18:49:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-20 18:49:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-20 18:49:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:49:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:49:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:49:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:49:30 --> Total execution time: 0.1053
DEBUG - 2020-04-20 14:49:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:49:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:49:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:49:31 --> Total execution time: 0.1065
DEBUG - 2020-04-20 14:49:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:49:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:49:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:49:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:49:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 18:49:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 14:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:49:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:49:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:50:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:50:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:50:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:50:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:50:20 --> Total execution time: 0.1005
DEBUG - 2020-04-20 18:50:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 18:50:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 14:50:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:50:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:50:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:50:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:50:22 --> Total execution time: 0.1158
DEBUG - 2020-04-20 18:50:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 18:50:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 14:50:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:50:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:50:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:50:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:50:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 18:50:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 18:50:24 --> Total execution time: 0.3432
DEBUG - 2020-04-20 14:50:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:50:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:50:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:51:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:51:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:51:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:51:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 18:51:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 18:51:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 18:51:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 18:51:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 18:51:21 --> Total execution time: 0.1340
DEBUG - 2020-04-20 14:51:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:51:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:51:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:51:22 --> Total execution time: 0.1201
DEBUG - 2020-04-20 14:51:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:51:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 14:51:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 14:51:23 --> Total execution time: 0.0853
DEBUG - 2020-04-20 14:51:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:51:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 18:51:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 14:51:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:51:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:51:38 --> Total execution time: 0.1122
DEBUG - 2020-04-20 14:51:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:51:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:51:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:52:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:52:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:52:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:52:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:52:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:52:27 --> Total execution time: 0.2785
DEBUG - 2020-04-20 14:52:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:52:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:52:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:53:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:53:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:53:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:53:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:53:31 --> Total execution time: 0.0981
DEBUG - 2020-04-20 14:53:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:53:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:53:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:53:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:53:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:53:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:54:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:54:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:54:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:54:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:54:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:54:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:54:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:54:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:56:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:56:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:56:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:56:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:56:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:56:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:56:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:56:44 --> Total execution time: 0.1444
DEBUG - 2020-04-20 14:56:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:56:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:56:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 14:57:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 14:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 14:57:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:57:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:12:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:12:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:12:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:12:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:12:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:12:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:12:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:12:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:12:53 --> Total execution time: 0.2118
DEBUG - 2020-04-20 15:12:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:12:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:12:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:14:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:14:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:14:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 19:14:16 --> Query error: Column 'id' in IN/ALL/ANY subquery is ambiguous - Invalid query: SELECT `Q`.`id`, `Q`.`title`, `SA`.`subject_id`, `SA`.`section_id`, `TQ`.`topic_id`, `TQ`.`category_id`
FROM `question` as `Q`
JOIN `topics_questions` as `TQ` ON `Q`.`id` = `TQ`.`question_id`
JOIN `subject_assign` as `SUBA` ON `TQ`.`category_id` = `SUBA`.`category_id`
JOIN `section_assign` as `SA` ON `SUBA`.`subject_id` = `SA`.`subject_id`
WHERE `TQ`.`category_id` = '2'
AND `SUBA`.`subject_id` IN('1')
AND id  IN (SELECT Min(id) FROM `question` GROUP BY title)
 LIMIT 100
DEBUG - 2020-04-20 19:14:16 --> DB Transaction Failure
DEBUG - 2020-04-20 15:14:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:14:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:14:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 19:14:36 --> Query error: Column 'id' in IN/ALL/ANY subquery is ambiguous - Invalid query: SELECT `Q`.`id`, `Q`.`title`, `SA`.`subject_id`, `SA`.`section_id`, `TQ`.`topic_id`, `TQ`.`category_id`
FROM `question` as `Q`
JOIN `topics_questions` as `TQ` ON `Q`.`id` = `TQ`.`question_id`
JOIN `subject_assign` as `SUBA` ON `TQ`.`category_id` = `SUBA`.`category_id`
JOIN `section_assign` as `SA` ON `SUBA`.`subject_id` = `SA`.`subject_id`
WHERE `TQ`.`category_id` = '2'
AND `SUBA`.`subject_id` IN('1')
AND `id`  IN (SELECT Min(`id`) FROM `question` GROUP BY title)
 LIMIT 100
DEBUG - 2020-04-20 19:14:36 --> DB Transaction Failure
DEBUG - 2020-04-20 15:14:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:14:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:14:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 19:14:50 --> Query error: Unknown column 'Q.id' in 'IN/ALL/ANY subquery' - Invalid query: SELECT `Q`.`id`, `Q`.`title`, `SA`.`subject_id`, `SA`.`section_id`, `TQ`.`topic_id`, `TQ`.`category_id`
FROM `question` as `Q`
JOIN `topics_questions` as `TQ` ON `Q`.`id` = `TQ`.`question_id`
JOIN `subject_assign` as `SUBA` ON `TQ`.`category_id` = `SUBA`.`category_id`
JOIN `section_assign` as `SA` ON `SUBA`.`subject_id` = `SA`.`subject_id`
WHERE `TQ`.`category_id` = '2'
AND `SUBA`.`subject_id` IN('1')
AND `Q.id`  IN (SELECT Min(`id`) FROM `question` GROUP BY title)
 LIMIT 100
DEBUG - 2020-04-20 19:14:50 --> DB Transaction Failure
DEBUG - 2020-04-20 15:15:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:15:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:15:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:15:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:15:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:15:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:15:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:15:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 19:15:48 --> Query error: Column 'id' in IN/ALL/ANY subquery is ambiguous - Invalid query: SELECT `Q`.`id`, `Q`.`title`, `SA`.`subject_id`, `SA`.`section_id`, `TQ`.`topic_id`, `TQ`.`category_id`
FROM `question` as `Q`
JOIN `topics_questions` as `TQ` ON `Q`.`id` = `TQ`.`question_id`
JOIN `subject_assign` as `SUBA` ON `TQ`.`category_id` = `SUBA`.`category_id`
JOIN `section_assign` as `SA` ON `SUBA`.`subject_id` = `SA`.`subject_id`
WHERE `TQ`.`category_id` = '2'
AND `SUBA`.`subject_id` IN('1')
AND id  IN (SELECT Min(id) FROM question GROUP BY title)
 LIMIT 100
DEBUG - 2020-04-20 19:15:48 --> DB Transaction Failure
DEBUG - 2020-04-20 15:16:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:16:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:16:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:17:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:17:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:17:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:18:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:18:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:18:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:18:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:18:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:18:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:18:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:18:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:20:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:20:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:20:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:20:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:20:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:20:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:22:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:22:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:22:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 19:22:01 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::where_not_id() D:\shipan7.2\htdocs\xplore\application\modules\modeltest\models\Modeltest_Model.php 17
DEBUG - 2020-04-20 15:22:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:22:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:22:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:22:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:22:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:22:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:22:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:22:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:22:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 19:22:53 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::distnct() D:\shipan7.2\htdocs\xplore\application\modules\modeltest\models\Modeltest_Model.php 9
DEBUG - 2020-04-20 15:23:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:23:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:23:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:24:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:24:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:27:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:27:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 15:27:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 15:27:19 --> Total execution time: 0.4692
DEBUG - 2020-04-20 15:27:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:27:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:27:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:27:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:27:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:27:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:27:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:27:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:27:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:28:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:28:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:28:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:28:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:28:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:28:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:28:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:28:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:28:28 --> Total execution time: 0.2513
DEBUG - 2020-04-20 15:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:28:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:28:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:29:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:29:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:29:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 19:29:30 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::distnict() D:\shipan7.2\htdocs\xplore\application\modules\modeltest\models\Modeltest_Model.php 10
DEBUG - 2020-04-20 15:30:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:30:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:30:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:31:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:31:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:31:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:31:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:31:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 15:31:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 15:31:35 --> Total execution time: 0.0906
DEBUG - 2020-04-20 15:31:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:31:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:31:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:32:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:32:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:34:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:34:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:34:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:34:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:34:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:34:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:34:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:34:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:34:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:35:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:35:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:35:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:35:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:35:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:36:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:36:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:36:19 --> Total execution time: 0.1356
DEBUG - 2020-04-20 15:36:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:36:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:36:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:36:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:36:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:36:38 --> Total execution time: 0.1085
DEBUG - 2020-04-20 15:36:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:36:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:36:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:38:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:38:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:45:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:45:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:45:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:46:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:46:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:46:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:46:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:46:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:46:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:46:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:46:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:46:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:47:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:47:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:47:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:47:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:47:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:47:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:47:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:47:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:47:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:47:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:47:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:47:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:47:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:47:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:47:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:47:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:47:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:47:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:47:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:47:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:47:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 19:47:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 19:47:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 19:47:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 19:47:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 19:47:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 19:47:52 --> Total execution time: 0.2192
DEBUG - 2020-04-20 15:47:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:47:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 15:47:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 15:47:52 --> Total execution time: 0.1036
DEBUG - 2020-04-20 15:47:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:47:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 19:47:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 15:48:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:48:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:48:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 19:48:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 19:48:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 19:48:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 19:48:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 19:48:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 19:48:08 --> Total execution time: 0.0889
DEBUG - 2020-04-20 15:48:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:48:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 15:48:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 15:48:09 --> Total execution time: 0.1184
DEBUG - 2020-04-20 15:48:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:48:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 19:48:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 15:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:51:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 15:51:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 15:51:12 --> Total execution time: 0.1787
DEBUG - 2020-04-20 15:51:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:51:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:51:34 --> Total execution time: 0.1237
DEBUG - 2020-04-20 15:51:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:51:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:51:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:52:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:52:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:52:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:52:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:52:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:52:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:52:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:52:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:52:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:52:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:52:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:53:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:53:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:53:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:53:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:53:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:53:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 15:53:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:53:27 --> Total execution time: 0.1347
DEBUG - 2020-04-20 19:53:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 19:53:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 15:53:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:53:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:53:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 15:53:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:53:31 --> Total execution time: 0.1059
DEBUG - 2020-04-20 19:53:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 19:53:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 15:53:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:53:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:53:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:54:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:54:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 15:54:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:54:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 19:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 19:54:22 --> Total execution time: 0.3819
DEBUG - 2020-04-20 15:54:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:54:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:54:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:54:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:54:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:54:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:55:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:55:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:55:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 15:55:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:55:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:55:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 19:55:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 19:55:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 19:55:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 19:55:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 19:55:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 19:55:20 --> Total execution time: 0.1585
DEBUG - 2020-04-20 15:55:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:55:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 15:55:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 15:55:20 --> Total execution time: 0.1368
DEBUG - 2020-04-20 15:55:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 15:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 15:55:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 19:55:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:05:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:05:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:05:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:05:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:05:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:05:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:05:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:05:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:05:30 --> Total execution time: 0.1881
DEBUG - 2020-04-20 16:05:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:05:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:05:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:05:31 --> Total execution time: 0.2121
DEBUG - 2020-04-20 16:05:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:05:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:05:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:05:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:05:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:05:50 --> Total execution time: 0.1049
DEBUG - 2020-04-20 16:06:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:06:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:06:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 20:06:02 --> Severity: Notice --> Undefined property: Modeltest::$subject D:\shipan7.2\htdocs\xplore\application\modules\modeltest\controllers\Modeltest.php 46
ERROR - 2020-04-20 20:06:02 --> Severity: error --> Exception: Call to a member function insert() on null D:\shipan7.2\htdocs\xplore\application\modules\modeltest\controllers\Modeltest.php 46
DEBUG - 2020-04-20 16:06:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:06:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:06:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:06:05 --> Total execution time: 0.1708
DEBUG - 2020-04-20 16:06:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:06:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:06:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 20:06:14 --> Severity: Notice --> Undefined property: Modeltest::$subject D:\shipan7.2\htdocs\xplore\application\modules\modeltest\controllers\Modeltest.php 46
ERROR - 2020-04-20 20:06:14 --> Severity: error --> Exception: Call to a member function insert() on null D:\shipan7.2\htdocs\xplore\application\modules\modeltest\controllers\Modeltest.php 46
DEBUG - 2020-04-20 16:06:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:06:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:06:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 20:06:33 --> Query error: Unknown column 'category_id' in 'field list' - Invalid query: INSERT INTO `model_test_question` (`category_id`, `model_test_id`, `question_id`, `section_id`, `subject_id`, `title`, `topic_id`) VALUES ('1',1,'13','41','2','Mutton is a/an','272'), ('1',1,'23','30','9','x এবং y উভয়ই বিজোড় সংখ্যা হলে কোনটি জোড় সংখ্যা হবে?','201'), ('1',1,'9','2','1','উল্লিখিত কোন রচনাটি পুঁথি সাহিত্যের অন্তর্গত নয়?','3'), ('1',1,'1','2','1','উল্লিখিতদের মধ্যে কে প্রাচীনযুগের কবি নন?','2'), ('1',1,'14','1','1','কোনটিতে অপপ্রয়োগ ঘটেছে?','24'), ('1',1,'11','2','1','গঠনরীতিতে শ্রীকৃষ্ণকীর্তন কাব্য মূলত','3'), ('1',1,'17','8','4','গণপ্রজাতন্ত্রী বাংলাদেশের সংবিধানের কোন ধারায় সকল নাগরিককে আইনের দৃষ্টিতে সমতার কথা বলা হয়েছে?','67'), ('1',1,'4','2','1','চর্যাচর্যবিনিশ্চয়- এর অর্থ কি?','2'), ('1',1,'7','2','1','চর্যাপদ কোন ছন্দে লেখা?','2'), ('1',1,'10','2','1','জীবনীকাব্য রচনার জন্য বিখ্যাত','3'), ('1',1,'3','2','1','ড. মুহম্মদ শহীদুল্লাহ্ সম্পাদিত চর্যাপদ বিষয়ক গ্রন্থের নাম কি?','2'), ('1',1,'15','3','4','পূর্ববঙ্গ ও আসাম প্রদেশ গঠনকালে ব্রিটিশ ভারতের গভর্নর জেনারেল ও ভাইসরয় ছিলেন--','50'), ('1',1,'24','2','1','বাংলা উপন্যাসের জনক কে ?','12'), ('1',1,'8','2','1','বাংলা ভাষার আদি নিদর্শন চর্যাপদ আবিসষ্কৃত হয় কত সালে?','2'), ('1',1,'6','2','1','বাংলা সাহিত্যের প্রাচীন যুগের নিদর্শন কোনটি?','2'), ('1',1,'16','4','4','বাংলাদেশে মোট আবাদযোগ্য জমির পরিমাণ__','54'), ('1',1,'18','13','5','মেসোপটেমীয় সভ্যতা গড়ে উঠেছিল কোথায়?','92'), ('1',1,'12','18','5','শান্তির জন্য প্রথম কোন মহিলা নোবেল পুরস্কার পান?','121'), ('1',1,'2','2','1','সন্ধ্যাভাষা কোন সাহিত্যকর্মের সাথে যুক্ত?','2'), ('1',1,'5','2','1','সবচেয়ে বেশি চর্যাপদ পাওয়া গেছে কোন কবির?','2')
DEBUG - 2020-04-20 20:06:33 --> DB Transaction Failure
DEBUG - 2020-04-20 16:06:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:06:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:06:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 20:06:49 --> Query error: Unknown column 'title' in 'field list' - Invalid query: INSERT INTO `model_test_question` (`model_test_id`, `question_id`, `section_id`, `subject_id`, `title`, `topic_id`) VALUES (2,'13','41','2','Mutton is a/an','272'), (2,'23','30','9','x এবং y উভয়ই বিজোড় সংখ্যা হলে কোনটি জোড় সংখ্যা হবে?','201'), (2,'9','2','1','উল্লিখিত কোন রচনাটি পুঁথি সাহিত্যের অন্তর্গত নয়?','3'), (2,'1','2','1','উল্লিখিতদের মধ্যে কে প্রাচীনযুগের কবি নন?','2'), (2,'14','1','1','কোনটিতে অপপ্রয়োগ ঘটেছে?','24'), (2,'11','2','1','গঠনরীতিতে শ্রীকৃষ্ণকীর্তন কাব্য মূলত','3'), (2,'17','8','4','গণপ্রজাতন্ত্রী বাংলাদেশের সংবিধানের কোন ধারায় সকল নাগরিককে আইনের দৃষ্টিতে সমতার কথা বলা হয়েছে?','67'), (2,'4','2','1','চর্যাচর্যবিনিশ্চয়- এর অর্থ কি?','2'), (2,'7','2','1','চর্যাপদ কোন ছন্দে লেখা?','2'), (2,'10','2','1','জীবনীকাব্য রচনার জন্য বিখ্যাত','3'), (2,'3','2','1','ড. মুহম্মদ শহীদুল্লাহ্ সম্পাদিত চর্যাপদ বিষয়ক গ্রন্থের নাম কি?','2'), (2,'15','3','4','পূর্ববঙ্গ ও আসাম প্রদেশ গঠনকালে ব্রিটিশ ভারতের গভর্নর জেনারেল ও ভাইসরয় ছিলেন--','50'), (2,'24','2','1','বাংলা উপন্যাসের জনক কে ?','12'), (2,'8','2','1','বাংলা ভাষার আদি নিদর্শন চর্যাপদ আবিসষ্কৃত হয় কত সালে?','2'), (2,'6','2','1','বাংলা সাহিত্যের প্রাচীন যুগের নিদর্শন কোনটি?','2'), (2,'16','4','4','বাংলাদেশে মোট আবাদযোগ্য জমির পরিমাণ__','54'), (2,'18','13','5','মেসোপটেমীয় সভ্যতা গড়ে উঠেছিল কোথায়?','92'), (2,'12','18','5','শান্তির জন্য প্রথম কোন মহিলা নোবেল পুরস্কার পান?','121'), (2,'2','2','1','সন্ধ্যাভাষা কোন সাহিত্যকর্মের সাথে যুক্ত?','2'), (2,'5','2','1','সবচেয়ে বেশি চর্যাপদ পাওয়া গেছে কোন কবির?','2')
DEBUG - 2020-04-20 20:06:49 --> DB Transaction Failure
DEBUG - 2020-04-20 16:06:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:06:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:06:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 16:13:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:13:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:13:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:13:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:13:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:13:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:13:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:13:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:13:42 --> Total execution time: 0.2095
DEBUG - 2020-04-20 16:13:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:13:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:13:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:13:42 --> Total execution time: 0.2515
DEBUG - 2020-04-20 16:13:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:13:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:13:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:13:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:13:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:13:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:13:48 --> Total execution time: 0.1311
DEBUG - 2020-04-20 16:13:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:13:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:13:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:13:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:13:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:13:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:13:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:13:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:13:52 --> Total execution time: 0.0973
DEBUG - 2020-04-20 16:13:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:13:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:13:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:13:52 --> Total execution time: 0.1432
DEBUG - 2020-04-20 16:13:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:13:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:13:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:13:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:13:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:13:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:13:54 --> Total execution time: 0.1908
DEBUG - 2020-04-20 16:14:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:14:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:14:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:14:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:14:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:14:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:14:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:14:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:14:19 --> Total execution time: 0.1603
DEBUG - 2020-04-20 16:14:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:14:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:14:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:14:19 --> Total execution time: 0.1807
DEBUG - 2020-04-20 16:14:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:14:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:14:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:14:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:14:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:14:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:14:21 --> Total execution time: 0.1565
DEBUG - 2020-04-20 16:14:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:14:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:14:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:14:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:14:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:14:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:14:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:14:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:14:41 --> Total execution time: 0.1470
DEBUG - 2020-04-20 16:14:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:14:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:14:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:14:42 --> Total execution time: 0.1224
DEBUG - 2020-04-20 16:14:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:14:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:14:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:14:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:14:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:14:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:14:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:14:43 --> Total execution time: 0.1714
DEBUG - 2020-04-20 16:15:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:15:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:15:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:15:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:15:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:15:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:15:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:15:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:15:34 --> Total execution time: 0.1014
DEBUG - 2020-04-20 16:15:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:15:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:15:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:15:34 --> Total execution time: 0.1074
DEBUG - 2020-04-20 16:15:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:15:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:15:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:15:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:15:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:15:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:15:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:15:35 --> Total execution time: 0.1818
DEBUG - 2020-04-20 16:15:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:15:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:15:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:15:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:15:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:15:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:15:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:15:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:15:43 --> Total execution time: 0.1452
DEBUG - 2020-04-20 16:15:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:15:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:15:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:15:43 --> Total execution time: 0.1469
DEBUG - 2020-04-20 16:15:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:15:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:15:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:15:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:15:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:15:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:15:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:15:44 --> Total execution time: 0.2098
DEBUG - 2020-04-20 16:16:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:16:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:16:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:16:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:16:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:16:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:16:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:16:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:16:26 --> Total execution time: 0.1435
DEBUG - 2020-04-20 16:16:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:16:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:16:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:16:27 --> Total execution time: 0.1615
DEBUG - 2020-04-20 16:16:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:16:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:16:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:16:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:16:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:16:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:16:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:16:28 --> Total execution time: 0.2180
DEBUG - 2020-04-20 16:20:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:20:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:20:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:20:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:20:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:20:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:20:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:20:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:20:53 --> Total execution time: 0.1815
DEBUG - 2020-04-20 16:20:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:20:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:20:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:20:53 --> Total execution time: 0.0849
DEBUG - 2020-04-20 16:20:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:20:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:20:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:20:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:21:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:21:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:21:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:21:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:21:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:21:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:21:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:21:17 --> Total execution time: 0.0910
DEBUG - 2020-04-20 16:21:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:21:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:21:17 --> Total execution time: 0.1203
DEBUG - 2020-04-20 16:21:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:21:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:21:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:21:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:21:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:21:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:21:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:21:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:21:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:21:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:21:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:21:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:21:37 --> Total execution time: 0.1311
DEBUG - 2020-04-20 16:21:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:21:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:21:37 --> Total execution time: 0.1569
DEBUG - 2020-04-20 16:21:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:21:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:21:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:21:38 --> Total execution time: 0.1270
DEBUG - 2020-04-20 16:21:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:21:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:21:39 --> Total execution time: 0.1115
DEBUG - 2020-04-20 16:21:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:21:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:21:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:21:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:21:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 16:21:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:21:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:21:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:22:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:22:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:22:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:22:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:22:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:22:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:22:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:22:27 --> Total execution time: 0.0848
DEBUG - 2020-04-20 16:22:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:22:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:22:28 --> Total execution time: 0.1201
DEBUG - 2020-04-20 16:22:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:22:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:22:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:22:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:22:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:22:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:22:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:22:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:22:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:22:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:22:29 --> Total execution time: 0.1234
DEBUG - 2020-04-20 16:22:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:22:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:22:29 --> Total execution time: 0.0797
DEBUG - 2020-04-20 16:22:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:22:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:22:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:22:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 16:22:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:22:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:22:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:22:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:22:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:22:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:22:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:22:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:22:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:22:40 --> Total execution time: 0.0905
DEBUG - 2020-04-20 16:22:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:22:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:22:40 --> Total execution time: 0.1174
DEBUG - 2020-04-20 16:22:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:22:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:22:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:22:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:22:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:22:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:22:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:22:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:22:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:22:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:22:41 --> Total execution time: 0.1371
DEBUG - 2020-04-20 16:22:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:22:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:22:41 --> Total execution time: 0.0918
DEBUG - 2020-04-20 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:22:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:22:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:22:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:22:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:22:44 --> Total execution time: 0.1747
DEBUG - 2020-04-20 16:22:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:22:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 16:22:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:22:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:22:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:23:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:23:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:23:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:23:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:23:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:23:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:23:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:23:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:23:31 --> Total execution time: 0.0920
DEBUG - 2020-04-20 16:23:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:23:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:23:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:23:31 --> Total execution time: 0.1052
DEBUG - 2020-04-20 16:23:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:23:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:23:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:23:33 --> Total execution time: 0.0942
DEBUG - 2020-04-20 16:23:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:23:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:23:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:23:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:23:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:23:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:23:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 16:23:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:23:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:23:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:24:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:24:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:24:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:24:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:24:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:24:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:24:00 --> Total execution time: 0.0920
DEBUG - 2020-04-20 16:24:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:24:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:24:01 --> Total execution time: 0.1180
DEBUG - 2020-04-20 16:24:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:24:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:24:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:24:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:24:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:24:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:24:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:24:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:24:02 --> Total execution time: 0.1411
DEBUG - 2020-04-20 16:24:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:24:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:24:02 --> Total execution time: 0.1034
DEBUG - 2020-04-20 16:24:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:24:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:24:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:24:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:24:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:24:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:24:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:24:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:24:26 --> Total execution time: 0.0882
DEBUG - 2020-04-20 16:24:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:24:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:24:27 --> Total execution time: 0.1105
DEBUG - 2020-04-20 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:24:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:24:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:24:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:24:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:24:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:24:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:24:28 --> Total execution time: 0.0938
DEBUG - 2020-04-20 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:24:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:24:28 --> Total execution time: 0.1083
DEBUG - 2020-04-20 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:24:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:24:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 16:24:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:24:33 --> Total execution time: 0.0837
DEBUG - 2020-04-20 16:24:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:24:33 --> Total execution time: 0.1036
DEBUG - 2020-04-20 16:24:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:24:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:24:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:24:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:26:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:26:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:26:20 --> Total execution time: 0.3399
DEBUG - 2020-04-20 16:26:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:26:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:26:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:26:21 --> Total execution time: 0.1203
DEBUG - 2020-04-20 16:26:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:26:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:26:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:26:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:29:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:29:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:29:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:29:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:29:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:29:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:29:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:29:02 --> Total execution time: 0.1223
DEBUG - 2020-04-20 16:29:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:29:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:29:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:29:02 --> Total execution time: 0.1236
DEBUG - 2020-04-20 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:29:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:29:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:29:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:29:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:29:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:29:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:29:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:29:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:29:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:29:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:29:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:29:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:29:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:29:09 --> Total execution time: 0.0860
DEBUG - 2020-04-20 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:29:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:29:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:29:09 --> Total execution time: 0.1856
DEBUG - 2020-04-20 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:29:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:29:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:29:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:29:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:29:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:29:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:29:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:29:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:29:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:29:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:29:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:29:54 --> Total execution time: 0.3067
DEBUG - 2020-04-20 16:29:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:29:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:29:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:29:55 --> Total execution time: 0.2828
DEBUG - 2020-04-20 16:29:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:29:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:29:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:29:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:31:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:31:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:31:03 --> Total execution time: 0.1101
DEBUG - 2020-04-20 16:31:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:31:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:31:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:31:03 --> Total execution time: 0.1082
DEBUG - 2020-04-20 16:31:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:31:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:31:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:31:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:32:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:32:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:32:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:32:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:32:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:32:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:32:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:32:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:32:05 --> Total execution time: 0.1366
DEBUG - 2020-04-20 16:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:32:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:32:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:32:06 --> Total execution time: 0.1037
DEBUG - 2020-04-20 16:32:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:32:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:32:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:32:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:32:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:32:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:32:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:32:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:32:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:32:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:32:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:32:43 --> Total execution time: 0.0831
DEBUG - 2020-04-20 16:32:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:32:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:32:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:32:43 --> Total execution time: 0.1045
DEBUG - 2020-04-20 16:32:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:32:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:46:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:46:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:46:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:46:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:46:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:46:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:46:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:46:07 --> Total execution time: 0.7414
DEBUG - 2020-04-20 16:46:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:46:08 --> Total execution time: 0.1299
DEBUG - 2020-04-20 16:46:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:46:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:46:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:46:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 20:46:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\modeltest\views\all-model-question.php 16
DEBUG - 2020-04-20 20:46:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:46:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:46:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:46:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:46:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:46:21 --> Total execution time: 0.4356
DEBUG - 2020-04-20 16:46:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:46:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:46:21 --> Total execution time: 0.0995
DEBUG - 2020-04-20 16:46:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:46:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:46:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:46:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 20:46:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\shipan7.2\htdocs\xplore\application\modules\modeltest\views\all-model-question.php 16
DEBUG - 2020-04-20 20:46:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:46:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:46:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:46:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:46:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:46:43 --> Total execution time: 0.1908
DEBUG - 2020-04-20 16:46:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:46:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:46:43 --> Total execution time: 0.1218
DEBUG - 2020-04-20 16:46:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:46:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:46:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:46:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:46:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:46:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:46:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:46:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:46:53 --> Total execution time: 0.1420
DEBUG - 2020-04-20 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:46:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:46:53 --> Total execution time: 0.0820
DEBUG - 2020-04-20 16:46:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:46:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:46:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:48:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:48:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:48:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:48:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:48:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:48:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:48:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:48:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:48:06 --> Total execution time: 0.1356
DEBUG - 2020-04-20 16:48:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:48:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:48:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:48:07 --> Total execution time: 0.1153
DEBUG - 2020-04-20 16:48:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:48:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:48:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:48:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:48:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:48:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:48:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:48:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:48:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:48:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:48:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:48:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:48:12 --> Total execution time: 0.1388
DEBUG - 2020-04-20 16:48:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:48:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:48:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:48:12 --> Total execution time: 0.1037
DEBUG - 2020-04-20 16:48:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:48:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:48:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:48:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:48:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-04-20 20:48:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:48:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:48:15 --> Total execution time: 0.6135
DEBUG - 2020-04-20 16:48:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:48:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:48:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:48:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 20:48:18 --> Total execution time: 0.2454
DEBUG - 2020-04-20 16:48:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:48:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:48:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:48:20 --> Total execution time: 0.2318
ERROR - 2020-04-20 20:48:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:51:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:51:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:51:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:51:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:51:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:51:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:51:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:51:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:51:49 --> Total execution time: 0.2705
DEBUG - 2020-04-20 16:51:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:51:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:51:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:51:49 --> Total execution time: 0.1092
DEBUG - 2020-04-20 16:51:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:51:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:51:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:51:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:51:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:51:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:51:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:51:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:51:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:51:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:51:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:51:59 --> Total execution time: 0.1403
DEBUG - 2020-04-20 16:51:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:51:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:51:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:51:59 --> Total execution time: 0.1107
DEBUG - 2020-04-20 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:52:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:52:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:53:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:53:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:53:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:53:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:53:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:53:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:53:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:53:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:53:58 --> Total execution time: 0.1785
DEBUG - 2020-04-20 16:53:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:53:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:53:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:53:58 --> Total execution time: 0.1197
DEBUG - 2020-04-20 16:53:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:53:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:53:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:54:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:54:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:54:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 20:54:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:54:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:54:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:54:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:54:01 --> Total execution time: 0.1059
DEBUG - 2020-04-20 16:54:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:54:02 --> Total execution time: 0.1094
DEBUG - 2020-04-20 16:54:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:54:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 16:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:54:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:54:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:54:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:54:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:54:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:54:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:54:05 --> Total execution time: 0.1099
DEBUG - 2020-04-20 16:54:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:54:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:54:05 --> Total execution time: 0.1056
DEBUG - 2020-04-20 16:54:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:54:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:54:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:54:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:54:08 --> Total execution time: 0.2488
DEBUG - 2020-04-20 16:54:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:54:22 --> Total execution time: 0.1721
DEBUG - 2020-04-20 16:54:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:54:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:54:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:54:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:54:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:54:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:54:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:54:23 --> Total execution time: 0.1381
DEBUG - 2020-04-20 16:54:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:54:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:54:24 --> Total execution time: 0.0941
DEBUG - 2020-04-20 16:54:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:54:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:54:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:54:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 16:54:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:54:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:54:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 16:55:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:55:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:55:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:55:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:55:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:55:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:55:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:55:08 --> Total execution time: 0.2765
DEBUG - 2020-04-20 16:55:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:55:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:55:09 --> Total execution time: 0.1463
DEBUG - 2020-04-20 16:55:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:55:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:55:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:55:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:55:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:55:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:55:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:55:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:55:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:55:17 --> Total execution time: 0.1507
DEBUG - 2020-04-20 16:55:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:55:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:55:17 --> Total execution time: 0.1092
DEBUG - 2020-04-20 16:55:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:55:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:55:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:55:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:55:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:55:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:55:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:55:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:55:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:55:38 --> Total execution time: 0.3042
DEBUG - 2020-04-20 16:55:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:55:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:55:38 --> Total execution time: 0.1369
DEBUG - 2020-04-20 16:55:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:55:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:55:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:55:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:55:51 --> Total execution time: 0.4451
DEBUG - 2020-04-20 16:55:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:55:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:55:51 --> Total execution time: 0.4474
DEBUG - 2020-04-20 16:55:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:55:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:55:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:55:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:55:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:55:57 --> Total execution time: 0.1547
DEBUG - 2020-04-20 16:56:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:56:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:56:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:56:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:56:03 --> Total execution time: 0.1287
ERROR - 2020-04-20 20:56:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:56:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:56:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:56:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:56:15 --> Total execution time: 0.1535
DEBUG - 2020-04-20 16:56:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:56:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:56:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 20:56:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 20:56:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 20:56:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 20:56:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 20:56:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 20:56:18 --> Total execution time: 0.1387
DEBUG - 2020-04-20 16:56:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:56:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:56:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:56:18 --> Total execution time: 0.1297
DEBUG - 2020-04-20 16:56:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:56:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:56:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 16:56:19 --> Total execution time: 0.0896
DEBUG - 2020-04-20 16:56:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:56:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 20:56:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 16:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 16:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 16:56:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 16:56:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 20:56:26 --> Total execution time: 0.1312
ERROR - 2020-04-20 20:56:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 17:00:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:00:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:00:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:00:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:00:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:00:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:00:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:00:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:00:58 --> Total execution time: 0.2070
DEBUG - 2020-04-20 17:00:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:00:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:00:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:00:58 --> Total execution time: 0.0801
DEBUG - 2020-04-20 17:00:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:00:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:00:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:00:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:00:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:00:59 --> Total execution time: 0.1606
DEBUG - 2020-04-20 17:00:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:00:59 --> Total execution time: 0.2373
DEBUG - 2020-04-20 17:01:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:01:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:01:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:01:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:01:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:01:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:01:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:01:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:01:07 --> Total execution time: 0.1835
DEBUG - 2020-04-20 17:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:01:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:01:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:01:08 --> Total execution time: 0.1047
DEBUG - 2020-04-20 17:01:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:01:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:01:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:01:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:01:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:01:09 --> Total execution time: 0.1252
DEBUG - 2020-04-20 17:01:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:01:09 --> Total execution time: 0.1712
DEBUG - 2020-04-20 17:02:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:02:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:02:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:02:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:02:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:02:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:02:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:02:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:02:34 --> Total execution time: 0.2043
DEBUG - 2020-04-20 17:02:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:02:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:02:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:02:34 --> Total execution time: 0.1429
DEBUG - 2020-04-20 17:02:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:02:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:02:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:02:35 --> Total execution time: 0.1010
DEBUG - 2020-04-20 17:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:02:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:02:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:02:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 21:02:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:02:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:02:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:02:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:02:45 --> Total execution time: 0.1088
DEBUG - 2020-04-20 17:02:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:02:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:02:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:02:45 --> Total execution time: 0.1399
DEBUG - 2020-04-20 17:02:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:02:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:02:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:02:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 17:02:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:02:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:02:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:02:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:02:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:02:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:02:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:02:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:02:49 --> Total execution time: 0.2075
DEBUG - 2020-04-20 17:02:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:02:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:02:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:02:49 --> Total execution time: 0.0848
DEBUG - 2020-04-20 17:02:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:02:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:02:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:02:50 --> Total execution time: 0.2247
DEBUG - 2020-04-20 17:03:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:03:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:03:06 --> Total execution time: 0.2150
DEBUG - 2020-04-20 17:03:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:03:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:03:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:03:07 --> Total execution time: 0.1374
DEBUG - 2020-04-20 17:03:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:03:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:03:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:03:08 --> Total execution time: 0.1750
DEBUG - 2020-04-20 17:03:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:03:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:03:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:03:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:03:13 --> Total execution time: 0.1963
DEBUG - 2020-04-20 17:03:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:03:13 --> Total execution time: 0.2693
DEBUG - 2020-04-20 17:03:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:03:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:03:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:03:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:03:15 --> Total execution time: 0.1556
DEBUG - 2020-04-20 17:03:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:03:15 --> Total execution time: 0.2119
DEBUG - 2020-04-20 17:04:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:04:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:04:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:04:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:04:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:04:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:04:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:04:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:04:21 --> Total execution time: 0.1833
DEBUG - 2020-04-20 17:04:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:04:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:04:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:04:22 --> Total execution time: 0.1263
DEBUG - 2020-04-20 17:04:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:04:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:04:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:04:23 --> Total execution time: 0.1211
DEBUG - 2020-04-20 17:04:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:04:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:04:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:04:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:04:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:04:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:04:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:04:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:04:58 --> Total execution time: 0.1262
DEBUG - 2020-04-20 17:04:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:04:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:04:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:04:58 --> Total execution time: 0.0873
DEBUG - 2020-04-20 17:04:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:04:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:04:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:04:59 --> Total execution time: 0.1159
DEBUG - 2020-04-20 17:05:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:05:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:05:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:05:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:05:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:05:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:05:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:05:06 --> Total execution time: 0.1893
DEBUG - 2020-04-20 17:05:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:05:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:05:06 --> Total execution time: 0.1138
DEBUG - 2020-04-20 17:05:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:05:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:05:07 --> Total execution time: 0.1360
DEBUG - 2020-04-20 17:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:05:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:05:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:05:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:05:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:05:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:05:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:05:16 --> Total execution time: 0.1554
DEBUG - 2020-04-20 17:05:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:05:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:05:16 --> Total execution time: 0.1011
DEBUG - 2020-04-20 17:05:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:05:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:05:17 --> Total execution time: 0.1098
DEBUG - 2020-04-20 17:05:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:05:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:05:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:05:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:05:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:05:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:05:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:05:24 --> Total execution time: 0.1506
DEBUG - 2020-04-20 17:05:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:05:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:05:24 --> Total execution time: 0.1664
DEBUG - 2020-04-20 17:05:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:05:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:05:25 --> Total execution time: 0.1461
DEBUG - 2020-04-20 17:05:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:05:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:05:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:05:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:05:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:05:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:05:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:05:35 --> Total execution time: 0.2080
DEBUG - 2020-04-20 17:05:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:05:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:05:35 --> Total execution time: 0.1185
DEBUG - 2020-04-20 17:05:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:05:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:05:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:05:36 --> Total execution time: 0.1135
DEBUG - 2020-04-20 17:06:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:06:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:06:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:06:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:06:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:06:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:06:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:06:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:06:45 --> Total execution time: 0.2407
DEBUG - 2020-04-20 17:06:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:06:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:06:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:06:46 --> Total execution time: 0.1402
DEBUG - 2020-04-20 17:06:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:06:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:06:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:06:47 --> Total execution time: 0.1274
DEBUG - 2020-04-20 17:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:07:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:07:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:07:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:07:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:07:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:07:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:07:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:07:04 --> Total execution time: 0.2247
DEBUG - 2020-04-20 17:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:07:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:07:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:07:04 --> Total execution time: 0.2077
DEBUG - 2020-04-20 17:07:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:07:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:07:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:07:05 --> Total execution time: 0.1181
DEBUG - 2020-04-20 17:07:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:07:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:07:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:07:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:07:09 --> Total execution time: 0.1832
DEBUG - 2020-04-20 17:07:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:07:09 --> Total execution time: 0.3960
DEBUG - 2020-04-20 17:07:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:07:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:07:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:07:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:07:10 --> Total execution time: 0.1140
DEBUG - 2020-04-20 17:07:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:07:10 --> Total execution time: 0.4767
DEBUG - 2020-04-20 17:31:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:31:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-04-20 17:31:06 --> Severity: error --> Exception: syntax error, unexpected ')' D:\shipan7.2\htdocs\xplore\application\modules\modeltest\controllers\Modeltest.php 235
DEBUG - 2020-04-20 17:31:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:31:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:31:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:31:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 21:31:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:31:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:31:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:31:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:31:23 --> Total execution time: 0.2200
DEBUG - 2020-04-20 17:31:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:31:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:31:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:31:23 --> Total execution time: 0.2505
DEBUG - 2020-04-20 17:31:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:31:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:31:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:31:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 17:31:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:31:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:31:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:31:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:31:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:31:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:31:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:31:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:31:28 --> Total execution time: 0.1712
DEBUG - 2020-04-20 17:31:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:31:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:31:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:31:29 --> Total execution time: 0.1071
DEBUG - 2020-04-20 17:31:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:31:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:31:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 21:31:30 --> Query error: Unknown column 'TQ.topic_id' in 'field list' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`title`, `TQ`.`topic_id`, `SA`.`section_id`, `SUBA`.`id` as `subject_id`
FROM `question` as `Q`
LEFT JOIN `topic_assign` as `TA` ON `TQ`.`topic_id` = `TA`.`topic_id`
LEFT JOIN `section_assign` as `SA` ON `TA`.`section_id` = `SA`.`section_id`
LEFT JOIN `subject_assign` as `SUBA` ON `SA`.`subject_id` = `SUBA`.`subject_id`
WHERE `TQ`.`category_id` = '1'
) CI_count_all_results
DEBUG - 2020-04-20 17:32:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:32:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:32:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:32:10 --> Total execution time: 0.2260
DEBUG - 2020-04-20 17:32:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:32:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:32:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:32:10 --> Total execution time: 0.1185
DEBUG - 2020-04-20 17:32:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:32:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:32:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 21:32:11 --> Query error: Unknown column 'TQ.topic_id' in 'field list' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`title`, `TQ`.`topic_id`, `SA`.`section_id`, `SUBA`.`id` as `subject_id`
FROM `question` as `Q`
LEFT JOIN `topic_assign` as `TA` ON `TQ`.`topic_id` = `TA`.`topic_id`
LEFT JOIN `section_assign` as `SA` ON `TA`.`section_id` = `SA`.`section_id`
LEFT JOIN `subject_assign` as `SUBA` ON `SA`.`subject_id` = `SUBA`.`subject_id`
WHERE `TQ`.`category_id` = '1'
) CI_count_all_results
DEBUG - 2020-04-20 17:32:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:32:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:32:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:32:14 --> Total execution time: 0.1275
DEBUG - 2020-04-20 17:32:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:32:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:32:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:32:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:32:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:32:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:32:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:32:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:32:18 --> Total execution time: 0.1447
DEBUG - 2020-04-20 17:32:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:32:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:32:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:32:18 --> Total execution time: 0.1209
DEBUG - 2020-04-20 17:32:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:32:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:32:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:32:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:32:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 21:32:19 --> Query error: Unknown column 'TQ.topic_id' in 'field list' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`title`, `TQ`.`topic_id`, `SA`.`section_id`, `SUBA`.`id` as `subject_id`
FROM `question` as `Q`
LEFT JOIN `topic_assign` as `TA` ON `TQ`.`topic_id` = `TA`.`topic_id`
LEFT JOIN `section_assign` as `SA` ON `TA`.`section_id` = `SA`.`section_id`
LEFT JOIN `subject_assign` as `SUBA` ON `SA`.`subject_id` = `SUBA`.`subject_id`
WHERE `TQ`.`category_id` = '1'
) CI_count_all_results
DEBUG - 2020-04-20 17:32:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:32:19 --> Total execution time: 0.2265
DEBUG - 2020-04-20 17:33:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:33:03 --> Total execution time: 0.1211
DEBUG - 2020-04-20 17:33:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:33:03 --> Total execution time: 0.1166
DEBUG - 2020-04-20 17:33:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:33:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 21:33:04 --> Query error: Not unique table/alias: 'TA' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`title`, `TQ`.`topic_id`, `SA`.`section_id`, `SUBA`.`id` as `subject_id`
FROM `question` as `Q`
LEFT JOIN `topics_questions` `TQ` ON `Q`.`id` = `TQ`.`question_id`
LEFT JOIN `topic_assign` as `TA` ON `TQ`.`topic_id` = `TA`.`topic_id`
LEFT JOIN `topic_assign` as `TA` ON `TQ`.`topic_id` = `TA`.`topic_id`
LEFT JOIN `section_assign` as `SA` ON `TA`.`section_id` = `SA`.`section_id`
LEFT JOIN `subject_assign` as `SUBA` ON `SA`.`subject_id` = `SUBA`.`subject_id`
WHERE `TQ`.`category_id` = '1'
) CI_count_all_results
DEBUG - 2020-04-20 17:33:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:33:04 --> Total execution time: 0.2770
DEBUG - 2020-04-20 17:33:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:33:17 --> Total execution time: 0.1757
DEBUG - 2020-04-20 17:33:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:33:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:33:17 --> Total execution time: 0.1115
DEBUG - 2020-04-20 17:33:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:33:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:33:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:33:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:33:20 --> Total execution time: 0.7229
DEBUG - 2020-04-20 17:33:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:33:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:33:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:33:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:33:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:33:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:33:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:33:48 --> Total execution time: 0.2137
DEBUG - 2020-04-20 17:33:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:33:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:33:49 --> Total execution time: 0.1043
DEBUG - 2020-04-20 17:33:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:33:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:33:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:33:50 --> Total execution time: 0.1632
DEBUG - 2020-04-20 21:33:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:33:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:33:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:33:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:33:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:33:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:33:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:33:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:33:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:34:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:34:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:34:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:34:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:34:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:34:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:34:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:34:00 --> Total execution time: 0.1450
DEBUG - 2020-04-20 17:34:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:34:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:34:00 --> Total execution time: 0.1067
DEBUG - 2020-04-20 17:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:34:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:34:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:34:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:34:02 --> Total execution time: 0.4450
DEBUG - 2020-04-20 17:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:34:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:34:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:34:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:34:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:34:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:34:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:34:43 --> Total execution time: 0.1550
DEBUG - 2020-04-20 17:34:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:34:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:34:43 --> Total execution time: 0.1260
DEBUG - 2020-04-20 17:34:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:34:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:34:44 --> Total execution time: 0.1324
DEBUG - 2020-04-20 21:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:34:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:34:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 17:34:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:34:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 21:34:53 --> Total execution time: 0.7604
DEBUG - 2020-04-20 17:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:34:57 --> Total execution time: 0.1470
DEBUG - 2020-04-20 21:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:34:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:34:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:34:59 --> Total execution time: 0.1200
DEBUG - 2020-04-20 21:34:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:34:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:35:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:35:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:35:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:35:01 --> Total execution time: 0.1111
DEBUG - 2020-04-20 21:35:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:35:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:35:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:35:22 --> Total execution time: 0.1693
DEBUG - 2020-04-20 17:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:35:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:35:22 --> Total execution time: 0.0786
DEBUG - 2020-04-20 17:35:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:35:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:35:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:35:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:35:24 --> Total execution time: 0.3562
DEBUG - 2020-04-20 17:36:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:36:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:36:17 --> Total execution time: 0.1612
DEBUG - 2020-04-20 17:36:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:36:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:36:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:36:18 --> Total execution time: 0.1250
DEBUG - 2020-04-20 17:36:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:36:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:36:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:36:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:36:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:36:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:36:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:36:19 --> Total execution time: 0.2877
DEBUG - 2020-04-20 17:37:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:37:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:37:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:37:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:37:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:37:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:37:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:37:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:37:51 --> Total execution time: 0.1684
DEBUG - 2020-04-20 17:37:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:37:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:37:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:37:51 --> Total execution time: 0.1028
DEBUG - 2020-04-20 17:37:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:37:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:37:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:37:52 --> Total execution time: 0.1512
DEBUG - 2020-04-20 17:38:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:38:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:38:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:38:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:38:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:38:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:38:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:38:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:38:09 --> Total execution time: 0.2262
DEBUG - 2020-04-20 17:38:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:38:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:38:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:38:09 --> Total execution time: 0.1247
DEBUG - 2020-04-20 17:38:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:38:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:38:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:38:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:38:11 --> Total execution time: 0.1870
DEBUG - 2020-04-20 21:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 17:38:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:38:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:38:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:38:11 --> Total execution time: 0.3851
DEBUG - 2020-04-20 17:38:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:38:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:41:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:41:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:41:38 --> Total execution time: 0.2416
DEBUG - 2020-04-20 17:41:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:41:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:41:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:41:39 --> Total execution time: 0.1526
DEBUG - 2020-04-20 17:41:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:41:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:41:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:41:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:41:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:41:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:41:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:41:40 --> Total execution time: 0.3387
DEBUG - 2020-04-20 17:41:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:41:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:41:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:41:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:41:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:41:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 21:41:43 --> Total execution time: 0.3401
DEBUG - 2020-04-20 17:41:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:41:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:41:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:41:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:41:48 --> Total execution time: 0.1877
DEBUG - 2020-04-20 21:41:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:41:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:54:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:54:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:54:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
ERROR - 2020-04-20 21:54:57 --> Severity: Notice --> Undefined variable: model_test_id D:\shipan7.2\htdocs\xplore\application\modules\modeltest\views\all-model-question.php 11
DEBUG - 2020-04-20 21:54:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:54:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:54:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:54:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:54:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:54:57 --> Total execution time: 0.4598
DEBUG - 2020-04-20 17:54:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:54:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:54:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:54:58 --> Total execution time: 0.2175
DEBUG - 2020-04-20 17:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:54:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:54:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:54:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:54:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:54:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:54:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:54:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:54:59 --> Total execution time: 0.5318
DEBUG - 2020-04-20 17:55:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:55:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:55:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:55:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:55:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:55:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:55:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:55:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:55:31 --> Total execution time: 0.2089
DEBUG - 2020-04-20 17:55:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:55:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:55:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:55:31 --> Total execution time: 0.1245
DEBUG - 2020-04-20 17:55:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:55:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:55:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:55:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:55:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:55:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:55:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:55:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:55:33 --> Total execution time: 0.4518
DEBUG - 2020-04-20 17:55:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:55:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:55:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:55:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:55:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:55:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:55:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:55:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:55:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:55:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:55:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:55:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:55:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:55:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:55:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:55:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:55:58 --> Total execution time: 0.2420
DEBUG - 2020-04-20 17:55:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:55:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:55:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:55:59 --> Total execution time: 0.1424
DEBUG - 2020-04-20 17:55:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:55:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:55:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:55:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:56:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:56:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:56:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:56:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:56:29 --> Total execution time: 0.1274
DEBUG - 2020-04-20 21:56:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:56:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:56:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:56:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:56:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:56:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:56:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:56:43 --> Total execution time: 0.1070
DEBUG - 2020-04-20 21:56:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:56:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:56:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:56:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:56:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:56:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:56:50 --> Total execution time: 0.1658
DEBUG - 2020-04-20 17:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:56:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:56:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:56:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:56:56 --> Total execution time: 0.1504
DEBUG - 2020-04-20 21:56:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:56:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:56:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:57:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:57:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:57:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:57:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:57:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:57:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:57:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:57:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:57:52 --> Total execution time: 0.2401
DEBUG - 2020-04-20 17:57:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:57:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:57:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:57:53 --> Total execution time: 0.2303
DEBUG - 2020-04-20 17:57:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:57:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:57:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:57:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:57:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:57:54 --> Total execution time: 0.1265
DEBUG - 2020-04-20 21:57:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:57:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:57:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:58:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:58:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:58:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:58:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:58:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:58:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 21:58:06 --> Total execution time: 0.4461
DEBUG - 2020-04-20 17:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:58:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:58:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:58:09 --> Total execution time: 0.1840
DEBUG - 2020-04-20 21:58:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:58:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:58:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:59:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:59:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:59:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:59:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:59:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:59:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:59:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:59:05 --> Total execution time: 0.3122
DEBUG - 2020-04-20 17:59:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:59:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:59:05 --> Total execution time: 0.1555
DEBUG - 2020-04-20 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:59:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:59:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:59:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:59:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:59:07 --> Total execution time: 0.5503
DEBUG - 2020-04-20 17:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:59:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:59:09 --> Total execution time: 0.1136
DEBUG - 2020-04-20 21:59:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:59:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:59:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:59:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:59:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:59:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:59:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:59:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:59:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:59:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:59:20 --> Total execution time: 0.1220
DEBUG - 2020-04-20 17:59:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:59:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:59:20 --> Total execution time: 0.1183
DEBUG - 2020-04-20 17:59:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:59:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:59:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:59:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:59:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:59:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 21:59:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 21:59:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 21:59:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 21:59:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 21:59:48 --> Total execution time: 0.1151
DEBUG - 2020-04-20 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 17:59:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:59:48 --> Total execution time: 0.1241
DEBUG - 2020-04-20 17:59:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:59:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:59:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 21:59:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 17:59:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:59:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:59:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 17:59:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 17:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 17:59:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 21:59:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 21:59:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:00:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:00:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:00:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:00:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:00:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:00:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:00:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:00:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:00:59 --> Total execution time: 0.1588
DEBUG - 2020-04-20 18:00:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:00:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:00:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:00:59 --> Total execution time: 0.1298
DEBUG - 2020-04-20 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 22:01:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 18:01:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:01:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:01:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:01:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:01:01 --> Total execution time: 0.2636
DEBUG - 2020-04-20 22:01:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:01:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:01:01 --> Total execution time: 0.0978
DEBUG - 2020-04-20 18:01:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:01:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:12 --> Total execution time: 0.1016
DEBUG - 2020-04-20 22:01:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:01:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:01:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:01:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:01:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:04:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:04:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:04:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:04:47 --> Total execution time: 0.2054
DEBUG - 2020-04-20 18:04:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:04:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:04:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:04:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:04:51 --> Total execution time: 0.0987
DEBUG - 2020-04-20 22:04:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:07:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:07:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:07:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:07:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:07:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:07:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:07:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:07:16 --> Total execution time: 0.2415
DEBUG - 2020-04-20 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:07:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:07:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:07:17 --> Total execution time: 0.1504
DEBUG - 2020-04-20 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:07:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:07:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:07:18 --> Total execution time: 0.1026
DEBUG - 2020-04-20 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:07:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:07:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:07:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:07:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:07:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:07:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:07:25 --> Total execution time: 0.2100
DEBUG - 2020-04-20 18:10:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:10:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:10:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:10:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:10:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:10:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:10:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:10:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:10:06 --> Total execution time: 0.1574
DEBUG - 2020-04-20 18:10:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:10:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:10:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:10:07 --> Total execution time: 0.1152
DEBUG - 2020-04-20 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:10:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:10:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:10:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:10:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:10:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:10:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:10:08 --> Total execution time: 0.4328
DEBUG - 2020-04-20 18:10:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:10:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:10:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:10:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:10:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:10:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:10:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 22:10:13 --> Total execution time: 0.3131
DEBUG - 2020-04-20 18:10:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:10:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:10:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:10:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:10:17 --> Total execution time: 0.1482
DEBUG - 2020-04-20 22:10:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:10:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:10:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:12:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:12:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:12:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:12:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:12:01 --> Total execution time: 0.1308
DEBUG - 2020-04-20 22:12:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:12:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:12:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:14:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:14:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:14:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:14:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:14:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:14:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:14:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:14:18 --> Total execution time: 0.2894
DEBUG - 2020-04-20 18:14:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:14:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:14:19 --> Total execution time: 0.1158
DEBUG - 2020-04-20 18:14:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:14:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:14:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:14:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:14:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:14:20 --> Total execution time: 0.4652
DEBUG - 2020-04-20 18:14:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:14:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:14:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:14:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:14:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:14:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:14:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:14:23 --> Total execution time: 0.1637
DEBUG - 2020-04-20 18:14:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:14:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:14:23 --> Total execution time: 0.1030
DEBUG - 2020-04-20 18:14:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:14:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:14:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:14:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:14:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:14:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:14:25 --> Total execution time: 0.5132
DEBUG - 2020-04-20 18:14:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:14:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:14:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:14:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:14:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:14:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:14:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:14:51 --> Total execution time: 0.1985
DEBUG - 2020-04-20 18:14:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:14:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:14:51 --> Total execution time: 0.1487
DEBUG - 2020-04-20 18:14:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:14:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:14:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:14:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:14:53 --> Total execution time: 0.1531
DEBUG - 2020-04-20 22:14:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:14:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:14:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:18:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:18:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:18:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:18:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:18:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:18:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:18:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:18:18 --> Total execution time: 0.2329
DEBUG - 2020-04-20 18:18:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:18:18 --> Total execution time: 0.4235
DEBUG - 2020-04-20 18:18:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:18:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:18:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:18:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:18:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:18:21 --> Total execution time: 0.3597
DEBUG - 2020-04-20 18:18:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:18:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-20 22:18:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-20 22:18:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:18:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:18:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:18:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:18:27 --> Total execution time: 1.2095
DEBUG - 2020-04-20 18:18:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:18:27 --> Total execution time: 0.1435
DEBUG - 2020-04-20 18:18:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:18:29 --> Total execution time: 0.0892
DEBUG - 2020-04-20 18:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:18:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 22:18:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-20 22:18:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-20 22:18:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:18:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:18:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:18:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:18:35 --> Total execution time: 0.3986
DEBUG - 2020-04-20 18:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:18:35 --> Total execution time: 0.1706
DEBUG - 2020-04-20 18:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 22:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-20 18:18:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:18:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:18:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 22:18:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:18:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:18:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:18:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:18:39 --> Total execution time: 0.3935
DEBUG - 2020-04-20 18:18:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:18:40 --> Total execution time: 0.2312
DEBUG - 2020-04-20 18:18:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 18:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:18:41 --> Total execution time: 0.3572
DEBUG - 2020-04-20 18:18:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:18:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:18:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:18:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:18:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:18:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:18:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:18:44 --> Total execution time: 0.1755
DEBUG - 2020-04-20 18:18:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:18:45 --> Total execution time: 0.1029
DEBUG - 2020-04-20 18:18:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:18:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:18:46 --> Total execution time: 0.1802
DEBUG - 2020-04-20 22:18:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:18:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:18:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:18:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:18:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:18:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:18:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:18:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:18:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:18:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:19:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:19:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:19:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:19:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:19:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 22:19:02 --> Total execution time: 1.0241
DEBUG - 2020-04-20 18:19:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:19:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:19:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:19:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:19:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:19:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:19:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:19:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:19:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:19:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:19:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:19:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:19:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:19:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:19:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:19:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:19:26 --> Total execution time: 0.3132
DEBUG - 2020-04-20 18:19:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:19:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:19:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:19:26 --> Total execution time: 0.1095
DEBUG - 2020-04-20 18:19:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:19:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:19:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:19:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:19:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:19:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:19:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:19:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:19:28 --> Total execution time: 0.6257
DEBUG - 2020-04-20 18:19:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:19:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:19:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:19:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:19:31 --> Total execution time: 0.1137
DEBUG - 2020-04-20 22:19:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:19:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:19:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:20:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:20:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:20:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:20:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:20:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:20:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:20:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:20:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:20:07 --> Total execution time: 1.2936
DEBUG - 2020-04-20 18:20:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:20:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:20:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:20:08 --> Total execution time: 0.1648
DEBUG - 2020-04-20 18:20:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:20:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:20:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:20:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:20:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:20:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:20:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:20:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:20:10 --> Total execution time: 1.4899
DEBUG - 2020-04-20 18:20:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:20:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:20:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:20:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:20:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:20:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:20:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:20:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:20:14 --> Total execution time: 0.1546
DEBUG - 2020-04-20 18:20:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:20:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:20:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:20:14 --> Total execution time: 0.1445
DEBUG - 2020-04-20 18:20:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:20:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:20:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:20:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:20:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:20:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:20:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:20:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:20:16 --> Total execution time: 0.5341
DEBUG - 2020-04-20 18:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:20:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 22:20:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:20:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:20:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:20:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 22:20:23 --> Total execution time: 1.7757
DEBUG - 2020-04-20 18:21:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:21:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:21:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:21:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:21:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:21:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:21:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:21:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:21:04 --> Total execution time: 0.1901
DEBUG - 2020-04-20 18:21:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:21:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:21:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:21:04 --> Total execution time: 0.1227
DEBUG - 2020-04-20 18:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:21:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:21:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:21:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:21:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:21:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:21:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:21:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:21:06 --> Total execution time: 0.6887
DEBUG - 2020-04-20 18:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:21:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:21:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:21:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:21:09 --> Total execution time: 0.3589
DEBUG - 2020-04-20 22:21:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:21:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:21:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:24:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:24:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:24:52 --> Total execution time: 0.3356
DEBUG - 2020-04-20 18:24:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:24:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:24:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:24:52 --> Total execution time: 0.0930
DEBUG - 2020-04-20 18:24:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:24:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:24:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:24:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:24:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:24:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:24:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:24:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:24:54 --> Total execution time: 0.4792
DEBUG - 2020-04-20 18:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:24:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:24:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:24:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:24:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:24:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:24:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 22:24:58 --> Total execution time: 2.2985
DEBUG - 2020-04-20 18:25:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:25:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:25:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:25:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:25:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:27:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:27:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:27:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:27:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:27:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:27:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:27:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:27:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:27:51 --> Total execution time: 0.1232
DEBUG - 2020-04-20 18:27:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:27:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:27:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:27:51 --> Total execution time: 0.1522
DEBUG - 2020-04-20 18:27:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:27:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:27:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:27:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:27:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:27:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:27:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:27:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:27:53 --> Total execution time: 0.5013
DEBUG - 2020-04-20 18:27:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:27:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:27:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:27:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:27:56 --> Total execution time: 0.1339
DEBUG - 2020-04-20 22:27:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:27:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:27:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:27:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:27:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:27:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:27:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:27:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:27:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:27:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:27:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:28:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:28:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:28:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:28:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:28:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:28:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:28:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:28:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:28:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:28:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:28:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:28:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:28:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:28:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:28:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:28:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:28:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:28:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:28:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:28:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:28:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:28:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:28:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:28:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:28:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:28:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:28:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:28:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:28:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:28:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:29:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:29:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:29:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:29:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 22:29:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:29:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:29:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:29:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:29:24 --> Total execution time: 0.1143
DEBUG - 2020-04-20 18:29:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:29:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:29:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:29:25 --> Total execution time: 0.1365
DEBUG - 2020-04-20 18:29:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:29:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:29:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:29:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 18:29:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:29:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:29:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:29:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:29:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:29:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:29:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:29:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:29:29 --> Total execution time: 0.1890
DEBUG - 2020-04-20 18:29:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:29:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:29:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:29:30 --> Total execution time: 0.4072
DEBUG - 2020-04-20 18:29:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:29:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:29:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:29:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:29:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:29:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:29:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:29:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:29:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:29:35 --> Total execution time: 0.1605
DEBUG - 2020-04-20 22:29:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:29:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:29:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:30:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:30:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:30:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:30:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 22:30:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:30:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:30:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:30:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:30:33 --> Total execution time: 0.1634
DEBUG - 2020-04-20 18:30:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:30:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:30:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:30:34 --> Total execution time: 0.5711
DEBUG - 2020-04-20 18:30:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:30:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:30:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:30:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 18:30:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:30:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:30:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:30:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:30:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:30:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:30:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:30:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:30:38 --> Total execution time: 0.2153
DEBUG - 2020-04-20 18:30:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:30:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:30:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:30:38 --> Total execution time: 0.0932
DEBUG - 2020-04-20 18:30:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:30:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:30:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:30:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:30:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:30:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:30:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:30:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:30:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:30:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:30:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:30:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:30:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:30:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:30:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:30:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:30:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:30:46 --> Total execution time: 0.1160
DEBUG - 2020-04-20 22:30:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:30:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:30:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:30:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:30:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:30:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:30:51 --> Total execution time: 0.1609
DEBUG - 2020-04-20 18:31:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:31:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:31:05 --> Total execution time: 0.1899
DEBUG - 2020-04-20 18:31:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:31:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:31:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:31:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:31:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:31:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:31:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:31:21 --> Total execution time: 0.1656
DEBUG - 2020-04-20 18:31:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:31:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:31:21 --> Total execution time: 0.1636
DEBUG - 2020-04-20 18:31:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:31:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:31:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:31:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:31:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:31:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:31:23 --> Total execution time: 0.3635
DEBUG - 2020-04-20 18:31:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:31:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:31:25 --> Total execution time: 0.2125
DEBUG - 2020-04-20 22:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:31:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:31:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:31:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:31:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:31:35 --> Total execution time: 0.0920
DEBUG - 2020-04-20 22:31:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:31:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:31:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:31:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:31:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:31:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:31:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:31:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:31:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:31:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:31:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:31:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:31:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:31:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:31:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:31:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:31:48 --> Total execution time: 0.1103
DEBUG - 2020-04-20 22:31:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:31:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:31:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:32:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:32:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:32:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:32:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:32:49 --> Total execution time: 0.1657
DEBUG - 2020-04-20 22:32:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:32:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:32:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:32:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:32:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:32:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:32:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:32:51 --> Total execution time: 0.1100
DEBUG - 2020-04-20 22:32:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:32:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:32:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:34:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:34:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:34:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:34:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:34:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:34:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:34:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:34:13 --> Total execution time: 0.1061
DEBUG - 2020-04-20 18:34:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:34:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:34:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:34:14 --> Total execution time: 0.1473
DEBUG - 2020-04-20 18:34:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:34:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:34:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:34:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:34:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:34:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:34:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:34:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:34:15 --> Total execution time: 0.3382
DEBUG - 2020-04-20 18:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:34:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:34:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 22:34:18 --> Total execution time: 0.3941
DEBUG - 2020-04-20 18:34:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:34:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-20 22:34:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Modeltest_Model D:\shipan7.2\htdocs\xplore\system\core\Loader.php 348
DEBUG - 2020-04-20 18:35:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:35:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:35:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-20 22:35:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-04-20 22:35:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:35:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:35:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:35:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:35:07 --> Total execution time: 0.1311
DEBUG - 2020-04-20 18:35:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:35:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:35:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:35:07 --> Total execution time: 0.1215
DEBUG - 2020-04-20 18:35:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:35:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:35:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:35:09 --> Total execution time: 0.0713
DEBUG - 2020-04-20 18:35:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:35:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:35:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:35:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:35:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-20 22:35:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-04-20 18:35:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:35:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:35:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-20 22:35:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-04-20 22:35:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:35:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:35:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:35:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:35:30 --> Total execution time: 0.1151
DEBUG - 2020-04-20 18:35:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:35:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:35:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:35:30 --> Total execution time: 0.1149
DEBUG - 2020-04-20 18:35:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:35:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:35:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-20 22:35:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-04-20 18:36:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:36:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-20 22:36:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-04-20 22:36:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:36:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:36:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:36:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:36:28 --> Total execution time: 0.3775
DEBUG - 2020-04-20 18:36:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:36:28 --> Total execution time: 0.0953
DEBUG - 2020-04-20 18:36:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:36:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-20 18:36:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:36:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-04-20 22:36:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:36:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 22:36:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:36:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:36:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:36:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:36:35 --> Total execution time: 3.6417
DEBUG - 2020-04-20 18:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:36:36 --> Total execution time: 0.0988
DEBUG - 2020-04-20 18:36:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:36:36 --> Total execution time: 0.0930
DEBUG - 2020-04-20 18:36:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:36:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:36:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 18:36:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:36:38 --> Total execution time: 0.2623
DEBUG - 2020-04-20 18:36:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:36:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:36:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:36:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:36:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:36:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:36:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:36:40 --> Total execution time: 0.1183
DEBUG - 2020-04-20 18:36:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:36:41 --> Total execution time: 0.1401
DEBUG - 2020-04-20 18:36:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:36:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:36:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:36:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:36:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:36:42 --> Total execution time: 0.4032
DEBUG - 2020-04-20 18:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:36:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:36:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:36:46 --> Total execution time: 0.1327
DEBUG - 2020-04-20 22:36:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:36:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:36:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:37:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:37:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:37:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 22:37:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:37:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:37:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:37:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:37:19 --> Total execution time: 1.5060
DEBUG - 2020-04-20 18:37:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:37:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:37:20 --> Total execution time: 0.1835
DEBUG - 2020-04-20 18:37:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:37:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:37:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 18:37:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:37:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:37:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:37:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:37:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:37:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:37:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:37:23 --> Total execution time: 0.2695
DEBUG - 2020-04-20 18:37:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:37:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:37:23 --> Total execution time: 0.1002
DEBUG - 2020-04-20 18:37:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:37:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:37:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:37:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:37:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:37:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 22:37:28 --> Total execution time: 0.5377
DEBUG - 2020-04-20 18:37:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:37:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:37:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:37:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:37:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:37:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:37:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:37:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:37:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:37:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:37:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:37:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:37:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:37:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:37:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:37:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:38:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:38:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:38:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:38:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:38:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:38:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:38:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:38:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:38:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:38:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:38:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:38:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:38:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:38:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:38:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:38:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:38:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:38:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:38:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:38:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:38:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:38:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 22:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:38:59 --> Total execution time: 0.1622
DEBUG - 2020-04-20 18:38:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:38:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:38:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:38:59 --> Total execution time: 0.1321
DEBUG - 2020-04-20 18:39:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:39:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 18:39:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:39:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:39:02 --> Total execution time: 0.1147
DEBUG - 2020-04-20 18:39:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:39:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:39:03 --> Total execution time: 0.1219
DEBUG - 2020-04-20 18:39:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:39:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:39:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:39:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:39:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:39:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:39:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:39:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:39:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:10 --> Total execution time: 0.1112
DEBUG - 2020-04-20 22:39:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:39:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:39:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:39:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:39:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:39:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:39:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:39:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:39:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 22:39:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:39:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:39:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:39:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:39:19 --> Total execution time: 0.0926
DEBUG - 2020-04-20 18:39:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:39:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:39:19 --> Total execution time: 0.1109
DEBUG - 2020-04-20 18:39:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:39:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 18:39:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:39:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:39:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:39:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:39:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:39:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:39:24 --> Total execution time: 0.1410
DEBUG - 2020-04-20 18:39:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:39:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:39:25 --> Total execution time: 0.1386
DEBUG - 2020-04-20 18:39:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:39:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:39:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:39:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:39:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:42:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:42:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 22:42:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:42:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:42:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:42:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:42:06 --> Total execution time: 0.1764
DEBUG - 2020-04-20 18:42:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:42:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:42:07 --> Total execution time: 0.1873
DEBUG - 2020-04-20 18:42:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:42:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 18:42:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:42:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-model-question.php
DEBUG - 2020-04-20 22:42:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:42:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:42:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:42:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:42:10 --> Total execution time: 0.1205
DEBUG - 2020-04-20 18:42:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:42:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:42:11 --> Total execution time: 0.1311
DEBUG - 2020-04-20 18:42:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:42:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:42:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:42:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 22:42:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-04-20 18:42:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:42:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:42:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:42:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:42:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:42:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:42:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:42:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 22:42:24 --> Total execution time: 0.5551
DEBUG - 2020-04-20 18:42:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 22:42:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-04-20 18:42:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 22:42:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-04-20 18:42:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 18:42:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:42:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/all-question-view.php
DEBUG - 2020-04-20 22:42:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-all-question-view.php
DEBUG - 2020-04-20 18:42:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 22:42:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-04-20 18:42:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-20 22:42:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-04-20 18:42:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:42:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 22:42:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 22:42:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 22:42:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 22:42:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 22:42:50 --> Total execution time: 0.0967
DEBUG - 2020-04-20 18:42:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 18:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 18:42:51 --> Total execution time: 0.1071
DEBUG - 2020-04-20 18:42:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 18:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 18:42:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 22:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 22:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/model-test-view.php
DEBUG - 2020-04-20 19:24:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 19:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 19:24:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 23:24:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/models/Modeltest_model.php
DEBUG - 2020-04-20 23:24:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/modeltest/views/index.php
DEBUG - 2020-04-20 23:24:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 23:24:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 23:24:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 23:24:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 23:24:10 --> Total execution time: 3.4373
DEBUG - 2020-04-20 19:24:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 19:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 19:24:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 23:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-20 23:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-20 23:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-20 23:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-20 23:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-20 23:24:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-20 23:24:33 --> Total execution time: 0.3837
DEBUG - 2020-04-20 19:24:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 19:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 19:24:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-20 19:24:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-20 19:24:34 --> Total execution time: 0.2395
