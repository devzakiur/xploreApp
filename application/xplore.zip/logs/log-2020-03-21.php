<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-21 09:44:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 14:44:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:44:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 14:44:29 --> Total execution time: 1.6896
DEBUG - 2020-03-21 09:44:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:44:51 --> No URI present. Default controller set.
DEBUG - 2020-03-21 09:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:44:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:44:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-21 09:44:52 --> Total execution time: 0.6766
DEBUG - 2020-03-21 09:44:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:44:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:44:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-21 09:44:52 --> Total execution time: 0.2050
DEBUG - 2020-03-21 09:44:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:44:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:44:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-21 09:44:53 --> Total execution time: 0.0415
DEBUG - 2020-03-21 09:45:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-21 09:45:05 --> Total execution time: 0.0854
DEBUG - 2020-03-21 09:45:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-21 09:45:05 --> Total execution time: 0.0434
DEBUG - 2020-03-21 09:45:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-21 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-21 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-21 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-21 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-21 14:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-21 14:45:13 --> Total execution time: 0.2806
DEBUG - 2020-03-21 09:45:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-21 09:45:13 --> Total execution time: 0.0725
DEBUG - 2020-03-21 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:45:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-21 14:45:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-21 14:45:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-21 14:45:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-21 14:45:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-21 14:45:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-21 14:45:19 --> Total execution time: 0.2493
DEBUG - 2020-03-21 09:45:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-21 09:45:19 --> Total execution time: 0.0406
DEBUG - 2020-03-21 09:45:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:45:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-21 14:45:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-21 09:45:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:45:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-21 14:45:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-21 14:45:23 --> Total execution time: 0.1672
DEBUG - 2020-03-21 09:45:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:45:25 --> Total execution time: 0.1929
DEBUG - 2020-03-21 14:45:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-21 14:45:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-21 09:45:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:45:26 --> Total execution time: 0.0427
DEBUG - 2020-03-21 14:45:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-21 14:45:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-21 09:45:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:45:28 --> Total execution time: 0.0404
DEBUG - 2020-03-21 14:45:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-21 14:45:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-21 09:45:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:45:30 --> Total execution time: 0.0390
DEBUG - 2020-03-21 14:45:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-21 14:45:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-21 09:45:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:45:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-21 14:45:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-21 09:45:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 09:45:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 09:45:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-21 09:45:40 --> Total execution time: 0.0497
DEBUG - 2020-03-21 09:46:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 14:46:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:46:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 14:46:37 --> Total execution time: 0.0670
DEBUG - 2020-03-21 09:49:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 14:49:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:49:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-21 14:49:33 --> Severity: Notice --> Undefined index: library_id D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 123
ERROR - 2020-03-21 14:49:33 --> Severity: Notice --> Undefined index: library_id D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 124
DEBUG - 2020-03-21 14:49:33 --> Total execution time: 0.2845
DEBUG - 2020-03-21 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 14:49:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:49:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 14:49:46 --> Total execution time: 0.1631
DEBUG - 2020-03-21 09:51:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 14:51:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:51:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 14:51:29 --> Total execution time: 0.0730
DEBUG - 2020-03-21 09:52:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 14:52:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:52:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 14:52:07 --> Total execution time: 0.0627
DEBUG - 2020-03-21 09:52:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 09:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 14:52:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 14:52:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 14:52:59 --> Total execution time: 0.0679
DEBUG - 2020-03-21 10:20:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:20:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:20:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-21 10:20:20 --> Severity: Notice --> Undefined property: PasswordController::$user D:\shipan7.2\htdocs\xplore\application\controllers\api\PasswordController.php 22
ERROR - 2020-03-21 10:20:20 --> Severity: error --> Exception: Call to a member function get_single() on null D:\shipan7.2\htdocs\xplore\application\controllers\api\PasswordController.php 22
DEBUG - 2020-03-21 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:20:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:20:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 10:20:43 --> Total execution time: 0.3509
DEBUG - 2020-03-21 10:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:20:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:20:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 10:20:46 --> Total execution time: 0.2976
DEBUG - 2020-03-21 10:23:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:23:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:23:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 10:23:42 --> Total execution time: 2.6764
DEBUG - 2020-03-21 10:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:24:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:24:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 10:24:20 --> Total execution time: 2.4417
DEBUG - 2020-03-21 10:25:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:25:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:25:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 10:25:08 --> Total execution time: 0.1621
DEBUG - 2020-03-21 10:25:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:25:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:25:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 10:25:36 --> Total execution time: 0.2138
DEBUG - 2020-03-21 10:27:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:27:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:27:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 10:27:12 --> Total execution time: 0.1058
DEBUG - 2020-03-21 10:29:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:29:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:29:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 10:29:00 --> Total execution time: 0.0516
DEBUG - 2020-03-21 10:29:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:29:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:29:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-21 10:29:30 --> Severity: Notice --> Undefined property: PasswordController::$enc_lib D:\shipan7.2\htdocs\xplore\application\controllers\api\PasswordController.php 107
ERROR - 2020-03-21 10:29:30 --> Severity: error --> Exception: Call to a member function passHashEnc() on null D:\shipan7.2\htdocs\xplore\application\controllers\api\PasswordController.php 107
DEBUG - 2020-03-21 10:29:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:29:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:29:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 10:29:49 --> Total execution time: 0.1708
DEBUG - 2020-03-21 10:30:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:30:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:30:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 15:30:00 --> Total execution time: 0.1314
DEBUG - 2020-03-21 10:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-21 10:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-21 10:30:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-21 10:30:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-21 15:30:05 --> Total execution time: 0.1237
