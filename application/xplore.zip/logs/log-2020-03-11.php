<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-11 09:22:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:22:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:22:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:22:33 --> Total execution time: 0.4201
DEBUG - 2020-03-11 09:35:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:35:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:35:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:35:49 --> Total execution time: 0.1884
DEBUG - 2020-03-11 09:37:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:37:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:37:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:37:07 --> Total execution time: 0.0886
DEBUG - 2020-03-11 09:39:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:39:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:39:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:39:28 --> Total execution time: 0.0818
DEBUG - 2020-03-11 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:39:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:39:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:39:48 --> Total execution time: 0.0881
DEBUG - 2020-03-11 09:39:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:39:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:39:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:39:56 --> Total execution time: 0.0756
DEBUG - 2020-03-11 09:40:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:40:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:40:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:40:19 --> Total execution time: 0.0856
DEBUG - 2020-03-11 09:43:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:43:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:43:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:43:11 --> Total execution time: 0.1606
DEBUG - 2020-03-11 09:43:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:43:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:43:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:43:46 --> Total execution time: 0.0858
DEBUG - 2020-03-11 09:44:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:44:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:44:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:44:39 --> Total execution time: 0.1227
DEBUG - 2020-03-11 09:46:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:46:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:46:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:46:15 --> Total execution time: 0.0995
DEBUG - 2020-03-11 09:46:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:46:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:46:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:46:22 --> Total execution time: 0.0872
DEBUG - 2020-03-11 09:46:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:46:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:46:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:46:30 --> Total execution time: 0.0724
DEBUG - 2020-03-11 09:46:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:46:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:46:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-11 14:46:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-10, 10' at line 4 - Invalid query: SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`
FROM `question` as `Q`
ORDER BY `Q`.`id` DESC
 LIMIT -10, 10
DEBUG - 2020-03-11 09:47:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:47:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:47:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-11 14:47:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-10, 10' at line 4 - Invalid query: SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`
FROM `question` as `Q`
ORDER BY `Q`.`id` DESC
 LIMIT -10, 10
DEBUG - 2020-03-11 09:48:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:48:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:48:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:48:03 --> Total execution time: 0.0692
DEBUG - 2020-03-11 09:49:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:49:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:49:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:49:08 --> Total execution time: 0.1243
DEBUG - 2020-03-11 09:49:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:49:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:49:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:49:40 --> Total execution time: 0.0755
DEBUG - 2020-03-11 09:51:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:04 --> No URI present. Default controller set.
DEBUG - 2020-03-11 09:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-11 09:51:04 --> Total execution time: 0.1710
DEBUG - 2020-03-11 09:51:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:04 --> No URI present. Default controller set.
DEBUG - 2020-03-11 09:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-11 09:51:04 --> Total execution time: 0.0526
DEBUG - 2020-03-11 09:51:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 09:51:04 --> Total execution time: 0.0607
DEBUG - 2020-03-11 09:51:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 09:51:04 --> Total execution time: 0.0456
DEBUG - 2020-03-11 09:51:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 09:51:05 --> Total execution time: 0.0437
DEBUG - 2020-03-11 09:51:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:51:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-11 14:51:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-11 14:51:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-11 14:51:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-11 14:51:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-11 14:51:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-11 14:51:09 --> Total execution time: 0.1293
DEBUG - 2020-03-11 09:51:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 09:51:09 --> Total execution time: 0.0415
DEBUG - 2020-03-11 09:51:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:51:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 14:51:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-11 14:51:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-11 14:51:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-11 14:51:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-11 14:51:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-11 14:51:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-11 14:51:13 --> Total execution time: 0.1195
DEBUG - 2020-03-11 09:51:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 09:51:13 --> Total execution time: 0.0486
DEBUG - 2020-03-11 09:51:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:51:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 14:51:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 09:51:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 09:51:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 09:51:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 09:51:19 --> Total execution time: 0.0785
DEBUG - 2020-03-11 09:51:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:51:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:51:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:51:56 --> Total execution time: 0.0912
DEBUG - 2020-03-11 09:52:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:05 --> Total execution time: 0.0833
DEBUG - 2020-03-11 09:52:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:06 --> Total execution time: 0.0913
DEBUG - 2020-03-11 09:52:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:07 --> Total execution time: 0.0864
DEBUG - 2020-03-11 09:52:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:08 --> Total execution time: 0.0769
DEBUG - 2020-03-11 09:52:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:09 --> Total execution time: 0.0677
DEBUG - 2020-03-11 09:52:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:09 --> Total execution time: 0.0676
DEBUG - 2020-03-11 09:52:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:10 --> Total execution time: 0.0720
DEBUG - 2020-03-11 09:52:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:11 --> Total execution time: 0.1023
DEBUG - 2020-03-11 09:52:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:12 --> Total execution time: 0.0851
DEBUG - 2020-03-11 09:52:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:13 --> Total execution time: 0.1250
DEBUG - 2020-03-11 09:52:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:13 --> Total execution time: 0.0877
DEBUG - 2020-03-11 09:52:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:14 --> Total execution time: 0.0870
DEBUG - 2020-03-11 09:52:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:15 --> Total execution time: 0.0750
DEBUG - 2020-03-11 09:52:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:16 --> Total execution time: 0.0798
DEBUG - 2020-03-11 09:52:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:17 --> Total execution time: 0.0993
DEBUG - 2020-03-11 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:18 --> Total execution time: 0.0744
DEBUG - 2020-03-11 09:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:26 --> Total execution time: 0.0720
DEBUG - 2020-03-11 09:52:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:29 --> Total execution time: 0.0837
DEBUG - 2020-03-11 09:52:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:29 --> Total execution time: 0.0658
DEBUG - 2020-03-11 09:52:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:30 --> Total execution time: 0.0776
DEBUG - 2020-03-11 09:52:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:31 --> Total execution time: 0.0849
DEBUG - 2020-03-11 09:52:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:38 --> Total execution time: 0.0895
DEBUG - 2020-03-11 09:52:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:38 --> Total execution time: 0.0860
DEBUG - 2020-03-11 09:52:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:39 --> Total execution time: 0.0992
DEBUG - 2020-03-11 09:52:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:40 --> Total execution time: 0.0983
DEBUG - 2020-03-11 09:52:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:42 --> Total execution time: 0.0712
DEBUG - 2020-03-11 09:52:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:43 --> Total execution time: 0.0780
DEBUG - 2020-03-11 09:52:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:52:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:52:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:52:44 --> Total execution time: 0.1570
DEBUG - 2020-03-11 09:56:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:56:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:56:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-11 14:56:27 --> Severity: Notice --> Undefined variable: random_data D:\shipan7.2\htdocs\xplore\application\controllers\api\ContentController.php 38
DEBUG - 2020-03-11 14:56:27 --> Total execution time: 0.1627
DEBUG - 2020-03-11 09:56:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:56:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:56:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:56:35 --> Total execution time: 0.1137
DEBUG - 2020-03-11 09:56:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:56:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:56:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:56:42 --> Total execution time: 0.1469
DEBUG - 2020-03-11 09:56:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:56:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:56:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:56:43 --> Total execution time: 0.0971
DEBUG - 2020-03-11 09:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:56:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:56:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:56:53 --> Total execution time: 0.1345
DEBUG - 2020-03-11 09:56:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:56:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:56:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:56:59 --> Total execution time: 0.1085
DEBUG - 2020-03-11 09:57:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-11 14:57:14 --> Severity: Notice --> Undefined index: difficulty D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 52
ERROR - 2020-03-11 14:57:14 --> Severity: Notice --> Undefined index: difficulty D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 52
ERROR - 2020-03-11 14:57:14 --> Severity: Notice --> Undefined index: difficulty D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 52
ERROR - 2020-03-11 14:57:14 --> Severity: Notice --> Undefined index: difficulty D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 52
ERROR - 2020-03-11 14:57:14 --> Severity: Notice --> Undefined index: difficulty D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 52
ERROR - 2020-03-11 14:57:14 --> Severity: Notice --> Undefined index: difficulty D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 52
ERROR - 2020-03-11 14:57:14 --> Severity: Notice --> Undefined index: difficulty D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 52
ERROR - 2020-03-11 14:57:14 --> Severity: Notice --> Undefined index: difficulty D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 52
ERROR - 2020-03-11 14:57:14 --> Severity: Notice --> Undefined index: difficulty D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 52
ERROR - 2020-03-11 14:57:14 --> Severity: Notice --> Undefined index: difficulty D:\shipan7.2\htdocs\xplore\application\models\ContentModel.php 52
ERROR - 2020-03-11 14:57:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\shipan7.2\htdocs\xplore\system\core\Exceptions.php:271) D:\shipan7.2\htdocs\xplore\system\core\Common.php 575
DEBUG - 2020-03-11 14:57:14 --> Total execution time: 0.1522
DEBUG - 2020-03-11 09:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:23 --> Total execution time: 0.1724
DEBUG - 2020-03-11 09:57:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:30 --> Total execution time: 0.1121
DEBUG - 2020-03-11 09:57:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:31 --> Total execution time: 0.1026
DEBUG - 2020-03-11 09:57:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:33 --> Total execution time: 0.1596
DEBUG - 2020-03-11 09:57:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:34 --> Total execution time: 0.0958
DEBUG - 2020-03-11 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:40 --> Total execution time: 0.1102
DEBUG - 2020-03-11 09:57:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:41 --> Total execution time: 0.1344
DEBUG - 2020-03-11 09:57:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:42 --> Total execution time: 0.1288
DEBUG - 2020-03-11 09:57:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:44 --> Total execution time: 0.1058
DEBUG - 2020-03-11 09:57:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:45 --> Total execution time: 0.1857
DEBUG - 2020-03-11 09:57:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:46 --> Total execution time: 0.2539
DEBUG - 2020-03-11 09:57:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:47 --> Total execution time: 0.1298
DEBUG - 2020-03-11 09:57:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:47 --> Total execution time: 0.1263
DEBUG - 2020-03-11 09:57:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:48 --> Total execution time: 0.0926
DEBUG - 2020-03-11 09:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:49 --> Total execution time: 0.0962
DEBUG - 2020-03-11 09:57:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:50 --> Total execution time: 0.0940
DEBUG - 2020-03-11 09:57:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:51 --> Total execution time: 0.1172
DEBUG - 2020-03-11 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:52 --> Total execution time: 0.1304
DEBUG - 2020-03-11 09:57:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:53 --> Total execution time: 0.1481
DEBUG - 2020-03-11 09:57:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:54 --> Total execution time: 0.1229
DEBUG - 2020-03-11 09:57:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:55 --> Total execution time: 0.1461
DEBUG - 2020-03-11 09:57:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:56 --> Total execution time: 0.2251
DEBUG - 2020-03-11 09:57:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:57 --> Total execution time: 0.1117
DEBUG - 2020-03-11 09:57:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:57:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:57:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:57:58 --> Total execution time: 0.0993
DEBUG - 2020-03-11 09:59:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:59:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:59:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:59:23 --> Total execution time: 0.1025
DEBUG - 2020-03-11 09:59:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:59:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:59:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:59:36 --> Total execution time: 0.1134
DEBUG - 2020-03-11 09:59:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:59:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:59:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:59:38 --> Total execution time: 0.1313
DEBUG - 2020-03-11 09:59:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:59:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:59:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:59:39 --> Total execution time: 0.1042
DEBUG - 2020-03-11 09:59:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:59:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:59:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:59:40 --> Total execution time: 0.0922
DEBUG - 2020-03-11 09:59:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:59:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:59:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:59:41 --> Total execution time: 0.1189
DEBUG - 2020-03-11 09:59:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:59:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:59:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:59:43 --> Total execution time: 0.1113
DEBUG - 2020-03-11 09:59:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 09:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 14:59:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 14:59:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 14:59:49 --> Total execution time: 0.1173
DEBUG - 2020-03-11 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:00:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:00:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:00:02 --> Total execution time: 0.1014
DEBUG - 2020-03-11 10:00:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:00:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:00:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:00:41 --> Total execution time: 0.1519
DEBUG - 2020-03-11 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:00:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:00:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:00:45 --> Total execution time: 0.1167
DEBUG - 2020-03-11 10:00:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:00:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:00:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:00:46 --> Total execution time: 0.2054
DEBUG - 2020-03-11 10:00:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:00:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:00:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:00:47 --> Total execution time: 0.1508
DEBUG - 2020-03-11 10:00:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:00:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:00:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:00:48 --> Total execution time: 0.0991
DEBUG - 2020-03-11 10:00:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:00:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:00:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:00:49 --> Total execution time: 0.1545
DEBUG - 2020-03-11 10:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:00:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:00:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:00:50 --> Total execution time: 0.1260
DEBUG - 2020-03-11 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:02 --> Total execution time: 0.1103
DEBUG - 2020-03-11 10:01:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:13 --> Total execution time: 0.1190
DEBUG - 2020-03-11 10:01:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:39 --> Total execution time: 0.1511
DEBUG - 2020-03-11 10:01:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:40 --> Total execution time: 0.1073
DEBUG - 2020-03-11 10:01:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:41 --> Total execution time: 0.1210
DEBUG - 2020-03-11 10:01:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:42 --> Total execution time: 0.0912
DEBUG - 2020-03-11 10:01:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:45 --> Total execution time: 0.0827
DEBUG - 2020-03-11 10:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:45 --> Total execution time: 0.0923
DEBUG - 2020-03-11 10:01:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:46 --> Total execution time: 0.0821
DEBUG - 2020-03-11 10:01:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:47 --> Total execution time: 0.0815
DEBUG - 2020-03-11 10:01:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:48 --> Total execution time: 0.0710
DEBUG - 2020-03-11 10:01:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:48 --> Total execution time: 0.0705
DEBUG - 2020-03-11 10:01:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:49 --> Total execution time: 0.0698
DEBUG - 2020-03-11 10:01:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:50 --> Total execution time: 0.1236
DEBUG - 2020-03-11 10:01:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:51 --> Total execution time: 0.0669
DEBUG - 2020-03-11 10:01:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:51 --> Total execution time: 0.1075
DEBUG - 2020-03-11 10:01:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:01:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:01:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:01:52 --> Total execution time: 0.0738
DEBUG - 2020-03-11 10:02:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:02:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:02:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:02:16 --> Total execution time: 0.3423
DEBUG - 2020-03-11 10:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:02:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:02:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:02:17 --> Total execution time: 0.0688
DEBUG - 2020-03-11 10:02:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:02:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:02:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:02:18 --> Total execution time: 0.1318
DEBUG - 2020-03-11 10:02:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:02:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:02:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:02:19 --> Total execution time: 0.0925
DEBUG - 2020-03-11 10:02:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:02:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:02:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:02:20 --> Total execution time: 0.1180
DEBUG - 2020-03-11 10:02:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:02:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:02:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:02:21 --> Total execution time: 0.1753
DEBUG - 2020-03-11 10:02:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:02:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:02:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:02:22 --> Total execution time: 0.1029
DEBUG - 2020-03-11 10:02:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:02:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:02:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:02:23 --> Total execution time: 0.0867
DEBUG - 2020-03-11 10:02:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:02:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:02:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:02:24 --> Total execution time: 0.1330
DEBUG - 2020-03-11 10:02:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:02:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:02:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:02:25 --> Total execution time: 0.1095
DEBUG - 2020-03-11 10:08:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:08:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:08:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:08:49 --> Total execution time: 0.1907
DEBUG - 2020-03-11 10:08:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:08:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:08:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:08:53 --> Total execution time: 0.0866
DEBUG - 2020-03-11 10:08:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:08:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:08:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:08:54 --> Total execution time: 0.1566
DEBUG - 2020-03-11 10:08:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:08:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:08:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:08:55 --> Total execution time: 0.1329
DEBUG - 2020-03-11 10:08:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:08:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:08:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:08:56 --> Total execution time: 0.1021
DEBUG - 2020-03-11 10:08:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:08:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:08:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:08:57 --> Total execution time: 0.1067
DEBUG - 2020-03-11 10:09:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:09:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:09:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:09:31 --> Total execution time: 0.0871
DEBUG - 2020-03-11 10:09:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:09:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:09:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:09:39 --> Total execution time: 0.2100
DEBUG - 2020-03-11 10:09:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:09:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:09:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:09:42 --> Total execution time: 0.0651
DEBUG - 2020-03-11 10:09:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:09:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:09:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:09:45 --> Total execution time: 0.0546
DEBUG - 2020-03-11 10:10:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:10:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:10:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:10:50 --> Total execution time: 0.0658
DEBUG - 2020-03-11 10:11:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:11:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:11:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:11:29 --> Total execution time: 0.1328
DEBUG - 2020-03-11 10:12:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:12:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:12:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:12:15 --> Total execution time: 0.0616
DEBUG - 2020-03-11 10:12:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:12:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:12:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:12:19 --> Total execution time: 0.0600
DEBUG - 2020-03-11 10:12:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:12:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:12:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:12:23 --> Total execution time: 0.1019
DEBUG - 2020-03-11 10:12:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:12:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:12:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:12:38 --> Total execution time: 0.0619
DEBUG - 2020-03-11 10:13:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:13:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:13:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:13:22 --> Total execution time: 0.0639
DEBUG - 2020-03-11 10:13:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:13:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:13:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:13:31 --> Total execution time: 0.0571
DEBUG - 2020-03-11 10:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:14:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:14:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:14:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-11 15:14:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-11 15:14:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-11 15:14:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-11 15:14:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-11 15:14:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-11 15:14:33 --> Total execution time: 0.2256
DEBUG - 2020-03-11 10:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:14:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:14:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 10:14:34 --> Total execution time: 0.0454
DEBUG - 2020-03-11 10:14:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:14:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:14:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:14:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:14:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:14:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 10:14:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:14:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:14:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:14:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:14:38 --> Total execution time: 0.0425
DEBUG - 2020-03-11 15:14:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:14:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:14:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:14:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:14:41 --> Total execution time: 0.0430
DEBUG - 2020-03-11 15:14:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:14:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 10:14:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:14:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:14:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:14:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:14:43 --> Total execution time: 0.0414
DEBUG - 2020-03-11 15:14:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:14:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 10:14:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:14:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:14:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 10:14:50 --> Total execution time: 0.0670
DEBUG - 2020-03-11 10:15:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:15:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:15:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:15:12 --> Total execution time: 0.1325
DEBUG - 2020-03-11 10:15:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:15:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:15:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 10:15:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:15:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:15:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:15:42 --> Total execution time: 0.0779
DEBUG - 2020-03-11 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:17:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:17:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:17:22 --> Total execution time: 0.0717
DEBUG - 2020-03-11 10:18:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:18:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:18:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:18:11 --> Total execution time: 0.0618
DEBUG - 2020-03-11 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:18:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:18:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-11 15:18:34 --> Query error: Unknown column 'TQ.topic_id' in 'on clause' - Invalid query: SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`, `Q`.`difficulty`
FROM `question` as `Q`
LEFT JOIN `topic_assign` as `TA` ON `TQ`.`topic_id` = `TA`.`topic_id`
LEFT JOIN `section_assign` as `SA` ON `TA`.`section_id` = `SA`.`section_id`
LEFT JOIN `subject_assign` as `SUBA` ON `SA`.`subject_id` = `SUBA`.`subject_id`
WHERE `SUBA`.`subject_id` IN('2')
ORDER BY RAND()
 LIMIT 10, 10
DEBUG - 2020-03-11 10:19:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:19:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:19:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-11 15:19:23 --> Query error: Not unique table/alias: 'TA' - Invalid query: SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`, `Q`.`difficulty`
FROM `question` as `Q`
LEFT JOIN `topic_assign` as `TA` ON `TQ`.`topic_id` = `TA`.`topic_id`
LEFT JOIN `section_assign` as `SA` ON `TA`.`section_id` = `SA`.`section_id`
LEFT JOIN `subject_assign` as `SUBA` ON `SA`.`subject_id` = `SUBA`.`subject_id`
LEFT JOIN `topics_questions` `TQ` ON `Q`.`id` = `TQ`.`question_id`
LEFT JOIN `topic_assign` as `TA` ON `TQ`.`topic_id` = `TA`.`topic_id`
LEFT JOIN `section_assign` as `SA` ON `TA`.`section_id` = `SA`.`section_id`
LEFT JOIN `subject_assign` as `SUBA` ON `SA`.`subject_id` = `SUBA`.`subject_id`
WHERE `SUBA`.`subject_id` IN('2')
AND `SUBA`.`subject_id` IN('2')
ORDER BY RAND()
 LIMIT 10, 10
DEBUG - 2020-03-11 10:19:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:19:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:19:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-11 15:19:59 --> Query error: Unknown column 'TQ.topic_id' in 'on clause' - Invalid query: SELECT DISTINCT `Q`.`id`, `Q`.`status`, `Q`.`title`, `Q`.`answer`, `Q`.`difficulty`
FROM `question` as `Q`
LEFT JOIN `topic_assign` as `TA` ON `TQ`.`topic_id` = `TA`.`topic_id`
LEFT JOIN `section_assign` as `SA` ON `TA`.`section_id` = `SA`.`section_id`
LEFT JOIN `subject_assign` as `SUBA` ON `SA`.`subject_id` = `SUBA`.`subject_id`
WHERE `SUBA`.`subject_id` IN('2')
ORDER BY RAND()
 LIMIT 10, 10
DEBUG - 2020-03-11 10:20:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:20:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:20:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:20:22 --> Total execution time: 0.1103
DEBUG - 2020-03-11 10:25:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:25:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:25:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:25:17 --> Total execution time: 0.0693
DEBUG - 2020-03-11 10:25:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:25:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:25:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:25:46 --> Total execution time: 0.1428
DEBUG - 2020-03-11 10:25:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:25:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:25:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:25:50 --> Total execution time: 0.1267
DEBUG - 2020-03-11 10:25:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:25:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:25:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:25:51 --> Total execution time: 0.0623
DEBUG - 2020-03-11 10:26:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:26:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:26:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:26:08 --> Total execution time: 0.1030
DEBUG - 2020-03-11 10:26:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:26:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:26:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:26:09 --> Total execution time: 0.0819
DEBUG - 2020-03-11 10:26:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:26:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:26:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:26:15 --> Total execution time: 0.0770
DEBUG - 2020-03-11 10:26:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:26:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:26:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:26:24 --> Total execution time: 0.0781
DEBUG - 2020-03-11 10:26:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:26:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:26:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:26:25 --> Total execution time: 0.1041
DEBUG - 2020-03-11 10:26:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:26:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:26:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:26:28 --> Total execution time: 0.0886
DEBUG - 2020-03-11 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:26:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:26:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 10:26:51 --> Total execution time: 0.1066
DEBUG - 2020-03-11 10:27:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:27:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:27:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:27:02 --> Total execution time: 0.0693
DEBUG - 2020-03-11 10:27:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:27:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:27:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:27:20 --> Total execution time: 0.0696
DEBUG - 2020-03-11 10:27:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:27:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:27:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:27:22 --> Total execution time: 0.1137
DEBUG - 2020-03-11 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:27:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:27:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:27:31 --> Total execution time: 0.0618
DEBUG - 2020-03-11 10:27:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:27:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:27:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:27:49 --> Total execution time: 0.1057
DEBUG - 2020-03-11 10:28:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:28:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:28:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:28:09 --> Total execution time: 0.0871
DEBUG - 2020-03-11 10:28:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:28:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:28:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:28:16 --> Total execution time: 0.0897
DEBUG - 2020-03-11 10:28:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:28:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:28:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:28:24 --> Total execution time: 0.0580
DEBUG - 2020-03-11 10:28:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:28:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:28:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:28:28 --> Total execution time: 0.1752
DEBUG - 2020-03-11 10:28:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:28:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:28:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:28:34 --> Total execution time: 0.0652
DEBUG - 2020-03-11 10:28:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:28:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:28:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:28:38 --> Total execution time: 0.0657
DEBUG - 2020-03-11 10:28:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:28:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:28:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:28:59 --> Total execution time: 0.0763
DEBUG - 2020-03-11 10:29:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:29:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:29:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:29:06 --> Total execution time: 0.1072
DEBUG - 2020-03-11 10:29:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:29:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:29:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:29:42 --> Total execution time: 0.0738
DEBUG - 2020-03-11 10:30:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:30:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:30:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:30:14 --> Total execution time: 0.0775
DEBUG - 2020-03-11 10:30:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:30:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:30:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:30:24 --> Total execution time: 0.0586
DEBUG - 2020-03-11 10:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:30:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:30:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:30:29 --> Total execution time: 0.0754
DEBUG - 2020-03-11 10:31:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:31:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:31:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:31:44 --> Total execution time: 0.1879
DEBUG - 2020-03-11 10:31:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:31:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:31:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:31:52 --> Total execution time: 0.0743
DEBUG - 2020-03-11 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:32:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:32:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:32:00 --> Total execution time: 0.0892
DEBUG - 2020-03-11 10:32:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:32:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:32:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:32:08 --> Total execution time: 0.0927
DEBUG - 2020-03-11 10:33:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:33:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:33:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-11 15:33:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-11 15:33:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-11 15:33:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-11 15:33:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-11 15:33:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-11 15:33:40 --> Total execution time: 0.1073
DEBUG - 2020-03-11 10:33:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:33:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 10:33:40 --> Total execution time: 0.0501
DEBUG - 2020-03-11 10:33:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:33:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:33:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 10:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:33:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:33:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:33:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 15:33:43 --> Total execution time: 0.2709
DEBUG - 2020-03-11 10:33:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:33:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:33:45 --> Total execution time: 0.0431
DEBUG - 2020-03-11 15:33:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:33:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 10:33:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:33:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:33:47 --> Total execution time: 0.0416
DEBUG - 2020-03-11 15:33:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:33:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 10:33:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:33:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:33:50 --> Total execution time: 0.0414
DEBUG - 2020-03-11 15:33:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:33:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 10:33:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:33:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:33:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 10:33:55 --> Total execution time: 0.0782
DEBUG - 2020-03-11 10:34:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:34:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:34:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 10:34:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:34:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 10:34:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:34:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:34:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:34:13 --> Total execution time: 0.1323
DEBUG - 2020-03-11 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:34:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:34:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:34:17 --> Total execution time: 0.1200
DEBUG - 2020-03-11 10:34:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:34:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:34:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:34:30 --> Total execution time: 0.0850
DEBUG - 2020-03-11 10:34:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:34:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:34:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:34:36 --> Total execution time: 0.0681
DEBUG - 2020-03-11 10:34:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:34:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:34:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-11 10:34:40 --> Total execution time: 0.0723
DEBUG - 2020-03-11 10:34:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:34:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:34:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:34:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:34:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 15:34:52 --> Total execution time: 0.1248
DEBUG - 2020-03-11 10:34:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 10:34:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 10:34:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:34:53 --> Total execution time: 0.0456
DEBUG - 2020-03-11 15:34:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-11 15:34:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-11 10:34:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:34:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:34:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:34:59 --> Total execution time: 0.0663
DEBUG - 2020-03-11 10:41:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:41:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:41:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:41:02 --> Total execution time: 0.1169
DEBUG - 2020-03-11 10:41:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:41:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:41:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:41:30 --> Total execution time: 0.0949
DEBUG - 2020-03-11 10:44:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 10:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 15:44:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 15:44:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 15:44:02 --> Total execution time: 0.0808
DEBUG - 2020-03-11 11:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 11:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 16:13:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 16:13:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 16:13:14 --> Total execution time: 0.2166
DEBUG - 2020-03-11 11:13:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 11:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 16:13:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 16:13:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 16:13:44 --> Total execution time: 0.0536
DEBUG - 2020-03-11 11:14:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 11:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 16:14:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 16:14:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 16:14:02 --> Total execution time: 0.0812
DEBUG - 2020-03-11 11:15:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 11:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 16:15:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 16:15:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 16:15:06 --> Total execution time: 0.0968
DEBUG - 2020-03-11 11:16:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 11:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 16:16:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 16:16:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 16:16:03 --> Total execution time: 0.1095
DEBUG - 2020-03-11 11:16:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 11:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 16:16:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 16:16:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 16:16:06 --> Total execution time: 0.0634
DEBUG - 2020-03-11 11:16:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 11:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 16:16:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 16:16:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 16:16:08 --> Total execution time: 0.0643
DEBUG - 2020-03-11 11:16:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 11:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 16:16:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 16:16:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 16:16:13 --> Total execution time: 0.0618
DEBUG - 2020-03-11 11:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 11:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 16:16:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 16:16:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 16:16:33 --> Total execution time: 0.0506
DEBUG - 2020-03-11 11:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-11 11:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-11 16:16:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-11 16:16:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-11 16:16:57 --> Total execution time: 0.1299
