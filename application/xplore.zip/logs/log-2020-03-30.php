<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-30 11:42:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-30 11:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-30 15:42:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-30 15:42:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-30 15:42:14 --> Total execution time: 1.4518
DEBUG - 2020-03-30 12:36:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-30 12:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-30 16:36:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-30 16:36:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-30 16:36:54 --> Severity: Notice --> Trying to get property 'id' of non-object D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 163
ERROR - 2020-03-30 16:36:55 --> Severity: Notice --> Trying to get property 'correct_question' of non-object D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 164
ERROR - 2020-03-30 16:36:55 --> Severity: Notice --> Trying to get property 'wrong_question' of non-object D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 165
ERROR - 2020-03-30 16:36:55 --> Severity: Notice --> Trying to get property 'unanswer_question' of non-object D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 166
ERROR - 2020-03-30 16:36:55 --> Severity: Notice --> Trying to get property 'total_point' of non-object D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 167
ERROR - 2020-03-30 16:36:55 --> Severity: Notice --> Trying to get property 'total_time' of non-object D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 168
ERROR - 2020-03-30 16:36:55 --> Severity: Notice --> Trying to get property 'total_question' of non-object D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 169
ERROR - 2020-03-30 16:36:55 --> Severity: Notice --> Trying to get property 'get_point' of non-object D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 170
ERROR - 2020-03-30 16:36:55 --> Severity: Notice --> Trying to get property 'creted_at' of non-object D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 171
ERROR - 2020-03-30 16:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\shipan7.2\htdocs\xplore\system\core\Exceptions.php:271) D:\shipan7.2\htdocs\xplore\system\core\Common.php 575
DEBUG - 2020-03-30 16:36:55 --> Total execution time: 0.4851
DEBUG - 2020-03-30 12:37:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-30 12:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-30 16:37:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-30 16:37:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-30 16:37:59 --> Total execution time: 0.1367
DEBUG - 2020-03-30 13:19:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-30 13:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-30 17:19:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-30 17:19:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-30 17:19:18 --> Total execution time: 0.4936
DEBUG - 2020-03-30 13:20:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-30 13:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-30 17:20:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-30 17:20:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-30 17:20:15 --> Total execution time: 0.1213
DEBUG - 2020-03-30 13:33:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-30 13:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-30 17:33:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-30 17:33:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-30 17:33:58 --> Total execution time: 0.2182
