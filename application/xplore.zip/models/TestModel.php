<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TestModel extends MY_Model
{
    public function test()
    {
        return "test";
    }

}

/* End of file .php */