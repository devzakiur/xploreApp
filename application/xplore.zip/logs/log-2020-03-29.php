<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-29 11:36:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 11:36:41 --> No URI present. Default controller set.
DEBUG - 2020-03-29 11:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 11:36:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 11:36:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-29 11:36:42 --> Total execution time: 1.9111
DEBUG - 2020-03-29 11:36:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 11:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 11:36:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 11:36:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 11:36:42 --> Total execution time: 0.2220
DEBUG - 2020-03-29 11:36:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 11:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 11:36:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 11:36:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 11:36:43 --> Total execution time: 0.1860
DEBUG - 2020-03-29 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 11:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 11:36:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 11:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 11:36:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:36:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-29 15:36:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-29 15:36:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 15:36:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 15:36:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 15:36:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 15:36:48 --> Total execution time: 0.7560
DEBUG - 2020-03-29 11:36:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 11:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 11:36:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 11:36:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 11:36:49 --> Total execution time: 0.1073
DEBUG - 2020-03-29 11:36:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 11:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 11:36:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:36:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-29 15:36:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 15:36:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 15:36:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 15:36:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 15:36:52 --> Total execution time: 0.1934
DEBUG - 2020-03-29 11:36:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 11:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 11:36:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 11:36:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 11:36:52 --> Total execution time: 0.1747
DEBUG - 2020-03-29 11:36:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 11:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 11:36:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 12:16:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:16:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:16:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:16:03 --> Total execution time: 0.8976
DEBUG - 2020-03-29 12:36:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:36:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:36:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:36:38 --> Total execution time: 0.2559
DEBUG - 2020-03-29 12:41:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:42:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:42:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:42:00 --> Total execution time: 0.3254
DEBUG - 2020-03-29 12:42:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:42:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:42:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:42:32 --> Total execution time: 0.1832
DEBUG - 2020-03-29 12:42:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:42:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:42:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:42:40 --> Total execution time: 0.1513
DEBUG - 2020-03-29 12:43:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:43:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:43:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:43:24 --> Total execution time: 0.1344
DEBUG - 2020-03-29 12:43:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:43:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:43:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:43:36 --> Total execution time: 0.1790
DEBUG - 2020-03-29 12:44:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:44:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:44:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:44:08 --> Total execution time: 0.1402
DEBUG - 2020-03-29 12:44:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:44:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:44:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:44:51 --> Total execution time: 0.1500
DEBUG - 2020-03-29 12:45:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:45:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:45:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:45:07 --> Total execution time: 0.1414
DEBUG - 2020-03-29 12:46:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:46:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:46:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:46:23 --> Total execution time: 0.1401
DEBUG - 2020-03-29 12:49:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:49:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:49:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:49:58 --> Total execution time: 0.1769
DEBUG - 2020-03-29 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:50:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:50:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:50:01 --> Total execution time: 0.1921
DEBUG - 2020-03-29 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 12:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 16:52:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 16:52:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:52:57 --> Total execution time: 0.1371
DEBUG - 2020-03-29 13:07:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 13:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 17:07:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 17:07:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 17:07:12 --> Total execution time: 0.1632
DEBUG - 2020-03-29 13:07:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 13:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 17:07:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 17:07:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 17:07:40 --> Total execution time: 0.1221
DEBUG - 2020-03-29 13:47:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 13:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 17:47:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 17:47:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-29 17:47:11 --> Severity: Notice --> Undefined index: game_time D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 104
ERROR - 2020-03-29 17:47:11 --> Severity: Notice --> Undefined index: game_time D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 104
ERROR - 2020-03-29 17:47:11 --> Severity: Notice --> Undefined index: game_time D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 104
ERROR - 2020-03-29 17:47:11 --> Severity: Notice --> Undefined index: game_time D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 104
ERROR - 2020-03-29 17:47:11 --> Severity: Notice --> Undefined index: game_time D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 104
ERROR - 2020-03-29 17:47:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\shipan7.2\htdocs\xplore\system\core\Exceptions.php:271) D:\shipan7.2\htdocs\xplore\system\core\Common.php 575
DEBUG - 2020-03-29 17:47:11 --> Total execution time: 0.5100
DEBUG - 2020-03-29 13:47:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 13:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 17:47:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 17:47:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 17:47:52 --> Total execution time: 0.2290
DEBUG - 2020-03-29 13:48:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 13:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 17:48:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 17:48:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 17:48:52 --> Total execution time: 0.1849
DEBUG - 2020-03-29 13:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 13:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 17:49:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 17:49:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 17:49:44 --> Total execution time: 0.1632
DEBUG - 2020-03-29 13:50:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 13:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 17:50:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 17:50:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 17:50:37 --> Total execution time: 0.1553
DEBUG - 2020-03-29 13:54:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 13:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 17:54:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 17:54:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 17:54:16 --> Total execution time: 0.2126
DEBUG - 2020-03-29 13:55:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 13:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 17:55:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 17:55:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 17:55:12 --> Total execution time: 0.1592
DEBUG - 2020-03-29 13:55:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 13:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 17:55:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 17:55:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 17:55:28 --> Total execution time: 0.1583
DEBUG - 2020-03-29 13:57:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 13:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 17:57:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 17:57:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 17:57:48 --> Total execution time: 0.1774
DEBUG - 2020-03-29 14:02:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:02:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:02:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:02:27 --> Total execution time: 0.3151
DEBUG - 2020-03-29 14:04:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:04:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:04:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:04:02 --> Total execution time: 0.3005
DEBUG - 2020-03-29 14:04:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:04:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:04:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:04:14 --> Total execution time: 0.3792
DEBUG - 2020-03-29 14:04:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:04:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:04:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:04:35 --> Total execution time: 0.3858
DEBUG - 2020-03-29 14:04:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:04:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:04:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:04:42 --> Total execution time: 0.3376
DEBUG - 2020-03-29 14:33:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:33:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:33:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:33:31 --> Total execution time: 0.6296
DEBUG - 2020-03-29 14:33:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:33:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:33:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:33:41 --> Total execution time: 0.2334
DEBUG - 2020-03-29 14:33:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:33:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:33:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-29 18:33:54 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT `GRQ`.`topic_id`, `T`.`name` as `topic_name`, COUNT(id) as per_topic_question
FROM `game_result_question` as `GRQ`
LEFT JOIN `topic` as `T` ON `GRQ`.`topic_id` = `T`.`id`
WHERE `GRQ`.`id` = '1'
AND `GRQ`.`subject_id` = '3'
AND `GRQ`.`section_id` = '2'
GROUP BY `GRQ`.`topic_id`
DEBUG - 2020-03-29 14:35:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:35:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:35:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:35:02 --> Total execution time: 0.1782
DEBUG - 2020-03-29 14:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:35:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:35:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:35:50 --> Total execution time: 0.1149
DEBUG - 2020-03-29 14:38:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:38:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:38:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:38:16 --> Total execution time: 0.1325
DEBUG - 2020-03-29 14:38:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:38:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:38:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:38:50 --> Total execution time: 0.1506
DEBUG - 2020-03-29 14:39:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:39:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:39:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:39:01 --> Total execution time: 0.1149
DEBUG - 2020-03-29 14:39:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:39:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:39:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:39:28 --> Total execution time: 0.1119
DEBUG - 2020-03-29 14:39:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:39:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:39:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:39:53 --> Total execution time: 0.1101
DEBUG - 2020-03-29 14:40:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:40:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:40:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:40:20 --> Total execution time: 0.1162
DEBUG - 2020-03-29 14:41:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:41:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:41:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:41:03 --> Total execution time: 0.1554
DEBUG - 2020-03-29 14:41:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:41:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:41:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:41:40 --> Total execution time: 0.1176
DEBUG - 2020-03-29 14:41:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:41:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:41:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:41:52 --> Total execution time: 0.1256
DEBUG - 2020-03-29 14:42:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:42:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:42:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:42:09 --> Total execution time: 0.1262
DEBUG - 2020-03-29 14:44:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:44:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:44:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:44:05 --> Total execution time: 0.1511
DEBUG - 2020-03-29 14:44:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:44:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:44:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:44:45 --> Total execution time: 0.1320
DEBUG - 2020-03-29 14:44:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:44:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:44:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:44:55 --> Total execution time: 0.1153
DEBUG - 2020-03-29 14:46:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:46:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:46:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:46:46 --> Total execution time: 0.1148
DEBUG - 2020-03-29 14:51:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:51:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:51:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-29 18:51:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='correct', COUNT('GRQ.id') as correct_ans_by_subject, '')
FROM `game_result_que' at line 1 - Invalid query: SELECT `GRQ`.`subject_id`, `S`.`name` as `subject_name`, count(GRQ.subject_id) as question_per_subject, IF(GRQ.answer_type=='correct', COUNT('GRQ.id') as correct_ans_by_subject, '')
FROM `game_result_question` as `GRQ`
LEFT JOIN `subject` as `S` ON `GRQ`.`subject_id` = `S`.`id`
WHERE `GRQ`.`game_table_id` = '1'
GROUP BY `GRQ`.`subject_id`
DEBUG - 2020-03-29 14:52:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:52:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:52:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-29 18:52:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '='correct', COUNT('GRQ.id') as correct_ans_by_subject, 'No')
FROM `game_result_q' at line 1 - Invalid query: SELECT `GRQ`.`subject_id`, `S`.`name` as `subject_name`, count(GRQ.subject_id) as question_per_subject, IF(GRQ.answer_type=='correct', COUNT('GRQ.id') as correct_ans_by_subject, 'No')
FROM `game_result_question` as `GRQ`
LEFT JOIN `subject` as `S` ON `GRQ`.`subject_id` = `S`.`id`
WHERE `GRQ`.`game_table_id` = '1'
GROUP BY `GRQ`.`subject_id`
DEBUG - 2020-03-29 14:54:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:54:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:54:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:54:25 --> Total execution time: 0.1285
DEBUG - 2020-03-29 14:55:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:55:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:55:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:55:12 --> Total execution time: 0.1872
DEBUG - 2020-03-29 14:56:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:56:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:56:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:56:52 --> Total execution time: 0.1485
DEBUG - 2020-03-29 14:58:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:58:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:58:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:58:14 --> Total execution time: 0.3347
DEBUG - 2020-03-29 14:58:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:58:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:58:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:58:17 --> Total execution time: 0.1691
DEBUG - 2020-03-29 14:59:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 14:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 18:59:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 18:59:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 18:59:29 --> Total execution time: 0.2262
DEBUG - 2020-03-29 15:02:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:02:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:02:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:02:59 --> Total execution time: 0.2731
DEBUG - 2020-03-29 15:03:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:03:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:03:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:03:54 --> Total execution time: 0.2488
DEBUG - 2020-03-29 15:04:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:04:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:04:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:04:01 --> Total execution time: 0.1316
DEBUG - 2020-03-29 15:04:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:04:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:04:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:04:20 --> Total execution time: 0.1163
DEBUG - 2020-03-29 15:06:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:06:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:06:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:06:40 --> Total execution time: 0.1241
DEBUG - 2020-03-29 15:06:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:06:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:06:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:06:50 --> Total execution time: 0.1191
DEBUG - 2020-03-29 15:07:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:07:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:07:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:07:56 --> Total execution time: 0.2279
DEBUG - 2020-03-29 15:07:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:07:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:07:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:07:59 --> Total execution time: 0.1574
DEBUG - 2020-03-29 15:08:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:08:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:08:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:08:11 --> Total execution time: 0.1655
DEBUG - 2020-03-29 15:12:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:12:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:12:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-29 19:12:07 --> Query error: Unknown column 'GRQ.total_time' in 'field list' - Invalid query: SELECT `GRQ`.`subject_id`, `S`.`name` as `subject_name`, count(GRQ.subject_id) as question_per_subject, COUNT(IF(GRQ.answer_type = 'correct', 1, NULL)) 'correct_ans_by_subject', SUM(GRQ.total_time) as subject_total_time
FROM `game_result_question` as `GRQ`
LEFT JOIN `subject` as `S` ON `GRQ`.`subject_id` = `S`.`id`
WHERE `GRQ`.`game_table_id` = '1'
GROUP BY `GRQ`.`subject_id`
DEBUG - 2020-03-29 15:12:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:12:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:12:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-29 19:12:58 --> Query error: Unknown column 'GRQ.total_time' in 'field list' - Invalid query: SELECT `GRQ`.`subject_id`, `S`.`name` as `subject_name`, count(GRQ.subject_id) as question_per_subject, COUNT(IF(GRQ.answer_type = 'correct', 1, NULL)) 'correct_ans_by_subject', SUM(GRQ.total_time) as subject_game_time
FROM `game_result_question` as `GRQ`
LEFT JOIN `subject` as `S` ON `GRQ`.`subject_id` = `S`.`id`
WHERE `GRQ`.`game_table_id` = '1'
GROUP BY `GRQ`.`subject_id`
DEBUG - 2020-03-29 15:13:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:13:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:13:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:13:23 --> Total execution time: 0.1758
DEBUG - 2020-03-29 15:24:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:24:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:24:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-29 19:24:22 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 67
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 67
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 93
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 93
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 120
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 120
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 120
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 120
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 67
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 67
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 93
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 93
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 120
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 120
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 93
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 93
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 120
ERROR - 2020-03-29 19:24:23 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\models\GameModel.php 120
ERROR - 2020-03-29 19:24:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\shipan7.2\htdocs\xplore\system\core\Exceptions.php:271) D:\shipan7.2\htdocs\xplore\system\core\Common.php 575
DEBUG - 2020-03-29 19:24:23 --> Total execution time: 0.4737
DEBUG - 2020-03-29 15:25:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:25:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:25:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:25:50 --> Total execution time: 0.1503
DEBUG - 2020-03-29 15:26:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:26:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:26:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:26:08 --> Total execution time: 0.1235
DEBUG - 2020-03-29 15:35:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:35:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:35:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:35:26 --> Total execution time: 0.3244
DEBUG - 2020-03-29 15:35:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:35:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:35:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-29 19:35:33 --> Severity: Notice --> Undefined property: stdClass::$total_time D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 122
ERROR - 2020-03-29 19:35:33 --> Severity: Notice --> Undefined property: stdClass::$total_question D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 123
DEBUG - 2020-03-29 19:35:33 --> Total execution time: 0.4304
DEBUG - 2020-03-29 15:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:36:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:36:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-29 19:36:34 --> Severity: Notice --> Undefined property: stdClass::$total_question D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 123
DEBUG - 2020-03-29 19:36:34 --> Total execution time: 0.2684
DEBUG - 2020-03-29 15:37:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:37:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:37:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:37:19 --> Total execution time: 0.3626
DEBUG - 2020-03-29 15:37:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:37:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:37:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:37:51 --> Total execution time: 0.2460
DEBUG - 2020-03-29 15:38:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:38:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:38:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:38:12 --> Total execution time: 0.2966
DEBUG - 2020-03-29 15:38:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 19:38:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:38:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 19:38:24 --> Total execution time: 0.1535
DEBUG - 2020-03-29 15:52:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:52:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:09 --> No URI present. Default controller set.
DEBUG - 2020-03-29 15:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:52:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-29 15:52:09 --> Total execution time: 0.1734
DEBUG - 2020-03-29 15:52:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:52:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 15:52:10 --> Total execution time: 0.1969
DEBUG - 2020-03-29 15:52:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:52:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:52:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-29 19:52:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-29 19:52:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 19:52:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 19:52:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 19:52:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 19:52:15 --> Total execution time: 0.3021
DEBUG - 2020-03-29 15:52:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:52:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 15:52:16 --> Total execution time: 0.2102
DEBUG - 2020-03-29 15:52:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-29 19:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-29 19:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 19:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 19:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 19:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 19:52:19 --> Total execution time: 0.3041
DEBUG - 2020-03-29 15:52:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 15:52:19 --> Total execution time: 0.1408
DEBUG - 2020-03-29 15:52:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:52:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-29 19:52:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-29 15:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:52:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-29 19:52:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 19:52:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 19:52:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 19:52:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 19:52:23 --> Total execution time: 0.2026
DEBUG - 2020-03-29 15:52:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:52:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 15:52:23 --> Total execution time: 0.1465
DEBUG - 2020-03-29 15:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:52:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:52:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:52:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:52:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:56:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:56:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-29 19:56:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 19:56:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 19:56:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 19:56:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 19:56:36 --> Total execution time: 0.1854
DEBUG - 2020-03-29 15:56:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:56:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:56:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 15:56:37 --> Total execution time: 0.1799
DEBUG - 2020-03-29 15:56:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:56:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:56:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:56:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:56:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:56:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:56:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-29 19:56:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 19:56:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 19:56:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 19:56:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 19:56:41 --> Total execution time: 0.1642
DEBUG - 2020-03-29 15:56:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:56:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:56:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 15:56:42 --> Total execution time: 0.1599
DEBUG - 2020-03-29 15:56:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:56:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:56:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:56:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:56:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-29 19:56:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 19:56:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 19:56:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 19:56:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 19:56:55 --> Total execution time: 0.1635
DEBUG - 2020-03-29 15:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:56:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:56:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 15:56:55 --> Total execution time: 0.1336
DEBUG - 2020-03-29 15:56:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:56:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:57:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:57:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:57:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-29 19:57:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 19:57:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 19:57:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 19:57:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 19:57:03 --> Total execution time: 0.1672
DEBUG - 2020-03-29 15:57:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:57:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 15:57:03 --> Total execution time: 0.1666
DEBUG - 2020-03-29 15:57:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:57:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:57:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:57:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-29 19:57:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 19:57:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 19:57:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 19:57:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 19:57:17 --> Total execution time: 0.1655
DEBUG - 2020-03-29 15:57:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:57:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 15:57:17 --> Total execution time: 0.1599
DEBUG - 2020-03-29 15:57:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:57:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:57:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:57:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-29 19:57:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 19:57:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 19:57:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 19:57:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 19:57:32 --> Total execution time: 0.1653
DEBUG - 2020-03-29 15:57:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:57:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 15:57:32 --> Total execution time: 0.1408
DEBUG - 2020-03-29 15:57:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 19:57:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-03-29 19:57:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-29 19:57:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-29 19:57:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-29 19:57:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-29 19:57:34 --> Total execution time: 0.1838
DEBUG - 2020-03-29 15:57:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 15:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 15:57:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 15:57:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-29 15:57:35 --> Total execution time: 0.1379
DEBUG - 2020-03-29 16:00:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:00:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:00:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 93
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 95
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 106
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 93
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 95
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 106
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 93
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 95
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 106
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 93
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 95
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 106
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:00:21 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:00:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\shipan7.2\htdocs\xplore\system\core\Exceptions.php:271) D:\shipan7.2\htdocs\xplore\system\core\Common.php 575
DEBUG - 2020-03-29 20:00:21 --> Total execution time: 0.7926
DEBUG - 2020-03-29 16:00:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:00:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:00:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 16:01:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:01:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:01:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 93
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 95
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 106
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 93
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 95
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 106
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 93
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 95
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 106
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 93
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 95
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 106
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:01:12 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\controllers\api\GameController.php 107
ERROR - 2020-03-29 20:01:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\shipan7.2\htdocs\xplore\system\core\Exceptions.php:271) D:\shipan7.2\htdocs\xplore\system\core\Common.php 575
DEBUG - 2020-03-29 20:01:12 --> Total execution time: 0.6617
DEBUG - 2020-03-29 16:02:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:02:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:02:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 20:02:37 --> Total execution time: 0.3066
DEBUG - 2020-03-29 16:06:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:06:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:06:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 20:06:00 --> Total execution time: 0.4477
DEBUG - 2020-03-29 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:31:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:31:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 20:31:06 --> Total execution time: 0.1893
DEBUG - 2020-03-29 16:31:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:31:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:31:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 20:31:34 --> Total execution time: 0.1530
DEBUG - 2020-03-29 16:31:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:31:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:31:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 20:31:38 --> Total execution time: 0.2856
DEBUG - 2020-03-29 16:32:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:32:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:32:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 20:32:01 --> Total execution time: 0.1302
DEBUG - 2020-03-29 16:35:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:35:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:35:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 20:35:27 --> Total execution time: 0.3700
DEBUG - 2020-03-29 16:36:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:36:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:36:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 20:36:05 --> Total execution time: 0.1628
DEBUG - 2020-03-29 16:36:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 16:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 20:36:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 20:36:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 20:36:23 --> Total execution time: 0.2473
DEBUG - 2020-03-29 17:37:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-29 17:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-29 21:37:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-29 21:37:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-29 21:37:45 --> Total execution time: 4.7067
