<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-28 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-28 13:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-28 18:08:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-28 18:08:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-28 18:08:38 --> Total execution time: 3.0701
DEBUG - 2020-03-28 13:10:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-28 13:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-28 18:10:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-28 18:10:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-28 18:10:03 --> Total execution time: 0.2171
