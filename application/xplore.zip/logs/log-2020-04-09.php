<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-04-09 11:32:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:32:10 --> No URI present. Default controller set.
DEBUG - 2020-04-09 11:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:32:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-09 11:32:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\shipan7.2\htdocs\xplore\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-04-09 11:32:15 --> Unable to connect to the database
DEBUG - 2020-04-09 11:32:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:32:49 --> No URI present. Default controller set.
DEBUG - 2020-04-09 11:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:32:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:32:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-09 11:32:49 --> Total execution time: 0.2241
DEBUG - 2020-04-09 11:32:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:32:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:32:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:32:49 --> Total execution time: 0.0948
DEBUG - 2020-04-09 11:32:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:32:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:32:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:32:50 --> Total execution time: 0.0821
DEBUG - 2020-04-09 11:32:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:32:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:32:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:32:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-09 15:32:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-09 15:32:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 15:32:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 15:32:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 15:32:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 15:32:54 --> Total execution time: 0.2294
DEBUG - 2020-04-09 11:32:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:32:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:32:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:32:54 --> Total execution time: 0.0802
DEBUG - 2020-04-09 11:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:33:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:33:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:33:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 15:33:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 15:33:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 15:33:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 15:33:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 15:33:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 15:33:11 --> Total execution time: 0.4250
DEBUG - 2020-04-09 11:33:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:33:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:33:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:33:11 --> Total execution time: 0.0772
DEBUG - 2020-04-09 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:33:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:33:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:33:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:33:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 11:34:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:34:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:34:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:34:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 15:34:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 15:34:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 15:34:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 15:34:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 15:34:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 15:34:30 --> Total execution time: 0.1332
DEBUG - 2020-04-09 11:34:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:34:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:34:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:34:30 --> Total execution time: 0.0941
DEBUG - 2020-04-09 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:34:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:34:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:34:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:34:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 11:35:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:35:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:35:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:35:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 15:35:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 15:35:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 15:35:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 15:35:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 15:35:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 15:35:49 --> Total execution time: 0.1212
DEBUG - 2020-04-09 11:35:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:35:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:35:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:35:49 --> Total execution time: 0.1026
DEBUG - 2020-04-09 11:35:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:35:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:35:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:35:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:35:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:35:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 11:35:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:35:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:35:54 --> Total execution time: 0.1098
DEBUG - 2020-04-09 11:36:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:36:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:36:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 15:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 15:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 15:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 15:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 15:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 15:36:30 --> Total execution time: 0.1215
DEBUG - 2020-04-09 11:36:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:36:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:36:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:36:30 --> Total execution time: 0.0983
DEBUG - 2020-04-09 11:36:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:36:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:36:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:36:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:36:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:36:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 11:42:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:42:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:42:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 15:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 15:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 15:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 15:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 15:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 15:42:51 --> Total execution time: 0.1651
DEBUG - 2020-04-09 11:42:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:42:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:42:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:42:51 --> Total execution time: 0.1125
DEBUG - 2020-04-09 11:42:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:42:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:42:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:42:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:42:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:42:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:42:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:42:56 --> Total execution time: 0.0478
DEBUG - 2020-04-09 11:43:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:43:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:43:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 15:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 15:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 15:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 15:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 15:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 15:43:43 --> Total execution time: 0.0754
DEBUG - 2020-04-09 11:43:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:43:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:43:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:43:43 --> Total execution time: 0.1085
DEBUG - 2020-04-09 11:43:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:43:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:43:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:43:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:43:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 11:52:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:52:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 15:52:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 15:52:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 15:52:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 15:52:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 15:52:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 15:52:04 --> Total execution time: 0.1210
DEBUG - 2020-04-09 11:52:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:52:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:52:05 --> Total execution time: 0.0847
DEBUG - 2020-04-09 11:52:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:52:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:52:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 11:52:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:15 --> Total execution time: 0.1075
DEBUG - 2020-04-09 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:17 --> Total execution time: 0.0497
DEBUG - 2020-04-09 11:52:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:52:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:20 --> Total execution time: 0.0475
DEBUG - 2020-04-09 11:52:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:25 --> Total execution time: 0.0672
DEBUG - 2020-04-09 11:52:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:26 --> Total execution time: 0.0503
DEBUG - 2020-04-09 11:52:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:34 --> Total execution time: 0.0506
DEBUG - 2020-04-09 11:52:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:37 --> Total execution time: 0.0519
DEBUG - 2020-04-09 11:52:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:52:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:52:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:52:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 15:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 15:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 15:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 15:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 15:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 15:52:43 --> Total execution time: 0.0741
DEBUG - 2020-04-09 11:52:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:52:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:52:43 --> Total execution time: 0.0802
DEBUG - 2020-04-09 11:52:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:52:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:52:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 11:52:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:50 --> Total execution time: 0.0600
DEBUG - 2020-04-09 11:52:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:52 --> Total execution time: 0.0519
DEBUG - 2020-04-09 11:52:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:52:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:52:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:52:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:52:58 --> Total execution time: 0.0491
DEBUG - 2020-04-09 11:53:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:53:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:53:02 --> Total execution time: 0.0627
DEBUG - 2020-04-09 11:53:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:53:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:53:03 --> Total execution time: 0.0499
DEBUG - 2020-04-09 11:56:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:56:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 15:56:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 15:56:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 15:56:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 15:56:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 15:56:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 15:56:08 --> Total execution time: 0.0908
DEBUG - 2020-04-09 11:56:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:56:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:56:08 --> Total execution time: 0.0803
DEBUG - 2020-04-09 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:56:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 11:56:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:14 --> Total execution time: 0.0681
DEBUG - 2020-04-09 11:56:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:15 --> Total execution time: 0.0512
DEBUG - 2020-04-09 11:56:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:56:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:56:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:19 --> Total execution time: 0.0477
DEBUG - 2020-04-09 11:56:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:22 --> Total execution time: 0.0605
DEBUG - 2020-04-09 11:56:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:24 --> Total execution time: 0.0533
DEBUG - 2020-04-09 11:56:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:56:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:56:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:31 --> Total execution time: 0.0494
DEBUG - 2020-04-09 11:56:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:34 --> Total execution time: 0.0558
DEBUG - 2020-04-09 11:56:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:36 --> Total execution time: 0.0534
DEBUG - 2020-04-09 11:56:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:56:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:56:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:56:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:56:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:56:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:57:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:57:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:57:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:57:07 --> Total execution time: 0.2218
DEBUG - 2020-04-09 11:57:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:57:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:57:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:57:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:57:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:57:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:57:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:57:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:57:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:57:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 11:57:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 11:57:50 --> Total execution time: 0.1389
DEBUG - 2020-04-09 11:57:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:57:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:57:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:57:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:58:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:58:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:58:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:59:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:59:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:59:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:59:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 11:59:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 11:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 11:59:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:59:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 15:59:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
ERROR - 2020-04-09 15:59:32 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 202
ERROR - 2020-04-09 15:59:32 --> Severity: Notice --> Array to string conversion D:\shipan7.2\htdocs\xplore\application\modules\question\controllers\Question.php 202
DEBUG - 2020-04-09 12:03:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:03:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:03:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:03:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:03:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:03:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:03:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:03:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:04:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:04:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:04:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:04:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:04:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:04:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:04:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:04:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:04:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 16:04:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 16:04:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:04:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:04:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:04:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:04:08 --> Total execution time: 0.1968
DEBUG - 2020-04-09 12:04:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:04:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:04:09 --> Total execution time: 0.0891
DEBUG - 2020-04-09 12:04:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:04:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:04:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:04:11 --> Total execution time: 0.0831
DEBUG - 2020-04-09 12:04:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:04:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:04:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:04:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:04:17 --> Total execution time: 0.0686
DEBUG - 2020-04-09 12:04:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:04:20 --> Total execution time: 0.0771
DEBUG - 2020-04-09 12:04:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:04:22 --> Total execution time: 0.0659
DEBUG - 2020-04-09 12:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:04:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:04:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:04:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:04:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:04:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:04:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:04:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:04:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:07:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:07:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:07:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:07:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:07:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:07:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:07:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:07:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:10:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:10:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:10:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:10:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 16:10:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 16:10:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:10:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:10:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:10:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:10:19 --> Total execution time: 0.1755
DEBUG - 2020-04-09 12:10:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:10:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:10:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:10:19 --> Total execution time: 0.0800
DEBUG - 2020-04-09 12:10:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:10:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:10:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:10:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:10:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:10:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:10:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:10:24 --> Total execution time: 0.1096
DEBUG - 2020-04-09 12:10:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:10:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:10:33 --> Total execution time: 0.0568
DEBUG - 2020-04-09 12:10:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:10:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:10:35 --> Total execution time: 0.0506
DEBUG - 2020-04-09 12:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:10:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:10:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:10:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:10:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:10:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:10:40 --> Total execution time: 0.0483
DEBUG - 2020-04-09 12:11:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:11:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:11:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:11:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 16:11:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 16:11:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:11:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:11:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:11:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:11:53 --> Total execution time: 0.0800
DEBUG - 2020-04-09 12:11:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:11:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:11:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:11:53 --> Total execution time: 0.1117
DEBUG - 2020-04-09 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:11:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:11:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:11:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:11:55 --> Total execution time: 0.0643
DEBUG - 2020-04-09 12:11:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:11:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:11:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:11:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:12:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:06 --> Total execution time: 0.0532
DEBUG - 2020-04-09 12:12:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:08 --> Total execution time: 0.0578
DEBUG - 2020-04-09 12:12:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:12:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:12:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:12 --> Total execution time: 0.0481
DEBUG - 2020-04-09 12:12:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:22 --> Total execution time: 0.0524
DEBUG - 2020-04-09 12:12:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:23 --> Total execution time: 0.0526
DEBUG - 2020-04-09 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:12:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:12:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:28 --> Total execution time: 0.0475
DEBUG - 2020-04-09 12:12:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:30 --> Total execution time: 0.0547
DEBUG - 2020-04-09 12:12:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:12:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:12:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:37 --> Total execution time: 0.0477
DEBUG - 2020-04-09 12:12:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:41 --> Total execution time: 0.0649
DEBUG - 2020-04-09 12:12:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:43 --> Total execution time: 0.0554
DEBUG - 2020-04-09 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:12:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:12:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:12:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:12:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:16:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:16:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:16:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 16:16:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 16:16:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:16:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:16:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:16:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:16:05 --> Total execution time: 0.2651
DEBUG - 2020-04-09 12:16:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:16:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:16:06 --> Total execution time: 0.0701
DEBUG - 2020-04-09 12:16:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:16:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:16:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:16:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:16:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:16:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 16:16:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 16:16:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:16:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:16:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:16:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:16:24 --> Total execution time: 0.0879
DEBUG - 2020-04-09 12:16:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:16:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:16:24 --> Total execution time: 0.0983
DEBUG - 2020-04-09 12:16:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:16:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:16:25 --> Total execution time: 0.0570
DEBUG - 2020-04-09 12:16:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:16:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:16:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:16:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:16:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:16:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:16:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:16:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:16:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 16:16:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 16:16:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:16:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:16:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:16:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:16:30 --> Total execution time: 0.0819
DEBUG - 2020-04-09 12:16:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:16:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:16:30 --> Total execution time: 0.0833
DEBUG - 2020-04-09 12:16:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:16:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:16:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 16:16:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 16:16:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:16:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:16:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:16:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:16:34 --> Total execution time: 0.0753
DEBUG - 2020-04-09 12:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:16:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:16:34 --> Total execution time: 0.0773
DEBUG - 2020-04-09 12:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:16:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:16:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:16:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:16:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:22:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:22:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:22:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:22:54 --> No URI present. Default controller set.
DEBUG - 2020-04-09 12:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:22:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:22:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-09 12:22:54 --> Total execution time: 0.0963
DEBUG - 2020-04-09 12:22:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:22:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:22:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:22:54 --> Total execution time: 0.0841
DEBUG - 2020-04-09 12:23:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:23:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-09 12:23:01 --> Query error: Table 'xploredb.roles' doesn't exist - Invalid query: SELECT *
FROM `roles`
WHERE `id` = '1'
ORDER BY `id` DESC
 LIMIT 1
DEBUG - 2020-04-09 12:29:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:29:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-09 12:29:59 --> Query error: Table 'xploredb.roles' doesn't exist - Invalid query: SELECT *
FROM `roles`
WHERE `id` = '1'
ORDER BY `id` DESC
 LIMIT 1
DEBUG - 2020-04-09 12:36:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:36:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:36:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:36:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-09 16:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-09 16:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:36:17 --> Total execution time: 0.1977
DEBUG - 2020-04-09 12:36:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:36:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:36:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:36:17 --> Total execution time: 0.1077
DEBUG - 2020-04-09 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:36:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:36:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:36:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 16:36:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 16:36:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:36:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:36:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:36:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:36:21 --> Total execution time: 0.2028
DEBUG - 2020-04-09 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:36:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:36:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:36:21 --> Total execution time: 0.1131
DEBUG - 2020-04-09 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:36:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:36:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:36:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:36:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:36:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:36:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:36:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:36:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:36:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 16:36:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 16:36:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:36:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:36:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:36:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:36:25 --> Total execution time: 0.1897
DEBUG - 2020-04-09 12:36:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:36:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:36:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:36:25 --> Total execution time: 0.4721
DEBUG - 2020-04-09 12:36:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:36:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:36:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:36:26 --> Total execution time: 0.0937
DEBUG - 2020-04-09 12:36:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:36:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:36:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:36:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:39:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:39:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:39:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 16:39:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 16:39:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:39:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:39:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:39:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:39:34 --> Total execution time: 0.1134
DEBUG - 2020-04-09 12:39:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:39:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:39:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:39:35 --> Total execution time: 0.1128
DEBUG - 2020-04-09 12:39:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:39:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:39:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:39:36 --> Total execution time: 0.1242
DEBUG - 2020-04-09 12:39:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:39:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:39:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:39:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:39:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:39:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:39:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:39:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 16:39:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 16:39:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 16:39:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 16:39:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 16:39:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 16:39:56 --> Total execution time: 0.3148
DEBUG - 2020-04-09 12:39:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:39:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:39:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:39:57 --> Total execution time: 0.2193
DEBUG - 2020-04-09 12:39:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:39:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 12:39:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 12:39:58 --> Total execution time: 0.1826
DEBUG - 2020-04-09 12:39:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:39:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:39:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:39:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 12:40:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:40:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:40:02 --> Total execution time: 0.0945
DEBUG - 2020-04-09 12:55:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:55:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:55:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:55:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:55:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:55:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:55:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:55:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:55:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:55:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:55:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:55:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:55:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:55:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:55:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:55:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:55:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:55:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:55:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:56:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:56:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:56:16 --> Total execution time: 0.1202
DEBUG - 2020-04-09 12:56:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:56:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:56:21 --> Total execution time: 0.2196
DEBUG - 2020-04-09 12:56:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:56:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:56:22 --> Total execution time: 0.0903
DEBUG - 2020-04-09 12:56:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:56:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:56:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 16:56:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/topic-relation.php
DEBUG - 2020-04-09 12:56:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:56:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:56:30 --> Total execution time: 0.0709
DEBUG - 2020-04-09 12:56:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 12:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 12:56:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 16:56:34 --> Total execution time: 0.0704
DEBUG - 2020-04-09 13:02:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:02:20 --> Total execution time: 0.0680
DEBUG - 2020-04-09 13:02:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:02:21 --> Total execution time: 0.2212
DEBUG - 2020-04-09 13:02:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:02:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:02:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:02:28 --> Total execution time: 0.3910
DEBUG - 2020-04-09 13:02:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:02:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:02:29 --> Total execution time: 0.4826
DEBUG - 2020-04-09 13:02:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:02:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:02:30 --> Total execution time: 0.1489
DEBUG - 2020-04-09 13:02:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:02:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:02:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:02:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:02:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:02:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:02:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:02:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:02:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:02:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:02:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:02:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:02:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:02:38 --> Total execution time: 0.2297
DEBUG - 2020-04-09 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:02:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:02:39 --> Total execution time: 0.2817
DEBUG - 2020-04-09 13:02:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:02:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:02:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:02:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:02:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:02:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:02:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:02:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:02:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:02:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:02:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:02:54 --> Total execution time: 0.1728
DEBUG - 2020-04-09 13:02:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:02:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:02:54 --> Total execution time: 0.1063
DEBUG - 2020-04-09 13:02:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:02:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:02:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:02:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:02:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:03:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:03:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:03:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:03:06 --> Total execution time: 0.1765
DEBUG - 2020-04-09 13:03:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:03:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:03:06 --> Total execution time: 0.1075
DEBUG - 2020-04-09 13:03:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:03:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:03:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:03:07 --> Total execution time: 0.1338
DEBUG - 2020-04-09 13:03:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:03:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:03:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:03:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:03:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:03:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:03:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:03:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:03:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:03:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:03:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:03:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:03:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:03:33 --> Total execution time: 0.3269
DEBUG - 2020-04-09 13:03:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:03:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:03:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:03:33 --> Total execution time: 0.1214
DEBUG - 2020-04-09 13:03:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:03:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:03:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:03:34 --> Total execution time: 0.0935
DEBUG - 2020-04-09 13:03:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:03:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:03:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:03:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:04:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:04:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:04:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:04:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:04:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:04:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:04:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:04:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:04:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:04:11 --> Total execution time: 0.1056
DEBUG - 2020-04-09 13:04:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:04:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:04:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:04:11 --> Total execution time: 0.1313
DEBUG - 2020-04-09 13:04:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:04:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:04:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:04:13 --> Total execution time: 0.2061
DEBUG - 2020-04-09 13:04:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:04:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:04:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:04:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:04:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:04:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:04:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:04:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:04:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:04:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:04:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:04:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:04:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:04:55 --> Total execution time: 0.2001
DEBUG - 2020-04-09 13:04:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:04:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:04:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:04:56 --> Total execution time: 0.1681
DEBUG - 2020-04-09 13:04:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:04:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:04:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:04:57 --> Total execution time: 0.1220
DEBUG - 2020-04-09 13:04:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:04:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:04:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:04:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:05:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:05:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:05:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:05:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:05:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:05:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:05:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:05:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:05:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:05:47 --> Total execution time: 0.1321
DEBUG - 2020-04-09 13:05:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:05:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:05:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:05:47 --> Total execution time: 0.1084
DEBUG - 2020-04-09 13:05:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:05:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:05:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:05:48 --> Total execution time: 0.1060
DEBUG - 2020-04-09 13:05:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:05:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:05:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:05:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:05:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:05:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:05:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:05:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:05:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:05:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:05:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:05:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:05:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:05:57 --> Total execution time: 0.3483
DEBUG - 2020-04-09 13:05:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:05:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:05:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:05:57 --> Total execution time: 0.1151
DEBUG - 2020-04-09 13:05:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:05:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:05:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:05:59 --> Total execution time: 0.1172
DEBUG - 2020-04-09 13:05:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:05:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:05:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:05:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:06:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:06:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:06:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:06:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:06:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:06:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:06:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:06:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:06:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:06:30 --> Total execution time: 0.2642
DEBUG - 2020-04-09 13:06:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:06:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:06:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:06:30 --> Total execution time: 0.1323
DEBUG - 2020-04-09 13:06:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:06:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:06:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:06:32 --> Total execution time: 0.1278
DEBUG - 2020-04-09 13:06:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:06:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:06:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:06:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:06:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:06:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:06:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:06:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:06:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:06:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:06:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:06:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:06:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:06:47 --> Total execution time: 0.2114
DEBUG - 2020-04-09 13:06:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:06:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:06:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:06:47 --> Total execution time: 0.1214
DEBUG - 2020-04-09 13:06:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:06:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:06:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:06:48 --> Total execution time: 0.1132
DEBUG - 2020-04-09 13:06:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:06:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:06:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:06:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:10:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:10:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:10:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:10:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 17:10:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 17:10:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:10:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:10:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:10:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:10:23 --> Total execution time: 0.2144
DEBUG - 2020-04-09 13:10:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:10:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:10:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:10:23 --> Total execution time: 0.1088
DEBUG - 2020-04-09 13:10:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:10:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:10:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:10:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:10:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:10:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 13:10:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:10:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-09 17:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-09 17:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:10:36 --> Total execution time: 0.2265
DEBUG - 2020-04-09 13:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:10:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:10:36 --> Total execution time: 0.1426
DEBUG - 2020-04-09 13:10:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:10:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-09 17:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-09 17:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:10:40 --> Total execution time: 0.1448
DEBUG - 2020-04-09 13:10:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:10:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:10:40 --> Total execution time: 0.1118
DEBUG - 2020-04-09 13:15:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:15:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:15:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-09 17:15:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-09 17:15:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:15:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:15:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:15:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:15:07 --> Total execution time: 0.1306
DEBUG - 2020-04-09 13:15:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:15:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:15:08 --> Total execution time: 0.1776
DEBUG - 2020-04-09 13:16:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:16:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-09 17:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-09 17:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:16:42 --> Total execution time: 0.2164
DEBUG - 2020-04-09 13:16:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:16:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:16:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:16:42 --> Total execution time: 0.0978
DEBUG - 2020-04-09 13:43:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:43:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:43:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:43:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 17:43:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 17:43:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 17:43:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 17:43:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 17:43:26 --> Total execution time: 0.1979
DEBUG - 2020-04-09 13:43:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:43:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 13:43:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 13:43:27 --> Total execution time: 0.4321
DEBUG - 2020-04-09 13:43:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 13:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 13:43:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 17:43:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 17:43:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:01:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:01:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:01:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:01:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:01:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:01:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:01:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:01:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:01:17 --> Total execution time: 0.3449
DEBUG - 2020-04-09 14:01:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:01:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:01:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:01:17 --> Total execution time: 0.1225
DEBUG - 2020-04-09 14:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:01:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:01:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:01:22 --> Total execution time: 0.1881
DEBUG - 2020-04-09 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:01:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:01:24 --> Total execution time: 0.1299
DEBUG - 2020-04-09 14:01:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:01:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:01:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:01:24 --> Total execution time: 0.1294
DEBUG - 2020-04-09 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:01:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:01:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:01:26 --> Total execution time: 0.1414
DEBUG - 2020-04-09 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:01:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:01:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:01:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:01:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:01:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:01:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:01:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:01:28 --> Total execution time: 0.1218
DEBUG - 2020-04-09 14:01:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:01:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:01:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:01:29 --> Total execution time: 0.1635
DEBUG - 2020-04-09 14:01:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:01:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:01:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:01:30 --> Total execution time: 0.1514
DEBUG - 2020-04-09 14:02:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:02:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:02:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:02:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:02:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:02:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:02:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:02:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:02:00 --> Total execution time: 0.1079
DEBUG - 2020-04-09 14:02:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:02:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:02:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:02:01 --> Total execution time: 0.1372
DEBUG - 2020-04-09 14:02:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:02:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:02:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:02:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:02:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:02:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:02:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:02:02 --> Total execution time: 0.2773
DEBUG - 2020-04-09 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:02:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:02:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:02:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:02:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:02:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:02:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:02:22 --> Total execution time: 0.1349
DEBUG - 2020-04-09 14:03:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:03:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:03:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:03:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:03:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:03:06 --> Total execution time: 0.1183
DEBUG - 2020-04-09 14:03:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:03:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:03:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 14:03:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:03:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:03:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:03:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:03:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:03:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:03:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:03:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:03:29 --> Total execution time: 0.1099
DEBUG - 2020-04-09 14:03:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:03:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:03:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:03:30 --> Total execution time: 0.1293
DEBUG - 2020-04-09 14:03:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:03:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:03:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:03:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:03:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 14:03:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:03:31 --> Total execution time: 0.2316
DEBUG - 2020-04-09 14:03:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:03:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:03:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:03:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:03:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:03:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:03:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:03:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:03:56 --> Total execution time: 0.1745
DEBUG - 2020-04-09 14:03:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:03:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:03:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:03:56 --> Total execution time: 0.1400
DEBUG - 2020-04-09 14:03:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:03:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:03:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:03:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:03:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 14:03:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:03:58 --> Total execution time: 0.2266
DEBUG - 2020-04-09 14:04:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:04:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:04:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:04:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:04:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:04:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:04:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:04:02 --> Total execution time: 0.1631
DEBUG - 2020-04-09 14:04:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:04:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:04:02 --> Total execution time: 0.1604
DEBUG - 2020-04-09 14:04:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:04:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:04:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:04:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:04:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:04:04 --> Total execution time: 0.2706
DEBUG - 2020-04-09 14:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:04:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:04:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:04:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:04:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:04:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:04:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:04:24 --> Total execution time: 0.1072
DEBUG - 2020-04-09 14:04:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:04:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:04:24 --> Total execution time: 0.1155
DEBUG - 2020-04-09 14:04:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:04:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-04-09 18:04:26 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:26 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:26 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:26 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:26 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:26 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:26 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:26 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:26 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:26 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
DEBUG - 2020-04-09 18:04:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:04:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:04:26 --> Total execution time: 0.4706
DEBUG - 2020-04-09 14:04:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:04:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:04:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:04:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:04:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:04:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:04:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:04:48 --> Total execution time: 0.1953
DEBUG - 2020-04-09 14:04:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:04:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:04:48 --> Total execution time: 0.1424
DEBUG - 2020-04-09 14:04:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:04:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:04:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-04-09 18:04:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:04:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
DEBUG - 2020-04-09 18:04:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:04:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:04:50 --> Total execution time: 0.5373
DEBUG - 2020-04-09 14:05:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:05:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:05:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-04-09 18:05:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:05:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:05:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:05:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:05:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:05:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:05:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:05:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:05:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:05:50 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
DEBUG - 2020-04-09 18:05:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:06:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:06:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:06:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:06:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:06:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-04-09 18:06:49 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:06:49 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:06:49 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:06:49 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:06:49 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:06:49 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:06:49 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:06:49 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:06:49 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
ERROR - 2020-04-09 18:06:49 --> Severity: Notice --> Undefined index: answer D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 6
DEBUG - 2020-04-09 18:06:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:07:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:07:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 14:07:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:07:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:07:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:07:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:08:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:08:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:08:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:08:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:08:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:08:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:08:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:08:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:09:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:09:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:09:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:09:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:09:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:09:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:09:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:09:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:09:00 --> Total execution time: 0.1082
DEBUG - 2020-04-09 14:09:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:09:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:09:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:09:00 --> Total execution time: 0.1429
DEBUG - 2020-04-09 14:09:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:09:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:09:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:09:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:09:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:09:01 --> Total execution time: 0.1364
DEBUG - 2020-04-09 18:09:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:09:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:09:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:09:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:09:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:09:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:09:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:09:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:09:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:09:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:09:28 --> Total execution time: 0.0906
DEBUG - 2020-04-09 14:09:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:09:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:09:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:09:28 --> Total execution time: 0.1164
DEBUG - 2020-04-09 14:09:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:09:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:09:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:09:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:09:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:09:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:09:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-details.php
DEBUG - 2020-04-09 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:09:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:09:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:09:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:09:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:09:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:09:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:09:46 --> Total execution time: 0.2596
DEBUG - 2020-04-09 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:11:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:11:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:11:03 --> Total execution time: 0.0986
DEBUG - 2020-04-09 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:11:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:11:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:11:04 --> Total execution time: 0.1250
DEBUG - 2020-04-09 14:11:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:11:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:11:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:11:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:11:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:11:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:11:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:11:05 --> Total execution time: 0.3534
DEBUG - 2020-04-09 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:11:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:11:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:11:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:13:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:13:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:13:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:13:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:13:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:13:04 --> Total execution time: 0.2200
DEBUG - 2020-04-09 14:13:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:13:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:13:05 --> Total execution time: 0.1254
DEBUG - 2020-04-09 14:13:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:13:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:13:06 --> Total execution time: 0.5181
DEBUG - 2020-04-09 14:13:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:13:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-04-09 18:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:13:19 --> Total execution time: 0.1942
DEBUG - 2020-04-09 14:13:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:13:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:13:19 --> Total execution time: 0.1345
DEBUG - 2020-04-09 14:13:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-04-09 14:13:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:13:20 --> Total execution time: 0.3187
DEBUG - 2020-04-09 14:13:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 14:13:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 14:13:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 14:13:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 14:13:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-04-09 18:13:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:13:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:13:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:13:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:13:31 --> Total execution time: 0.1066
DEBUG - 2020-04-09 14:13:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:13:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:13:32 --> Total execution time: 0.1548
DEBUG - 2020-04-09 14:13:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-04-09 14:13:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:13:33 --> Total execution time: 0.3098
DEBUG - 2020-04-09 14:13:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:13:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:13:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:13:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 14:14:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:14:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:14:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:14:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-04-09 18:14:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:14:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:14:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:14:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:14:30 --> Total execution time: 0.1576
DEBUG - 2020-04-09 14:14:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:14:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:14:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:14:31 --> Total execution time: 0.1685
DEBUG - 2020-04-09 14:14:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:14:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:14:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:14:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:14:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:14:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-04-09 14:14:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:14:33 --> Total execution time: 0.7280
DEBUG - 2020-04-09 14:15:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:15:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:15:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-04-09 18:15:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:15:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:15:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:15:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:15:01 --> Total execution time: 0.1536
DEBUG - 2020-04-09 14:15:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:15:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:15:01 --> Total execution time: 0.1316
DEBUG - 2020-04-09 14:15:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:15:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:15:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:15:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-04-09 14:15:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:15:03 --> Total execution time: 0.4091
DEBUG - 2020-04-09 14:15:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:15:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:15:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-04-09 14:15:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:15:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:15:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:15:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:15:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:15:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:15:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:15:14 --> Total execution time: 0.1236
DEBUG - 2020-04-09 14:15:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:15:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:15:14 --> Total execution time: 0.1347
DEBUG - 2020-04-09 14:15:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:15:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:15:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:15:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:15:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:15:15 --> Total execution time: 0.4506
DEBUG - 2020-04-09 14:15:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:15:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:15:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:15:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:15:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:15:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:15:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:15:39 --> Total execution time: 0.1324
DEBUG - 2020-04-09 14:15:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:15:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:15:39 --> Total execution time: 0.1636
DEBUG - 2020-04-09 14:15:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:15:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:15:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:15:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:15:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:15:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:15:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:15:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:15:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:15:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:15:42 --> Total execution time: 0.0970
DEBUG - 2020-04-09 14:15:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:15:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:15:42 --> Total execution time: 0.1076
DEBUG - 2020-04-09 14:15:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:15:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:15:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:15:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:15:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:15:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:15:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:15:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:15:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:15:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:17:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:17:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:17:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:17:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:17:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:17:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:17:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:17:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:17:44 --> Total execution time: 0.0979
DEBUG - 2020-04-09 14:17:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:17:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:17:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:17:44 --> Total execution time: 0.1054
DEBUG - 2020-04-09 14:17:45 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:17:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:18:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:18:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:18:17 --> Total execution time: 0.1666
DEBUG - 2020-04-09 14:18:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:18:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:18:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:18:18 --> Total execution time: 0.0902
DEBUG - 2020-04-09 14:18:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:18:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:18:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:18:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:28:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:28:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:28:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:28:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:28:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:28:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:28:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:28:57 --> Total execution time: 0.2395
DEBUG - 2020-04-09 14:28:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:28:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:28:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:28:57 --> Total execution time: 0.1469
DEBUG - 2020-04-09 14:28:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:28:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:28:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:28:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:35:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:35:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:35:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:35:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:35:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:35:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:35:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:35:19 --> Total execution time: 0.1882
DEBUG - 2020-04-09 14:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:35:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:35:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:35:19 --> Total execution time: 0.3896
DEBUG - 2020-04-09 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:35:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:35:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:35:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:35:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 14:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:35:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:35:22 --> Total execution time: 0.1008
DEBUG - 2020-04-09 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:35:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:35:23 --> Total execution time: 0.1207
DEBUG - 2020-04-09 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:35:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:36:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:36:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:36:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:36:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:36:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:36:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:36:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:36:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:36:37 --> Total execution time: 0.0907
DEBUG - 2020-04-09 14:36:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:36:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:36:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:36:37 --> Total execution time: 0.1139
DEBUG - 2020-04-09 14:36:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:36:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:36:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-04-09 18:36:38 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 12
ERROR - 2020-04-09 18:36:38 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 12
ERROR - 2020-04-09 18:36:38 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 12
ERROR - 2020-04-09 18:36:38 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 12
ERROR - 2020-04-09 18:36:38 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 12
ERROR - 2020-04-09 18:36:38 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 12
ERROR - 2020-04-09 18:36:38 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 12
ERROR - 2020-04-09 18:36:38 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 12
ERROR - 2020-04-09 18:36:38 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 12
ERROR - 2020-04-09 18:36:38 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-report-view.php 12
DEBUG - 2020-04-09 18:36:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:36:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:36:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:36:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:36:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:36:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:36:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:36:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:36:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:36:53 --> Total execution time: 0.1266
DEBUG - 2020-04-09 14:36:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:36:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:36:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:36:53 --> Total execution time: 0.1024
DEBUG - 2020-04-09 14:36:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:36:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:36:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:36:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:38:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:38:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:38:02 --> Total execution time: 0.0839
DEBUG - 2020-04-09 14:38:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:38:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:38:03 --> Total execution time: 0.1022
DEBUG - 2020-04-09 14:38:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:38:11 --> Total execution time: 0.0936
DEBUG - 2020-04-09 14:38:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:38:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:38:11 --> Total execution time: 0.1607
DEBUG - 2020-04-09 14:38:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 14:38:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:38:15 --> Total execution time: 0.0977
DEBUG - 2020-04-09 14:38:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:38:15 --> Total execution time: 0.1424
DEBUG - 2020-04-09 14:38:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 14:38:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:38:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:38:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:38:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:38:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:38:19 --> Total execution time: 0.0978
DEBUG - 2020-04-09 14:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:38:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:38:20 --> Total execution time: 0.1714
DEBUG - 2020-04-09 14:38:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 14:38:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:38:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:38:23 --> Total execution time: 0.1040
DEBUG - 2020-04-09 14:38:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:38:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:38:24 --> Total execution time: 0.1242
DEBUG - 2020-04-09 14:38:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-04-09 18:38:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:38:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:38:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:38:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:38:30 --> Total execution time: 0.1824
DEBUG - 2020-04-09 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:38:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:38:30 --> Total execution time: 0.1046
DEBUG - 2020-04-09 14:38:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-04-09 14:38:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 14:38:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-04-09 18:38:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:38:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:38:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:38:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:38:35 --> Total execution time: 0.1012
DEBUG - 2020-04-09 14:38:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:38:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:38:35 --> Total execution time: 0.1047
DEBUG - 2020-04-09 14:38:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:38:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:38:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:38:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-04-09 14:39:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:39:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:39:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:39:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-04-09 18:39:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:39:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:39:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:39:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:39:11 --> Total execution time: 0.1005
DEBUG - 2020-04-09 14:39:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:39:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:39:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:39:12 --> Total execution time: 0.1543
DEBUG - 2020-04-09 14:39:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:39:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:39:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-04-09 18:39:13 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
ERROR - 2020-04-09 18:39:13 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
ERROR - 2020-04-09 18:39:13 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
ERROR - 2020-04-09 18:39:13 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
ERROR - 2020-04-09 18:39:13 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
ERROR - 2020-04-09 18:39:13 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
ERROR - 2020-04-09 18:39:13 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
ERROR - 2020-04-09 18:39:13 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
ERROR - 2020-04-09 18:39:13 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
ERROR - 2020-04-09 18:39:13 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\views\user-question-view.php 10
DEBUG - 2020-04-09 18:39:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-04-09 14:40:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:40:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-04-09 18:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:40:06 --> Total execution time: 0.1058
DEBUG - 2020-04-09 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:40:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:40:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:40:06 --> Total execution time: 0.1079
DEBUG - 2020-04-09 14:40:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:40:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:40:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-04-09 18:40:07 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\models\Question_Model.php 310
ERROR - 2020-04-09 18:40:07 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\models\Question_Model.php 310
ERROR - 2020-04-09 18:40:07 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\models\Question_Model.php 310
ERROR - 2020-04-09 18:40:07 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\models\Question_Model.php 310
ERROR - 2020-04-09 18:40:07 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\models\Question_Model.php 310
ERROR - 2020-04-09 18:40:07 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\models\Question_Model.php 310
ERROR - 2020-04-09 18:40:07 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\models\Question_Model.php 310
ERROR - 2020-04-09 18:40:07 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\models\Question_Model.php 310
ERROR - 2020-04-09 18:40:07 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\models\Question_Model.php 310
ERROR - 2020-04-09 18:40:07 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\question\models\Question_Model.php 310
DEBUG - 2020-04-09 18:40:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-04-09 14:40:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:40:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:40:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:40:11 --> Total execution time: 0.3570
DEBUG - 2020-04-09 14:40:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:40:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-04-09 18:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:40:22 --> Total execution time: 0.2688
DEBUG - 2020-04-09 14:40:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:40:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:40:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:40:22 --> Total execution time: 0.1174
DEBUG - 2020-04-09 14:40:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:40:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:40:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:40:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:40:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:40:23 --> Total execution time: 0.1501
DEBUG - 2020-04-09 18:40:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
ERROR - 2020-04-09 18:40:23 --> Query error: Unknown column 'Q.status' in 'field list' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT DISTINCT `Q`.`id`, `Q`.`title`, `Q`.`answer`, `Q`.`status`
FROM `user_question` as `Q`
) CI_count_all_results
DEBUG - 2020-04-09 14:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:41:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:41:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question.php
DEBUG - 2020-04-09 18:41:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:41:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:41:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:41:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:41:24 --> Total execution time: 0.1196
DEBUG - 2020-04-09 14:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:41:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:41:24 --> Total execution time: 0.1128
DEBUG - 2020-04-09 14:41:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:41:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:41:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-view.php
DEBUG - 2020-04-09 14:41:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:41:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:41:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-details.php
DEBUG - 2020-04-09 14:41:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:41:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 18:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 18:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:41:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:41:34 --> Total execution time: 0.1817
DEBUG - 2020-04-09 14:41:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:41:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:41:35 --> Total execution time: 0.1155
DEBUG - 2020-04-09 14:41:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:41:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 14:41:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:41:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:41:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-09 14:41:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:41:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:41:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-04-09 14:41:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:41:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:41:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 18:41:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:41:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:41:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:41:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:41:48 --> Total execution time: 0.0948
DEBUG - 2020-04-09 14:41:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:41:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:41:49 --> Total execution time: 0.1383
DEBUG - 2020-04-09 14:41:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:41:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 18:41:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 14:41:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:41:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 18:41:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:41:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:41:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:41:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:41:53 --> Total execution time: 0.1724
DEBUG - 2020-04-09 14:41:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:41:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:41:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:41:53 --> Total execution time: 0.1347
DEBUG - 2020-04-09 14:42:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:42:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 18:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:42:43 --> Total execution time: 0.1066
DEBUG - 2020-04-09 14:42:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:42:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:42:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:42:43 --> Total execution time: 0.1200
DEBUG - 2020-04-09 14:42:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:42:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:42:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 18:42:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:42:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:42:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:42:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:42:55 --> Total execution time: 0.1086
DEBUG - 2020-04-09 14:42:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:42:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:42:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:42:56 --> Total execution time: 0.1512
DEBUG - 2020-04-09 14:43:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:43:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 18:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 18:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 18:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 18:43:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 18:43:01 --> Total execution time: 0.1005
DEBUG - 2020-04-09 14:43:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 14:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 14:43:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 14:43:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 14:43:02 --> Total execution time: 0.1108
DEBUG - 2020-04-09 15:02:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:02:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:02:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 19:02:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:02:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:02:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:02:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:02:52 --> Total execution time: 0.5099
DEBUG - 2020-04-09 15:02:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:02:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:02:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:02:53 --> Total execution time: 0.1057
DEBUG - 2020-04-09 15:03:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:03:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:03:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-04-09 19:03:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-04-09 19:03:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:03:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:03:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:03:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:03:03 --> Total execution time: 0.1245
DEBUG - 2020-04-09 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:03:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:03:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:03:04 --> Total execution time: 0.1152
DEBUG - 2020-04-09 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:03:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:03:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-04-09 19:03:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-04-09 15:03:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:03:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:03:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Module_model.php
DEBUG - 2020-04-09 19:03:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/views/module.php
DEBUG - 2020-04-09 19:03:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:03:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:03:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:03:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:03:13 --> Total execution time: 0.2579
DEBUG - 2020-04-09 15:03:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:03:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:03:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:03:13 --> Total execution time: 0.1074
DEBUG - 2020-04-09 15:03:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:03:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:03:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Module_model.php
DEBUG - 2020-04-09 19:03:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/views/icon-list.php
DEBUG - 2020-04-09 19:03:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:03:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:03:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:03:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:03:22 --> Total execution time: 0.1836
DEBUG - 2020-04-09 15:03:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:03:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:03:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:03:22 --> Total execution time: 0.3856
DEBUG - 2020-04-09 15:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:03:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
ERROR - 2020-04-09 19:03:42 --> Severity: Notice --> Trying to get property 'facebook' of non-object D:\shipan7.2\htdocs\xplore\application\modules\social\views\social.php 18
ERROR - 2020-04-09 19:03:42 --> Severity: Notice --> Trying to get property 'id' of non-object D:\shipan7.2\htdocs\xplore\application\modules\social\views\social.php 19
ERROR - 2020-04-09 19:03:42 --> Severity: Notice --> Trying to get property 'twitter' of non-object D:\shipan7.2\htdocs\xplore\application\modules\social\views\social.php 25
ERROR - 2020-04-09 19:03:42 --> Severity: Notice --> Trying to get property 'linked_in' of non-object D:\shipan7.2\htdocs\xplore\application\modules\social\views\social.php 31
ERROR - 2020-04-09 19:03:42 --> Severity: Notice --> Trying to get property 'youtube' of non-object D:\shipan7.2\htdocs\xplore\application\modules\social\views\social.php 37
DEBUG - 2020-04-09 19:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/social/views/social.php
DEBUG - 2020-04-09 19:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:03:42 --> Total execution time: 0.1437
DEBUG - 2020-04-09 15:03:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:03:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:03:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:03:42 --> Total execution time: 0.1115
DEBUG - 2020-04-09 15:04:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:04:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/social/views/social.php
DEBUG - 2020-04-09 19:04:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:04:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:04:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:04:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:04:09 --> Total execution time: 0.1084
DEBUG - 2020-04-09 15:04:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:04:09 --> Total execution time: 0.1387
DEBUG - 2020-04-09 15:04:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:04:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/social/views/social.php
DEBUG - 2020-04-09 19:04:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:04:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:04:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:04:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:04:33 --> Total execution time: 0.1076
DEBUG - 2020-04-09 15:04:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:04:33 --> Total execution time: 0.1272
DEBUG - 2020-04-09 15:04:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:04:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/social/views/social.php
DEBUG - 2020-04-09 19:04:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:04:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:04:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:04:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:04:36 --> Total execution time: 0.0973
DEBUG - 2020-04-09 15:04:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:04:36 --> Total execution time: 0.1166
DEBUG - 2020-04-09 15:04:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:04:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/social/views/social.php
DEBUG - 2020-04-09 19:04:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:04:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:04:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:04:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:04:38 --> Total execution time: 0.0960
DEBUG - 2020-04-09 15:04:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:04:38 --> Total execution time: 0.0980
DEBUG - 2020-04-09 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:04:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/social/views/social.php
DEBUG - 2020-04-09 19:04:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:04:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:04:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:04:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:04:40 --> Total execution time: 0.1060
DEBUG - 2020-04-09 15:04:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:04:41 --> Total execution time: 0.0930
DEBUG - 2020-04-09 15:04:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:04:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/social/views/social.php
DEBUG - 2020-04-09 19:04:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:04:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:04:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:04:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:04:43 --> Total execution time: 0.1008
DEBUG - 2020-04-09 15:04:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:04:43 --> Total execution time: 0.1295
DEBUG - 2020-04-09 15:04:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:04:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/social/views/social.php
DEBUG - 2020-04-09 19:04:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:04:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:04:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:04:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:04:46 --> Total execution time: 0.1210
DEBUG - 2020-04-09 15:04:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:04:46 --> Total execution time: 0.1274
DEBUG - 2020-04-09 15:04:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:04:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/social/views/social.php
DEBUG - 2020-04-09 19:04:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:04:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:04:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:04:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:04:53 --> Total execution time: 0.0928
DEBUG - 2020-04-09 15:04:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:04:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:04:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:04:54 --> Total execution time: 0.1209
DEBUG - 2020-04-09 15:06:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:06:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:06:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 19:06:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:06:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:06:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:06:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:06:21 --> Total execution time: 2.0878
DEBUG - 2020-04-09 15:06:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:06:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:06:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:06:22 --> Total execution time: 0.2156
DEBUG - 2020-04-09 15:06:25 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:06:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:08:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:08:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:08:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:08:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:08:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 19:08:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:08:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:08:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:08:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:08:46 --> Total execution time: 0.0903
DEBUG - 2020-04-09 15:08:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:08:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:08:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:08:46 --> Total execution time: 0.1134
DEBUG - 2020-04-09 15:08:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:08:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:08:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 19:08:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:08:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:08:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:08:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:08:49 --> Total execution time: 0.1025
DEBUG - 2020-04-09 15:08:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:08:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:08:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:08:49 --> Total execution time: 0.1489
DEBUG - 2020-04-09 15:08:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:08:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:09:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:09:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:09:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:09:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 19:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:09:37 --> Total execution time: 0.0943
DEBUG - 2020-04-09 15:09:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:09:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:09:37 --> Total execution time: 0.1366
DEBUG - 2020-04-09 15:09:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:09:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:09:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:09:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:09:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 19:09:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:09:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:09:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:09:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:09:47 --> Total execution time: 0.0921
DEBUG - 2020-04-09 15:09:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:09:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:09:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:09:47 --> Total execution time: 0.1605
DEBUG - 2020-04-09 15:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:12:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:12:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:12:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:12:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:12:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:12:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:12:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:12:49 --> Total execution time: 0.2023
DEBUG - 2020-04-09 15:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:12:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:12:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:12:49 --> Total execution time: 0.1058
DEBUG - 2020-04-09 15:12:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:12:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:12:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:12:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:14:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:14:10 --> Total execution time: 0.3675
DEBUG - 2020-04-09 15:14:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:14:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:14:10 --> Total execution time: 0.0960
DEBUG - 2020-04-09 15:14:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:14:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:14:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:14:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:14:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:14:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:14:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:14:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:14:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:14:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:14:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:14:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:14:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:14:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:14:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:14:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:14:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:14:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:14:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:14:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:14:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:14:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:14:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:14:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:14:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:14:55 --> Total execution time: 0.1125
DEBUG - 2020-04-09 15:14:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:14:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:14:55 --> Total execution time: 0.0844
DEBUG - 2020-04-09 15:14:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:14:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:14:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:14:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:14:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:14:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:14:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:15:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:15:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:15:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:15:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:16:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:16:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:16:11 --> Total execution time: 0.0939
DEBUG - 2020-04-09 15:16:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:16:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:16:12 --> Total execution time: 0.0717
DEBUG - 2020-04-09 15:16:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:16:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:16:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:16:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:16:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:16:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:16:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:16:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:16:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:16:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:16:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:16:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:16:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:16:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:16:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:16:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:16:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:16:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:16:33 --> Total execution time: 0.0709
DEBUG - 2020-04-09 15:16:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:16:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:16:33 --> Total execution time: 0.0822
DEBUG - 2020-04-09 15:16:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:16:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:16:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:16:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:16:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:16:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:16:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:16:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:16:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:16:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:16:39 --> Total execution time: 0.0856
DEBUG - 2020-04-09 15:16:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:16:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:16:39 --> Total execution time: 0.0827
DEBUG - 2020-04-09 15:16:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:16:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:16:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:16:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:16:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:16:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:16:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:17:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:17:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:17:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:17:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:17:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:17:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:17:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:17:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:17:05 --> Total execution time: 0.0728
DEBUG - 2020-04-09 15:17:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:17:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:17:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:17:05 --> Total execution time: 0.0841
DEBUG - 2020-04-09 15:17:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:17:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:17:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:17:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:17:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:17:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:17:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:17:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:17:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:17:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:17:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:17:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:17:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:17:32 --> Total execution time: 0.0707
DEBUG - 2020-04-09 15:17:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:17:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:17:32 --> Total execution time: 0.1037
DEBUG - 2020-04-09 15:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:17:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:17:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:17:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:17:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:17:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:17:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:17:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:17:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:17:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:17:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:17:49 --> Total execution time: 0.0720
DEBUG - 2020-04-09 15:17:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:17:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:17:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:17:49 --> Total execution time: 0.0889
DEBUG - 2020-04-09 15:17:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:17:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:17:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:17:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:18:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:18:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:18:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:18:02 --> Total execution time: 0.0712
DEBUG - 2020-04-09 15:18:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:18:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:18:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:18:03 --> Total execution time: 0.0774
DEBUG - 2020-04-09 15:18:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:18:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:18:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:18:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:18:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:18:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:18:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:18:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:18:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:18:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:18:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:18:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:18:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:18:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:18:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:18:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:18:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:18:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:18:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:18:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:18:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:18:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:18:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:18:16 --> Total execution time: 0.0734
DEBUG - 2020-04-09 15:18:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:18:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:18:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:18:16 --> Total execution time: 0.0833
DEBUG - 2020-04-09 15:18:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:18:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:18:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:19:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:19:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 19:19:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:19:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:19:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:19:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:19:09 --> Total execution time: 0.0770
DEBUG - 2020-04-09 15:19:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:19:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:19:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:19:09 --> Total execution time: 0.1072
DEBUG - 2020-04-09 15:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:19:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:19:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/game/views/index.php
DEBUG - 2020-04-09 19:19:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:19:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:19:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:19:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:19:11 --> Total execution time: 0.1579
DEBUG - 2020-04-09 15:19:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:19:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:19:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:19:11 --> Total execution time: 0.0841
DEBUG - 2020-04-09 15:19:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:19:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:19:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/social/views/social.php
DEBUG - 2020-04-09 19:19:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:19:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:19:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:19:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:19:12 --> Total execution time: 0.0881
DEBUG - 2020-04-09 15:19:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:19:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:19:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:19:13 --> Total execution time: 0.0863
DEBUG - 2020-04-09 15:19:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:19:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:19:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-09 19:19:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:19:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:19:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:19:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:19:37 --> Total execution time: 0.0743
DEBUG - 2020-04-09 15:19:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:19:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:19:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:19:37 --> Total execution time: 0.0857
DEBUG - 2020-04-09 15:19:42 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:19:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:20:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:20:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:20:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:20:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/report-question.php
DEBUG - 2020-04-09 19:20:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:20:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:20:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:20:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:20:13 --> Total execution time: 0.0721
DEBUG - 2020-04-09 15:20:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:20:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:20:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:20:13 --> Total execution time: 0.1052
DEBUG - 2020-04-09 15:20:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:20:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:20:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:20:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/user-question-report-view.php
DEBUG - 2020-04-09 15:21:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:21:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:21:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:21:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-09 19:21:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-09 19:21:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:21:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:21:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:21:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:21:12 --> Total execution time: 0.1660
DEBUG - 2020-04-09 15:21:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:21:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:21:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:21:12 --> Total execution time: 0.0818
DEBUG - 2020-04-09 15:21:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:21:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:21:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:21:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:21:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-09 19:21:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-09 15:21:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:21:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:21:17 --> Total execution time: 0.0674
DEBUG - 2020-04-09 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:21:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:21:18 --> Total execution time: 0.0618
DEBUG - 2020-04-09 15:29:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:29:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:29:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-09 19:29:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-09 19:29:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:29:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:29:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:29:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:29:47 --> Total execution time: 0.5692
DEBUG - 2020-04-09 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:29:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:29:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:29:48 --> Total execution time: 0.0889
DEBUG - 2020-04-09 15:32:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:32:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:32:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-09 19:32:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-09 19:32:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:32:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:32:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:32:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:32:08 --> Total execution time: 0.1267
DEBUG - 2020-04-09 15:32:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:32:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:32:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:32:08 --> Total execution time: 0.1022
DEBUG - 2020-04-09 15:32:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:32:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 19:32:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-09 19:32:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-09 19:32:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-09 19:32:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-09 19:32:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-09 19:32:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-09 19:32:17 --> Total execution time: 0.0744
DEBUG - 2020-04-09 15:32:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 15:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 15:32:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 15:32:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 15:32:17 --> Total execution time: 0.0732
DEBUG - 2020-04-09 18:47:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 18:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 18:47:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:47:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 18:47:33 --> No URI present. Default controller set.
DEBUG - 2020-04-09 18:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 18:47:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:47:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-09 18:47:33 --> Total execution time: 0.0939
DEBUG - 2020-04-09 18:47:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-09 18:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-09 18:47:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-09 18:47:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-09 18:47:33 --> Total execution time: 0.1981
