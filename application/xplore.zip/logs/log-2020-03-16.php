<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-16 08:18:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:18:27 --> No URI present. Default controller set.
DEBUG - 2020-03-16 08:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:18:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 08:18:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-16 08:18:28 --> Total execution time: 0.4833
DEBUG - 2020-03-16 08:18:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:18:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 08:18:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-16 08:18:28 --> Total execution time: 0.1338
DEBUG - 2020-03-16 08:18:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:18:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 08:18:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-16 08:18:29 --> Total execution time: 0.0411
DEBUG - 2020-03-16 08:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:18:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 08:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:18:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 13:18:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-16 13:18:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-16 13:18:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-16 13:18:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-16 13:18:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-16 13:18:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-16 13:18:36 --> Total execution time: 0.2730
DEBUG - 2020-03-16 08:18:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:18:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 08:18:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-16 08:18:37 --> Total execution time: 0.0478
DEBUG - 2020-03-16 08:18:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:18:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 13:18:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-16 13:18:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-16 13:18:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-16 13:18:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-16 13:18:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-16 13:18:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-16 13:18:42 --> Total execution time: 0.3766
DEBUG - 2020-03-16 08:18:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:18:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 08:18:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-16 08:18:42 --> Total execution time: 0.0411
DEBUG - 2020-03-16 08:18:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:18:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 08:18:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:18:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 13:18:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-16 13:18:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
DEBUG - 2020-03-16 08:31:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:31:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 13:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-16 13:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/index.php
DEBUG - 2020-03-16 13:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-16 13:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-16 13:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-16 13:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-16 13:31:25 --> Total execution time: 0.1010
DEBUG - 2020-03-16 08:31:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:31:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 08:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-16 08:31:25 --> Total execution time: 0.0425
DEBUG - 2020-03-16 08:31:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:31:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 08:31:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-16 08:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-16 08:31:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-16 13:31:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/models/Library_model.php
DEBUG - 2020-03-16 13:31:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/library/views/library-view.php
