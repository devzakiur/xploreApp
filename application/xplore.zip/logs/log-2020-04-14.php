<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-04-14 16:16:47 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:16:47 --> No URI present. Default controller set.
DEBUG - 2020-04-14 16:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:16:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:16:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-14 16:16:47 --> Total execution time: 0.2291
DEBUG - 2020-04-14 16:16:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:16:48 --> No URI present. Default controller set.
DEBUG - 2020-04-14 16:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:16:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:16:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:16:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-04-14 16:16:48 --> Total execution time: 0.0963
DEBUG - 2020-04-14 16:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:16:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:16:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:16:48 --> Total execution time: 0.1567
DEBUG - 2020-04-14 16:16:48 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:16:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:16:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:16:48 --> Total execution time: 0.0816
DEBUG - 2020-04-14 16:16:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:16:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:16:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:16:49 --> Total execution time: 0.0558
DEBUG - 2020-04-14 16:16:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:16:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:16:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:16:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:16:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-14 20:16:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-14 20:16:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:16:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:16:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:16:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:16:53 --> Total execution time: 0.1444
DEBUG - 2020-04-14 16:16:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:16:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:16:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:16:53 --> Total execution time: 0.0623
DEBUG - 2020-04-14 16:16:57 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:16:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:16:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-04-14 20:16:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:16:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:16:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:16:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:16:57 --> Total execution time: 0.1307
DEBUG - 2020-04-14 16:16:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:16:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:16:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:16:58 --> Total execution time: 0.0803
DEBUG - 2020-04-14 16:17:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:17:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:17:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:17:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:17:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:17:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:17:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:17:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:17:00 --> Total execution time: 0.0744
DEBUG - 2020-04-14 16:17:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:17:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:17:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:17:00 --> Total execution time: 0.0802
DEBUG - 2020-04-14 16:17:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:17:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:17:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:17:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:17:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-14 20:17:01 --> Severity: Notice --> Undefined property: News::$category D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 60
ERROR - 2020-04-14 20:17:01 --> Severity: error --> Exception: Call to a member function get() on null D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 60
DEBUG - 2020-04-14 16:17:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:17:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:17:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Module_model.php
DEBUG - 2020-04-14 20:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/views/module.php
DEBUG - 2020-04-14 20:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:17:11 --> Total execution time: 0.1133
DEBUG - 2020-04-14 16:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:17:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:17:11 --> Total execution time: 0.0709
DEBUG - 2020-04-14 16:17:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:17:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:17:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Module_model.php
DEBUG - 2020-04-14 20:17:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/views/icon-list.php
DEBUG - 2020-04-14 20:17:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:17:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:17:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:17:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:17:13 --> Total execution time: 0.1477
DEBUG - 2020-04-14 16:17:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:17:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:17:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:17:13 --> Total execution time: 0.0652
DEBUG - 2020-04-14 16:18:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:18:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/models/Module_model.php
DEBUG - 2020-04-14 20:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/administrator/views/module.php
DEBUG - 2020-04-14 20:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:18:41 --> Total execution time: 0.0824
DEBUG - 2020-04-14 16:18:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:18:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:18:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:18:41 --> Total execution time: 0.0810
DEBUG - 2020-04-14 16:18:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:18:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:18:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:18:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:18:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:18:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:18:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:18:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:18:55 --> Total execution time: 0.0746
DEBUG - 2020-04-14 16:18:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:18:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:18:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:18:55 --> Total execution time: 0.0841
DEBUG - 2020-04-14 16:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:18:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:18:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:18:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:18:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-14 20:18:56 --> Severity: Notice --> Undefined property: News::$category D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 60
ERROR - 2020-04-14 20:18:56 --> Severity: error --> Exception: Call to a member function get() on null D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 60
DEBUG - 2020-04-14 16:19:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:19:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:19:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-14 20:19:04 --> Severity: Notice --> Undefined property: News::$category D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 41
ERROR - 2020-04-14 20:19:04 --> Severity: error --> Exception: Call to a member function insert() on null D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 41
DEBUG - 2020-04-14 16:19:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:19:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:19:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-14 20:19:06 --> Severity: Notice --> Undefined property: News::$category D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 41
ERROR - 2020-04-14 20:19:06 --> Severity: error --> Exception: Call to a member function insert() on null D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 41
DEBUG - 2020-04-14 16:19:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:19:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:19:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:19:08 --> Total execution time: 0.0912
DEBUG - 2020-04-14 16:19:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:19:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:19:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-14 20:19:19 --> Severity: Notice --> Undefined property: News::$category D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 41
ERROR - 2020-04-14 20:19:19 --> Severity: error --> Exception: Call to a member function insert() on null D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php 41
DEBUG - 2020-04-14 16:19:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:19:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:19:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 16:19:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:19:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:19:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:19:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:19:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-14 20:19:37 --> Severity: Notice --> Undefined index: subject_show D:\shipan7.2\htdocs\xplore\application\modules\news\views\category-view.php 10
ERROR - 2020-04-14 20:19:37 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\news\views\category-view.php 21
ERROR - 2020-04-14 20:19:37 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\news\views\category-view.php 21
DEBUG - 2020-04-14 20:19:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:20:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:20:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:20:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:20:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:20:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:20:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:20:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:20:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:20:33 --> Total execution time: 0.0825
DEBUG - 2020-04-14 16:20:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:20:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:20:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:20:33 --> Total execution time: 0.0934
DEBUG - 2020-04-14 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:20:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:20:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:20:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-14 20:20:34 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\news\views\category-view.php 11
ERROR - 2020-04-14 20:20:34 --> Severity: Notice --> Undefined index: status D:\shipan7.2\htdocs\xplore\application\modules\news\views\category-view.php 11
DEBUG - 2020-04-14 20:20:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:21:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:21:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:21:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:21:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:21:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:21:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:21:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:21:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:21:02 --> Total execution time: 0.0772
DEBUG - 2020-04-14 16:21:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:21:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:21:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:21:03 --> Total execution time: 0.0960
DEBUG - 2020-04-14 16:21:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:21:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:21:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:21:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:21:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:21:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:24:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:24:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:24:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-14 20:24:06 --> Severity: error --> Exception: Too few arguments to function MY_Model::duplicate_check(), 2 passed in D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php on line 41 and at least 3 expected D:\shipan7.2\htdocs\xplore\application\core\MY_Model.php 52
DEBUG - 2020-04-14 16:24:08 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:24:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:24:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-14 20:24:08 --> Severity: error --> Exception: Too few arguments to function MY_Model::duplicate_check(), 2 passed in D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php on line 41 and at least 3 expected D:\shipan7.2\htdocs\xplore\application\core\MY_Model.php 52
DEBUG - 2020-04-14 16:24:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:24:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:24:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:24:10 --> Total execution time: 0.2142
DEBUG - 2020-04-14 16:24:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:24:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:24:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
ERROR - 2020-04-14 20:24:14 --> Severity: error --> Exception: Too few arguments to function MY_Model::duplicate_check(), 2 passed in D:\shipan7.2\htdocs\xplore\application\modules\news\controllers\News.php on line 41 and at least 3 expected D:\shipan7.2\htdocs\xplore\application\core\MY_Model.php 52
DEBUG - 2020-04-14 16:24:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:24:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:24:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 16:24:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:24:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:24:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:24:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:24:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:24:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:24:49 --> Total execution time: 0.0775
DEBUG - 2020-04-14 16:24:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:24:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:24:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:24:49 --> Total execution time: 0.0780
DEBUG - 2020-04-14 16:24:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:24:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:24:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:24:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:24:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:24:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:30:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:30:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:30:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:30:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:30:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:30:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:30:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:30:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:30:29 --> Total execution time: 0.1125
DEBUG - 2020-04-14 16:30:30 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:30:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:30:30 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:30:30 --> Total execution time: 0.0762
DEBUG - 2020-04-14 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:30:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:30:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:30:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:30:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:30:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:30:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/index.php
DEBUG - 2020-04-14 20:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:30:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:30:32 --> Total execution time: 0.1262
DEBUG - 2020-04-14 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:30:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:30:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:30:33 --> Total execution time: 0.1238
DEBUG - 2020-04-14 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:30:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:30:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-04-14 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:31:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:31:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:31:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:31:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:31:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:31:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:31:06 --> Total execution time: 0.0768
DEBUG - 2020-04-14 16:31:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:31:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:31:06 --> Total execution time: 0.0987
DEBUG - 2020-04-14 16:31:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:31:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:31:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:31:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:31:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:31:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:31:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:31:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:31:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:31:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:31:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:31:09 --> Total execution time: 0.0781
DEBUG - 2020-04-14 16:31:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:31:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:31:09 --> Total execution time: 0.0826
DEBUG - 2020-04-14 16:31:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:31:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:31:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:31:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:31:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:31:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/index.php
DEBUG - 2020-04-14 20:31:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:31:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:31:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:31:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:31:13 --> Total execution time: 0.0713
DEBUG - 2020-04-14 16:31:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:31:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:31:14 --> Total execution time: 0.0787
DEBUG - 2020-04-14 16:31:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:31:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:31:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:31:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-04-14 16:32:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:32:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:32:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:32:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:32:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:32:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:32:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:32:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:32:59 --> Total execution time: 0.1019
DEBUG - 2020-04-14 16:32:59 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:32:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:32:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:32:59 --> Total execution time: 0.0786
DEBUG - 2020-04-14 16:33:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:33:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:33:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:33:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:33:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:33:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:33:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:33:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:33:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:33:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:33:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:33:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:33:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:33:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:33:01 --> Total execution time: 0.0927
DEBUG - 2020-04-14 16:33:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:33:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:33:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:33:02 --> Total execution time: 0.0866
DEBUG - 2020-04-14 16:33:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:33:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:33:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:33:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:33:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:33:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 16:33:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:33:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:33:06 --> Total execution time: 0.0762
DEBUG - 2020-04-14 16:33:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:33:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:33:06 --> Total execution time: 0.0646
DEBUG - 2020-04-14 16:33:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:33:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:33:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:33:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:33:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:33:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:34:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:34:04 --> Total execution time: 0.0712
DEBUG - 2020-04-14 16:34:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:34:04 --> Total execution time: 0.0759
DEBUG - 2020-04-14 16:34:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:34:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:34:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:34:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:34:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:34:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:34:06 --> Total execution time: 0.0725
DEBUG - 2020-04-14 16:34:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:34:07 --> Total execution time: 0.1017
DEBUG - 2020-04-14 16:34:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:34:09 --> Total execution time: 0.0723
DEBUG - 2020-04-14 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:34:09 --> Total execution time: 0.0703
DEBUG - 2020-04-14 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:34:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:34:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:34:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:34:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:34:12 --> Total execution time: 0.0737
DEBUG - 2020-04-14 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:34:12 --> Total execution time: 0.0907
DEBUG - 2020-04-14 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:34:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 16:34:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:34:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:34:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:34:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:34:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:34:14 --> Total execution time: 0.0805
DEBUG - 2020-04-14 16:34:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:34:15 --> Total execution time: 0.0739
DEBUG - 2020-04-14 16:34:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:34:18 --> Total execution time: 0.0753
DEBUG - 2020-04-14 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:34:18 --> Total execution time: 0.0998
DEBUG - 2020-04-14 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:34:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 16:34:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:34:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:34:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:34:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:34:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:34:23 --> Total execution time: 0.0796
DEBUG - 2020-04-14 16:34:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:34:24 --> Total execution time: 0.0825
DEBUG - 2020-04-14 16:34:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:34:27 --> Total execution time: 0.0736
DEBUG - 2020-04-14 16:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:34:27 --> Total execution time: 0.0756
DEBUG - 2020-04-14 16:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:34:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 16:34:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:34:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:34:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:34:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:34:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:34:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:34:37 --> Total execution time: 0.0749
DEBUG - 2020-04-14 16:34:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:34:37 --> Total execution time: 0.0784
DEBUG - 2020-04-14 16:34:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:34:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:34:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:34:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:34:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:35:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:35:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:35:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:35:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:35:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:35:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:35:05 --> Total execution time: 0.0741
DEBUG - 2020-04-14 16:35:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:35:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:35:05 --> Total execution time: 0.0795
DEBUG - 2020-04-14 16:35:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:35:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:35:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:35:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:35:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:35:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:35:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:35:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:35:12 --> Total execution time: 0.0751
DEBUG - 2020-04-14 16:35:12 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:35:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:35:13 --> Total execution time: 0.0750
DEBUG - 2020-04-14 16:35:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:35:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:35:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:35:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 16:35:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:35:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:35:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:35:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:35:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:35:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:35:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:35:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:35:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:35:18 --> Total execution time: 0.0784
DEBUG - 2020-04-14 16:35:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:35:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:35:18 --> Total execution time: 0.1004
DEBUG - 2020-04-14 16:35:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:35:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:35:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:35:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:35:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:35:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:35:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:35:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:35:21 --> Total execution time: 0.0776
DEBUG - 2020-04-14 16:35:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:35:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:35:21 --> Total execution time: 0.0834
DEBUG - 2020-04-14 16:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:35:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:35:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:35:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:35:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:35:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:35:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:35:40 --> Total execution time: 0.1195
DEBUG - 2020-04-14 16:35:40 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:35:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:35:40 --> Total execution time: 0.0689
DEBUG - 2020-04-14 16:35:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:35:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:35:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:35:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:35:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:42:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:42:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:42:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 16:42:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:42:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:42:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:42:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:42:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:42:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:42:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:42:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:42:31 --> Total execution time: 0.0799
DEBUG - 2020-04-14 16:42:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:42:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:42:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:42:31 --> Total execution time: 0.0874
DEBUG - 2020-04-14 16:42:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:42:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:42:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:42:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:42:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:42:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:42:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:42:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:42:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 20:42:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:42:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:42:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:42:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:42:35 --> Total execution time: 0.0774
DEBUG - 2020-04-14 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:42:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:42:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:42:36 --> Total execution time: 0.0682
DEBUG - 2020-04-14 16:42:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:42:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:42:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:42:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:42:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 20:42:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 16:52:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:52:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:52:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:52:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-04-14 20:52:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:52:19 --> Total execution time: 0.1650
DEBUG - 2020-04-14 16:52:19 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:52:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:52:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:52:19 --> Total execution time: 0.0724
DEBUG - 2020-04-14 16:52:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:52:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:52:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:52:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-04-14 16:52:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:52:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:52:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:52:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-04-14 20:52:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:52:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:52:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:52:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:52:21 --> Total execution time: 0.0698
DEBUG - 2020-04-14 16:52:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:52:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:52:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:52:21 --> Total execution time: 0.0881
DEBUG - 2020-04-14 16:52:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:52:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:52:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:52:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:52:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:52:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-04-14 16:52:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:52:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:52:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 16:52:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:52:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:52:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:52:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:52:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:52:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-04-14 16:53:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:53:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:53:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:53:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-04-14 20:53:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:53:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:53:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:53:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:53:32 --> Total execution time: 0.0760
DEBUG - 2020-04-14 16:53:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:53:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:53:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:53:32 --> Total execution time: 0.0699
DEBUG - 2020-04-14 16:53:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:53:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:53:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:53:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:53:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:53:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-04-14 16:54:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:54:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-14 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/index.php
DEBUG - 2020-04-14 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:54:22 --> Total execution time: 0.0871
DEBUG - 2020-04-14 16:54:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:54:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:54:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:54:22 --> Total execution time: 0.0650
DEBUG - 2020-04-14 16:54:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:54:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:54:23 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:54:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:54:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-14 20:54:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-view.php
DEBUG - 2020-04-14 16:54:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:54:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:54:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-14 20:54:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-04-14 20:54:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:54:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:54:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:54:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:54:27 --> Total execution time: 0.0885
DEBUG - 2020-04-14 16:54:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:54:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:54:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:54:27 --> Total execution time: 0.0736
DEBUG - 2020-04-14 16:54:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:54:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:54:28 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:54:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:54:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-14 20:54:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-04-14 16:56:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:56:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:56:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:56:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-04-14 20:56:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:56:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:56:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:56:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:56:31 --> Total execution time: 0.0749
DEBUG - 2020-04-14 16:56:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:56:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:56:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:56:31 --> Total execution time: 0.0700
DEBUG - 2020-04-14 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:56:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:56:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:56:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:56:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-04-14 16:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:56:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:56:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:56:55 --> Total execution time: 0.1548
DEBUG - 2020-04-14 16:56:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:56:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:56:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:56:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-04-14 20:56:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:56:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:56:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:56:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:56:58 --> Total execution time: 0.1047
DEBUG - 2020-04-14 16:56:58 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:56:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:56:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:56:58 --> Total execution time: 0.0788
DEBUG - 2020-04-14 16:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:57:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:57:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:57:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 20:57:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 16:57:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:57:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:57:00 --> Total execution time: 0.1782
DEBUG - 2020-04-14 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:57:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:57:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:57:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-04-14 20:57:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:57:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:57:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:57:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:57:05 --> Total execution time: 0.0833
DEBUG - 2020-04-14 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:57:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:57:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:57:05 --> Total execution time: 0.0875
DEBUG - 2020-04-14 16:57:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:57:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:57:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:57:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:57:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:57:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:57:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 16:57:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:57:06 --> Total execution time: 0.1609
DEBUG - 2020-04-14 16:57:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:57:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:57:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:57:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-04-14 20:57:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:57:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:57:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:57:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:57:36 --> Total execution time: 0.1119
DEBUG - 2020-04-14 16:57:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:57:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:57:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:57:37 --> Total execution time: 0.0824
DEBUG - 2020-04-14 16:57:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:57:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:57:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:57:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:57:38 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 20:57:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 16:57:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:57:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:57:38 --> Total execution time: 0.1590
DEBUG - 2020-04-14 16:58:35 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:58:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:58:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:58:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-04-14 20:58:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 20:58:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 20:58:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 20:58:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 20:58:36 --> Total execution time: 0.0969
DEBUG - 2020-04-14 16:58:36 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:58:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:58:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:58:36 --> Total execution time: 0.0992
DEBUG - 2020-04-14 16:58:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:58:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:58:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:58:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 16:58:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 16:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 16:58:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 20:58:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-04-14 20:58:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-04-14 16:58:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 16:58:37 --> Total execution time: 0.1939
DEBUG - 2020-04-14 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/index.php
DEBUG - 2020-04-14 21:00:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 21:00:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 21:00:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 21:00:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 21:00:04 --> Total execution time: 0.0777
DEBUG - 2020-04-14 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 17:00:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 17:00:04 --> Total execution time: 0.0862
DEBUG - 2020-04-14 17:00:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 17:00:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-04-14 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-14 21:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-04-14 21:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 21:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 21:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 21:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 21:00:06 --> Total execution time: 0.0692
DEBUG - 2020-04-14 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 17:00:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 17:00:06 --> Total execution time: 0.0790
DEBUG - 2020-04-14 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 17:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-14 21:00:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-04-14 17:00:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-14 17:00:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:09 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 17:00:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-14 21:00:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-04-14 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-14 21:00:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-04-14 21:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 21:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 21:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 21:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 21:00:14 --> Total execution time: 0.1051
DEBUG - 2020-04-14 17:00:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 17:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 17:00:14 --> Total execution time: 0.0794
DEBUG - 2020-04-14 17:00:14 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-04-14 21:00:14 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-04-14 17:00:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-14 21:00:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/index.php
DEBUG - 2020-04-14 21:00:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 21:00:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 21:00:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 21:00:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 21:00:17 --> Total execution time: 0.0745
DEBUG - 2020-04-14 17:00:17 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 17:00:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 17:00:18 --> Total execution time: 0.0995
DEBUG - 2020-04-14 17:00:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 17:00:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-14 21:00:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-view.php
DEBUG - 2020-04-14 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-14 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 17:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 17:00:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 17:00:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 21:00:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-04-14 21:00:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-view.php
DEBUG - 2020-04-14 18:21:55 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:21:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-14 22:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-14 22:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 22:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 22:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 22:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 22:21:56 --> Total execution time: 0.4220
DEBUG - 2020-04-14 18:21:56 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:21:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:21:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 18:21:56 --> Total execution time: 0.0934
DEBUG - 2020-04-14 18:22:02 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:22:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:22:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 22:22:02 --> Total execution time: 0.0725
DEBUG - 2020-04-14 18:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:22:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:22:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-14 22:22:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-14 22:22:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 22:22:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 22:22:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 22:22:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 22:22:04 --> Total execution time: 0.0711
DEBUG - 2020-04-14 18:22:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:22:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:22:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 18:22:04 --> Total execution time: 0.0770
DEBUG - 2020-04-14 18:22:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:22:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:22:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 22:22:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/news-category.php
DEBUG - 2020-04-14 22:22:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 22:22:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 22:22:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 22:22:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 22:22:06 --> Total execution time: 0.0924
DEBUG - 2020-04-14 18:22:06 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:22:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:22:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 18:22:06 --> Total execution time: 0.0784
DEBUG - 2020-04-14 18:22:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:22:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:22:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:22:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:22:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/models/Newsmodel.php
DEBUG - 2020-04-14 22:22:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/news/views/category-view.php
DEBUG - 2020-04-14 18:24:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:24:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:24:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-14 22:24:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-14 22:24:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 22:24:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 22:24:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 22:24:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 22:24:15 --> Total execution time: 0.0858
DEBUG - 2020-04-14 18:24:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:24:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:24:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 18:24:15 --> Total execution time: 0.0771
DEBUG - 2020-04-14 18:25:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/index.php
DEBUG - 2020-04-14 22:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 22:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 22:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 22:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 22:25:00 --> Total execution time: 0.0955
DEBUG - 2020-04-14 18:25:00 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:25:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 18:25:00 --> Total execution time: 0.0973
DEBUG - 2020-04-14 18:25:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-04-14 18:25:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-14 22:25:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-14 22:25:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 22:25:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 22:25:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 22:25:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 22:25:03 --> Total execution time: 0.2162
DEBUG - 2020-04-14 18:25:03 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:25:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 18:25:04 --> Total execution time: 0.0703
DEBUG - 2020-04-14 18:25:04 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:25:05 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-14 18:25:11 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:13 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:15 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:16 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:18 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:21 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-14 18:25:24 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:26 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:27 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:29 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:31 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:33 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:34 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:37 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:39 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:41 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:43 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:44 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:46 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:49 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-history-details.php
DEBUG - 2020-04-14 18:25:52 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-14 22:25:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-14 22:25:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 22:25:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 22:25:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 22:25:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 22:25:53 --> Total execution time: 0.1097
DEBUG - 2020-04-14 18:25:53 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:25:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 18:25:53 --> Total execution time: 0.0829
DEBUG - 2020-04-14 18:25:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:25:54 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:25:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:25:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:25:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-04-14 18:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:26:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:26:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-04-14 22:26:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-04-14 22:26:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 22:26:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 22:26:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 22:26:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 22:26:01 --> Total execution time: 0.0909
DEBUG - 2020-04-14 18:26:01 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:26:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:26:02 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 18:26:02 --> Total execution time: 0.0920
DEBUG - 2020-04-14 18:26:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:26:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:26:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/index.php
DEBUG - 2020-04-14 22:26:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 22:26:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 22:26:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 22:26:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 22:26:07 --> Total execution time: 0.0734
DEBUG - 2020-04-14 18:26:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:26:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:26:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 18:26:07 --> Total execution time: 0.0728
DEBUG - 2020-04-14 18:26:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:26:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:26:07 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:26:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:26:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-04-14 18:38:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:38:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:38:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-04-14 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-04-14 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-04-14 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-04-14 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-04-14 22:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-04-14 22:38:50 --> Total execution time: 0.1240
DEBUG - 2020-04-14 18:38:50 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:38:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:38:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-04-14 18:38:50 --> Total execution time: 0.0932
DEBUG - 2020-04-14 18:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:38:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 18:38:51 --> UTF-8 Support Enabled
DEBUG - 2020-04-14 18:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-14 18:38:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-04-14 22:38:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-04-14 22:38:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
