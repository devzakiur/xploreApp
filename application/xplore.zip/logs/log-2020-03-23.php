<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-03-23 06:19:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:19:53 --> No URI present. Default controller set.
DEBUG - 2020-03-23 06:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:19:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 06:19:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\login.php
DEBUG - 2020-03-23 06:19:53 --> Total execution time: 0.1174
DEBUG - 2020-03-23 06:19:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:19:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 06:19:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 06:19:53 --> Total execution time: 0.0403
DEBUG - 2020-03-23 06:19:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:19:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 06:19:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 06:19:53 --> Total execution time: 0.0368
DEBUG - 2020-03-23 06:19:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:19:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 06:19:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:19:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:19:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-23 11:19:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-23 11:19:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 11:19:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 11:19:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 11:19:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 11:19:57 --> Total execution time: 0.2159
DEBUG - 2020-03-23 06:19:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:19:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 06:19:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 06:19:58 --> Total execution time: 0.0391
DEBUG - 2020-03-23 06:20:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:20:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/content/views/index.php
DEBUG - 2020-03-23 11:20:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 11:20:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 11:20:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 11:20:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 11:20:00 --> Total execution time: 0.0802
DEBUG - 2020-03-23 06:20:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 06:20:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 06:20:00 --> Total execution time: 0.0433
DEBUG - 2020-03-23 06:20:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:20:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 11:20:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-23 11:20:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 11:20:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 11:20:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 11:20:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 11:20:04 --> Total execution time: 0.0621
DEBUG - 2020-03-23 06:20:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 06:20:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 06:20:04 --> Total execution time: 0.0413
DEBUG - 2020-03-23 06:20:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:20:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 11:20:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-23 06:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 06:20:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 11:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-23 11:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 11:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 11:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 11:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 11:20:12 --> Total execution time: 0.0594
DEBUG - 2020-03-23 06:20:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 06:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 06:20:12 --> Total execution time: 0.0417
DEBUG - 2020-03-23 06:20:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 11:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-23 06:20:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:20:17 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 06:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:20:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 11:20:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-23 11:20:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 11:20:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 11:20:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 11:20:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 11:20:18 --> Total execution time: 0.0844
DEBUG - 2020-03-23 06:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 06:20:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 06:20:18 --> Total execution time: 0.0396
DEBUG - 2020-03-23 06:20:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:20:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 11:20:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-23 06:20:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:20:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 11:20:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-23 11:20:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 11:20:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 11:20:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 11:20:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 11:20:44 --> Total execution time: 0.0610
DEBUG - 2020-03-23 06:20:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 06:20:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 06:20:44 --> Total execution time: 0.0382
DEBUG - 2020-03-23 06:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:20:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:20:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 11:20:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-23 06:23:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:23:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:23:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 11:23:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/index.php
DEBUG - 2020-03-23 11:23:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 11:23:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 11:23:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 11:23:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 11:23:51 --> Total execution time: 0.0592
DEBUG - 2020-03-23 06:23:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:23:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 06:23:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 06:23:51 --> Total execution time: 0.0439
DEBUG - 2020-03-23 06:23:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 06:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 06:23:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 11:23:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/models/Users_model.php
DEBUG - 2020-03-23 11:23:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/users/views/users-view.php
DEBUG - 2020-03-23 07:08:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:08:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-23 12:08:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/bcs.php
DEBUG - 2020-03-23 12:08:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/index.php
DEBUG - 2020-03-23 12:08:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:08:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:08:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:08:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:08:03 --> Total execution time: 0.4974
DEBUG - 2020-03-23 07:08:03 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:08:03 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:08:03 --> Total execution time: 0.0398
DEBUG - 2020-03-23 07:08:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:08:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:08:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-23 12:08:04 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-view.php
DEBUG - 2020-03-23 07:08:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:08:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/models/Question_model.php
DEBUG - 2020-03-23 12:08:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/question/views/question-details.php
DEBUG - 2020-03-23 07:08:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:08:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/models/Batch_model.php
DEBUG - 2020-03-23 12:08:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/views/index.php
DEBUG - 2020-03-23 12:08:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:08:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:08:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:08:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:08:20 --> Total execution time: 0.0954
DEBUG - 2020-03-23 07:08:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:08:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:08:20 --> Total execution time: 0.0406
DEBUG - 2020-03-23 07:08:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:08:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/models/Batch_model.php
DEBUG - 2020-03-23 12:08:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/views/batch-view.php
DEBUG - 2020-03-23 07:08:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:08:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:08:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:08:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:08:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:08:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:08:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:08:21 --> Total execution time: 0.1127
DEBUG - 2020-03-23 07:08:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:08:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:08:21 --> Total execution time: 0.0365
DEBUG - 2020-03-23 07:08:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:08:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:08:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:08:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:08:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:08:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:08:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-03-23 12:08:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:08:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:08:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:08:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:08:24 --> Total execution time: 0.1005
DEBUG - 2020-03-23 07:08:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:08:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:08:25 --> Total execution time: 0.0371
DEBUG - 2020-03-23 07:08:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:08:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:08:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:08:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:09:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/index.php
DEBUG - 2020-03-23 12:09:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:09:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:09:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:09:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:09:32 --> Total execution time: 0.0815
DEBUG - 2020-03-23 07:09:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:09:33 --> Total execution time: 0.0410
DEBUG - 2020-03-23 07:09:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-03-23 07:09:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/models/Batch_model.php
DEBUG - 2020-03-23 12:09:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/views/index.php
DEBUG - 2020-03-23 12:09:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:09:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:09:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:09:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:09:34 --> Total execution time: 0.0557
DEBUG - 2020-03-23 07:09:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:09:34 --> Total execution time: 0.0516
DEBUG - 2020-03-23 07:09:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/models/Batch_model.php
DEBUG - 2020-03-23 12:09:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/views/batch-view.php
DEBUG - 2020-03-23 07:09:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:09:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:09:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:09:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:09:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:09:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:09:35 --> Total execution time: 0.0576
DEBUG - 2020-03-23 07:09:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:09:35 --> Total execution time: 0.0381
DEBUG - 2020-03-23 07:09:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:09:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:09:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/models/Batch_model.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/views/index.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:09:37 --> Total execution time: 0.0589
DEBUG - 2020-03-23 07:09:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:09:37 --> Total execution time: 0.0375
DEBUG - 2020-03-23 07:09:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/models/Batch_model.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/batch/views/batch-view.php
DEBUG - 2020-03-23 07:09:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/index.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:09:37 --> Total execution time: 0.0573
DEBUG - 2020-03-23 07:09:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:09:37 --> Total execution time: 0.0395
DEBUG - 2020-03-23 07:09:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-03-23 07:09:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-03-23 07:09:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:09:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:09:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:09:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:09:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:09:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:09:45 --> Total execution time: 0.0605
DEBUG - 2020-03-23 07:09:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:09:45 --> Total execution time: 0.0374
DEBUG - 2020-03-23 07:09:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:09:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:09:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:09:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:09:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:09:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:09:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:09:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:09:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:09:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:09:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:05 --> Total execution time: 0.0637
DEBUG - 2020-03-23 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:05 --> Total execution time: 0.0387
DEBUG - 2020-03-23 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:10:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:16 --> Total execution time: 0.0619
DEBUG - 2020-03-23 07:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:16 --> Total execution time: 0.0382
DEBUG - 2020-03-23 07:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:18 --> Total execution time: 0.0593
DEBUG - 2020-03-23 07:10:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:18 --> Total execution time: 0.0383
DEBUG - 2020-03-23 07:10:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:20 --> Total execution time: 0.0570
DEBUG - 2020-03-23 07:10:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:20 --> Total execution time: 0.0368
DEBUG - 2020-03-23 07:10:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:22 --> Total execution time: 0.0589
DEBUG - 2020-03-23 07:10:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:22 --> Total execution time: 0.0383
DEBUG - 2020-03-23 07:10:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-03-23 12:10:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:25 --> Total execution time: 0.0584
DEBUG - 2020-03-23 07:10:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:25 --> Total execution time: 0.1780
DEBUG - 2020-03-23 07:10:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:10:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/index.php
DEBUG - 2020-03-23 12:10:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:33 --> Total execution time: 0.0566
DEBUG - 2020-03-23 07:10:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:33 --> Total execution time: 0.0422
DEBUG - 2020-03-23 07:10:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/category/views/category-view.php
DEBUG - 2020-03-23 07:10:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:34 --> Total execution time: 0.0539
DEBUG - 2020-03-23 07:10:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:34 --> Total execution time: 0.0373
DEBUG - 2020-03-23 07:10:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:36 --> Total execution time: 0.0580
DEBUG - 2020-03-23 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:36 --> Total execution time: 0.0382
DEBUG - 2020-03-23 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:36 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:37 --> Total execution time: 0.0574
DEBUG - 2020-03-23 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:37 --> Total execution time: 0.0397
DEBUG - 2020-03-23 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:39 --> Total execution time: 0.0567
DEBUG - 2020-03-23 07:10:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:39 --> Total execution time: 0.0366
DEBUG - 2020-03-23 07:10:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:40 --> Total execution time: 0.0560
DEBUG - 2020-03-23 07:10:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:40 --> Total execution time: 0.0376
DEBUG - 2020-03-23 07:10:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:41 --> Total execution time: 0.0577
DEBUG - 2020-03-23 07:10:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:41 --> Total execution time: 0.0393
DEBUG - 2020-03-23 07:10:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:10:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:50 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:53 --> Total execution time: 0.0470
DEBUG - 2020-03-23 07:10:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:10:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:10:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:10:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:10:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:10:58 --> Total execution time: 0.0621
DEBUG - 2020-03-23 07:10:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:58 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:58 --> Total execution time: 0.0473
DEBUG - 2020-03-23 07:10:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:10:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:10:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:10:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:10:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:10:59 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:10:59 --> Total execution time: 0.1854
DEBUG - 2020-03-23 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:11:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:11:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:11:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:11:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:11:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:11:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:11:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:11:46 --> Total execution time: 0.0645
DEBUG - 2020-03-23 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:11:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:11:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:11:46 --> Total execution time: 0.0400
DEBUG - 2020-03-23 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:11:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:11:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:11:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:11:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:11:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:11:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:11:49 --> Total execution time: 0.0499
DEBUG - 2020-03-23 07:11:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:11:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:11:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:11:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:11:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:11:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:11:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:11:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:11:51 --> Total execution time: 0.0681
DEBUG - 2020-03-23 07:11:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:11:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:11:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:11:51 --> Total execution time: 0.0510
DEBUG - 2020-03-23 07:11:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:11:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:11:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:11:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:11:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:11:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:11:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:11:52 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:11:52 --> Total execution time: 0.0844
DEBUG - 2020-03-23 07:13:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:13:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:13:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:13:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:13:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:13:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:13:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:13:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:13:00 --> Total execution time: 0.0572
DEBUG - 2020-03-23 07:13:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:13:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:13:00 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:13:00 --> Total execution time: 0.0403
DEBUG - 2020-03-23 07:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:13:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:13:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:13:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 12:13:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:13:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:13:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:13:01 --> Total execution time: 0.1117
DEBUG - 2020-03-23 07:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:13:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:13:39 --> Total execution time: 0.1018
DEBUG - 2020-03-23 07:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:13:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:13:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:13:39 --> Total execution time: 0.0476
DEBUG - 2020-03-23 07:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:13:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:13:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:13:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:13:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:13:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:13:40 --> Total execution time: 0.0920
DEBUG - 2020-03-23 07:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:14:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:14:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:14:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:14:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:14:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:14:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:14:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:14:42 --> Total execution time: 0.0635
DEBUG - 2020-03-23 07:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:14:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:14:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:14:42 --> Total execution time: 0.0435
DEBUG - 2020-03-23 07:14:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:14:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:14:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:14:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:14:43 --> Total execution time: 0.0524
DEBUG - 2020-03-23 07:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:14:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:14:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:14:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:14:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:15:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:15:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:15:08 --> Total execution time: 0.0655
DEBUG - 2020-03-23 07:15:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:15:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:15:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:15:08 --> Total execution time: 0.0433
DEBUG - 2020-03-23 07:15:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:15:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:15:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:15:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:15:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 12:15:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:15:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:15:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:15:09 --> Total execution time: 0.1051
DEBUG - 2020-03-23 07:16:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:16:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:16:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:16:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:16:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:16:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:16:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:16:13 --> Total execution time: 0.0823
DEBUG - 2020-03-23 07:16:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:16:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:16:13 --> Total execution time: 0.0418
DEBUG - 2020-03-23 07:16:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:16:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:16:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:16:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:16:13 --> Total execution time: 0.0505
DEBUG - 2020-03-23 07:16:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:16:31 --> Total execution time: 0.0694
DEBUG - 2020-03-23 07:16:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:16:31 --> Total execution time: 0.0459
DEBUG - 2020-03-23 07:16:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:16:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:16:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:16:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:16:31 --> Total execution time: 0.0596
DEBUG - 2020-03-23 07:16:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:16:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:16:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/index.php
DEBUG - 2020-03-23 12:16:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:16:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:16:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:16:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:16:46 --> Total execution time: 0.0966
DEBUG - 2020-03-23 07:16:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:16:46 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:16:46 --> Total execution time: 0.0427
DEBUG - 2020-03-23 07:16:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:16:47 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:47 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:16:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:16:47 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-view.php
DEBUG - 2020-03-23 07:16:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:16:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 07:16:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:16:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:16:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:16:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:16:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-view.php
DEBUG - 2020-03-23 07:17:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/index.php
DEBUG - 2020-03-23 12:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:17:11 --> Total execution time: 0.0662
DEBUG - 2020-03-23 07:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:17:11 --> Total execution time: 0.0419
DEBUG - 2020-03-23 07:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
ERROR - 2020-03-23 12:17:11 --> Query error: Unknown column 'S.section_id' in 'group statement' - Invalid query: SELECT `AS`.*, `S`.`name` as `section_name`, `S`.`status`
FROM `section` as `S`
LEFT JOIN `section_assign` as `AS` ON `AS`.`section_id`=`S`.`id`
LEFT JOIN `subject_assign` as `SUBA` ON `AS`.`subject_id`=`SUBA`.`subject_id`
LEFT JOIN `category` as `C` ON `SUBA`.`category_id`=`C`.`id`
GROUP BY `S`.`section_id`
DEBUG - 2020-03-23 07:17:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:17:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/index.php
DEBUG - 2020-03-23 12:17:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:17:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:17:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:17:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:17:21 --> Total execution time: 0.0506
DEBUG - 2020-03-23 07:17:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:17:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:17:21 --> Total execution time: 0.0414
DEBUG - 2020-03-23 07:17:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:17:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:17:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-view.php
DEBUG - 2020-03-23 07:17:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-03-23 12:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:17:32 --> Total execution time: 0.0879
DEBUG - 2020-03-23 07:17:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:17:32 --> Total execution time: 0.0397
DEBUG - 2020-03-23 07:17:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:17:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-03-23 07:17:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:38 --> Total execution time: 0.0462
DEBUG - 2020-03-23 07:17:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 07:17:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:17:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-03-23 07:17:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-03-23 12:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:17:45 --> Total execution time: 0.0617
DEBUG - 2020-03-23 07:17:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:17:45 --> Total execution time: 0.0409
DEBUG - 2020-03-23 07:17:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:17:45 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:17:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:17:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:17:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:17:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:17:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:17:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:18:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:18:05 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:18:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:18:08 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:08 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:18:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:18:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:18:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:18:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:18:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:18:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:18:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:18:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:18:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/index.php
DEBUG - 2020-03-23 12:18:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:18:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:18:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:18:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:18:23 --> Total execution time: 0.0613
DEBUG - 2020-03-23 07:18:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:18:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:18:23 --> Total execution time: 0.0429
DEBUG - 2020-03-23 07:18:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:18:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:18:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-view.php
DEBUG - 2020-03-23 07:18:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:18:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-03-23 12:18:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:18:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:18:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:18:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:18:28 --> Total execution time: 0.0618
DEBUG - 2020-03-23 07:18:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:18:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:18:28 --> Total execution time: 0.0484
DEBUG - 2020-03-23 07:18:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:18:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-03-23 07:18:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:31 --> Total execution time: 0.0444
DEBUG - 2020-03-23 07:18:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 07:18:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:18:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-03-23 07:18:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 07:18:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:18:38 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-03-23 07:18:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:18:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-03-23 12:18:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:18:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:18:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:18:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:18:43 --> Total execution time: 0.1509
DEBUG - 2020-03-23 07:18:43 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:18:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:18:43 --> Total execution time: 0.0401
DEBUG - 2020-03-23 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:18:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-03-23 07:18:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:18:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:54 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:18:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:18:54 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:18:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:18:54 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-03-23 07:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-03-23 12:19:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:19:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:19:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:19:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:19:01 --> Total execution time: 0.0697
DEBUG - 2020-03-23 07:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:19:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:19:01 --> Total execution time: 0.0397
DEBUG - 2020-03-23 07:19:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:01 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:19:04 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:04 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:04 --> Total execution time: 0.0365
DEBUG - 2020-03-23 07:19:05 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:05 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:05 --> Total execution time: 0.0458
DEBUG - 2020-03-23 07:19:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:19:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:19:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-03-23 12:19:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:19:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:19:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:19:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:19:10 --> Total execution time: 0.0614
DEBUG - 2020-03-23 07:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:19:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:19:10 --> Total execution time: 0.0385
DEBUG - 2020-03-23 07:19:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:19:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-03-23 07:19:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:14 --> Total execution time: 0.0456
DEBUG - 2020-03-23 07:19:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 07:19:18 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:18 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:19:18 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-03-23 07:19:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-03-23 12:19:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:19:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:19:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:19:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:19:19 --> Total execution time: 0.0596
DEBUG - 2020-03-23 07:19:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:19:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:19:19 --> Total execution time: 0.0402
DEBUG - 2020-03-23 07:19:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:19:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-03-23 07:19:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-03-23 12:19:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:19:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:19:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:19:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:19:21 --> Total execution time: 0.0619
DEBUG - 2020-03-23 07:19:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:19:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:19:21 --> Total execution time: 0.0388
DEBUG - 2020-03-23 07:19:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:19:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:23 --> Total execution time: 0.0350
DEBUG - 2020-03-23 07:19:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:25 --> Total execution time: 0.0446
DEBUG - 2020-03-23 07:19:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:27 --> Total execution time: 0.0439
DEBUG - 2020-03-23 07:19:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-03-23 12:19:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:19:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:19:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:19:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:19:32 --> Total execution time: 0.0594
DEBUG - 2020-03-23 07:19:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:19:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:19:32 --> Total execution time: 0.0497
DEBUG - 2020-03-23 07:19:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:19:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-03-23 07:19:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:19:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-03-23 12:19:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:19:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:19:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:19:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:19:33 --> Total execution time: 0.0600
DEBUG - 2020-03-23 07:19:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:19:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:19:33 --> Total execution time: 0.0416
DEBUG - 2020-03-23 07:19:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:19:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-03-23 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-03-23 12:19:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:19:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:19:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:19:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:19:42 --> Total execution time: 0.0627
DEBUG - 2020-03-23 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:19:42 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:19:42 --> Total execution time: 0.0397
DEBUG - 2020-03-23 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:42 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:43 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:43 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-03-23 07:19:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-03-23 12:19:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:19:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:19:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:19:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:19:44 --> Total execution time: 0.0616
DEBUG - 2020-03-23 07:19:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:19:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:19:44 --> Total execution time: 0.0378
DEBUG - 2020-03-23 07:19:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:19:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:19:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:19:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:19:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:19:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:19:58 --> Total execution time: 0.0448
DEBUG - 2020-03-23 07:20:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:20:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:20:01 --> Total execution time: 0.0578
DEBUG - 2020-03-23 07:20:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:20:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:20:06 --> Total execution time: 0.0443
DEBUG - 2020-03-23 07:20:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:20:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:20:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:20:09 --> Total execution time: 0.0457
DEBUG - 2020-03-23 07:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:20:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:20:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:20:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-03-23 12:20:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:20:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:20:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:20:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:20:11 --> Total execution time: 0.0773
DEBUG - 2020-03-23 07:20:11 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:20:11 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:20:11 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:20:11 --> Total execution time: 0.0453
DEBUG - 2020-03-23 07:20:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:20:12 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:20:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:20:12 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:20:12 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:20:12 --> Total execution time: 0.0944
DEBUG - 2020-03-23 07:20:14 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:20:14 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:20:14 --> Total execution time: 0.0395
DEBUG - 2020-03-23 07:20:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:20:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:20:16 --> Total execution time: 0.0489
DEBUG - 2020-03-23 07:26:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-03-23 12:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:26:20 --> Total execution time: 0.0999
DEBUG - 2020-03-23 07:26:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:26:20 --> Total execution time: 0.0435
DEBUG - 2020-03-23 07:26:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:26:20 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:26:20 --> Total execution time: 0.0992
DEBUG - 2020-03-23 07:26:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:23 --> Total execution time: 0.0516
DEBUG - 2020-03-23 07:26:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:25 --> Total execution time: 0.0498
DEBUG - 2020-03-23 07:26:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:29 --> Total execution time: 0.0453
DEBUG - 2020-03-23 07:26:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:35 --> Total execution time: 0.0469
DEBUG - 2020-03-23 07:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:26:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:26:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:26:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:40 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:26:41 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:41 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:26:41 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:26:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:26:56 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:26:56 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:26:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:26:56 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:27:01 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:27:01 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:27:01 --> Total execution time: 0.0498
DEBUG - 2020-03-23 07:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:28:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:28:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:28:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-03-23 12:28:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:28:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:28:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:28:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:28:32 --> Total execution time: 0.0844
DEBUG - 2020-03-23 07:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:28:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:28:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:28:32 --> Total execution time: 0.0485
DEBUG - 2020-03-23 07:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:28:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:28:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:28:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:28:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:28:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:28:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:28:32 --> Total execution time: 0.0926
DEBUG - 2020-03-23 07:28:37 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:28:37 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:28:37 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:28:37 --> Total execution time: 0.0527
DEBUG - 2020-03-23 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:30:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:30:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:30:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-03-23 12:30:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:30:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:30:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:30:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:30:09 --> Total execution time: 0.0607
DEBUG - 2020-03-23 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:30:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:30:09 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:30:09 --> Total execution time: 0.0523
DEBUG - 2020-03-23 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:30:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:30:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 12:30:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:30:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:30:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-03-23 07:30:10 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:30:10 --> Total execution time: 0.0540
DEBUG - 2020-03-23 07:31:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:31:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:31:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:31:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-03-23 12:31:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:31:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:31:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:31:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:31:24 --> Total execution time: 0.1318
DEBUG - 2020-03-23 07:31:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:31:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:31:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:31:24 --> Total execution time: 0.0401
DEBUG - 2020-03-23 07:31:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:31:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:31:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:31:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:31:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:31:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-03-23 07:31:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:31:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-03-23 12:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:31:25 --> Total execution time: 0.0632
DEBUG - 2020-03-23 07:31:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:31:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:31:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:31:25 --> Total execution time: 0.0443
DEBUG - 2020-03-23 07:31:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:31:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:31:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:31:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:31:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:31:28 --> Total execution time: 0.0367
DEBUG - 2020-03-23 07:31:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:31:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:31:30 --> Total execution time: 0.0457
DEBUG - 2020-03-23 07:31:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:31:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:31:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:31:34 --> Total execution time: 0.0499
DEBUG - 2020-03-23 07:32:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:32:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-03-23 12:32:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:32:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:32:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:32:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:32:31 --> Total execution time: 0.0651
DEBUG - 2020-03-23 07:32:31 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:31 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:32:31 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:32:31 --> Total execution time: 0.0426
DEBUG - 2020-03-23 07:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:32:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:32:32 --> Total execution time: 0.0428
DEBUG - 2020-03-23 07:32:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:32:32 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:32:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:35 --> Total execution time: 0.0457
DEBUG - 2020-03-23 07:32:36 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:36 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:36 --> Total execution time: 0.0468
DEBUG - 2020-03-23 07:32:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:32:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:32:39 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:32:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:32:44 --> Total execution time: 0.0588
DEBUG - 2020-03-23 07:32:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:32:44 --> Total execution time: 0.0450
DEBUG - 2020-03-23 07:32:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:32:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:32:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:32:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:32:44 --> Total execution time: 0.0539
DEBUG - 2020-03-23 07:32:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:32:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-03-23 12:32:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:32:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:32:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:32:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:32:48 --> Total execution time: 0.1152
DEBUG - 2020-03-23 07:32:48 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:48 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:32:48 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:32:48 --> Total execution time: 0.0431
DEBUG - 2020-03-23 07:32:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:32:49 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:32:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:32:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:32:51 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:32:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:32:53 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:32:53 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:32:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:32:53 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:33:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-03-23 12:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:33:06 --> Total execution time: 0.0645
DEBUG - 2020-03-23 07:33:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:33:06 --> Total execution time: 0.0420
DEBUG - 2020-03-23 07:33:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:33:06 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:06 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:33:06 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-03-23 07:33:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:33:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-03-23 12:33:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:33:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:33:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:33:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:33:07 --> Total execution time: 0.0514
DEBUG - 2020-03-23 07:33:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:33:07 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:33:07 --> Total execution time: 0.0477
DEBUG - 2020-03-23 07:33:07 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:07 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:33:08 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:33:09 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:09 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:09 --> Total execution time: 0.0743
DEBUG - 2020-03-23 07:33:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:10 --> Total execution time: 0.0458
DEBUG - 2020-03-23 07:33:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:33:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:33:13 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:33:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:33:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:33:15 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:33:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:16 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
ERROR - 2020-03-23 12:33:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\topic\controllers\Topic.php 223
ERROR - 2020-03-23 12:33:16 --> Could not find the language line "insert_batch() called with no data"
DEBUG - 2020-03-23 07:33:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:19 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
ERROR - 2020-03-23 12:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\topic\controllers\Topic.php 223
ERROR - 2020-03-23 12:33:19 --> Could not find the language line "insert_batch() called with no data"
DEBUG - 2020-03-23 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:33:21 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:33:21 --> Total execution time: 0.0576
DEBUG - 2020-03-23 07:33:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
ERROR - 2020-03-23 12:33:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\topic\controllers\Topic.php 223
ERROR - 2020-03-23 12:33:25 --> Could not find the language line "insert_batch() called with no data"
DEBUG - 2020-03-23 07:33:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:33:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:33:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
ERROR - 2020-03-23 12:33:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\shipan7.2\htdocs\xplore\application\modules\topic\controllers\Topic.php 223
ERROR - 2020-03-23 12:33:44 --> Could not find the language line "insert_batch() called with no data"
DEBUG - 2020-03-23 07:34:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:34:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign.php
DEBUG - 2020-03-23 12:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:34:44 --> Total execution time: 0.0598
DEBUG - 2020-03-23 07:34:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:34:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:34:44 --> Total execution time: 0.0468
DEBUG - 2020-03-23 07:34:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:34:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:34:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:34:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:34:44 --> Total execution time: 0.0635
DEBUG - 2020-03-23 12:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:34:44 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:34:51 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:34:51 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:34:51 --> Total execution time: 0.0432
DEBUG - 2020-03-23 07:34:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:34:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:34:52 --> Total execution time: 0.0518
DEBUG - 2020-03-23 07:34:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:34:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:34:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:34:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:34:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:34:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:34:55 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:34:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 07:34:57 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:34:57 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:34:57 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-assign-view.php
DEBUG - 2020-03-23 07:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/index.php
DEBUG - 2020-03-23 12:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:35:22 --> Total execution time: 0.0603
DEBUG - 2020-03-23 07:35:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:35:22 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:35:22 --> Total execution time: 0.0446
DEBUG - 2020-03-23 07:35:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:35:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/models/Topic_model.php
DEBUG - 2020-03-23 12:35:23 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/topic/views/topic-view.php
DEBUG - 2020-03-23 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign.php
DEBUG - 2020-03-23 12:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:35:24 --> Total execution time: 0.0703
DEBUG - 2020-03-23 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:35:24 --> Total execution time: 0.0426
DEBUG - 2020-03-23 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:35:24 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-assign-view.php
DEBUG - 2020-03-23 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:35:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/index.php
DEBUG - 2020-03-23 12:35:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:35:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:35:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:35:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:35:25 --> Total execution time: 0.0493
DEBUG - 2020-03-23 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:35:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:35:25 --> Total execution time: 0.0447
DEBUG - 2020-03-23 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:25 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/models/Section_model.php
DEBUG - 2020-03-23 12:35:25 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/section/views/section-view.php
DEBUG - 2020-03-23 07:35:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:35:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-03-23 12:35:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:35:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:35:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:35:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:35:26 --> Total execution time: 0.0603
DEBUG - 2020-03-23 07:35:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:35:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:35:26 --> Total execution time: 0.0397
DEBUG - 2020-03-23 07:35:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:35:26 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:35:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/index.php
DEBUG - 2020-03-23 12:35:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:35:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:35:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:35:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:35:27 --> Total execution time: 0.0579
DEBUG - 2020-03-23 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:35:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:35:27 --> Total execution time: 0.0393
DEBUG - 2020-03-23 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:27 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:35:27 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-view.php
DEBUG - 2020-03-23 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:35:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign.php
DEBUG - 2020-03-23 12:35:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:35:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:35:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:35:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:35:28 --> Total execution time: 0.0647
DEBUG - 2020-03-23 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:28 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:35:28 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:35:28 --> Total execution time: 0.0552
DEBUG - 2020-03-23 07:35:29 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:29 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:35:29 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:35:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 07:35:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/models/Subject_model.php
DEBUG - 2020-03-23 12:35:33 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/subject/views/subject-assign-view.php
DEBUG - 2020-03-23 07:35:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 12:35:34 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/models/Dashboard_model.php
DEBUG - 2020-03-23 12:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\modules/dashboard/views/index.php
DEBUG - 2020-03-23 12:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/header.php
DEBUG - 2020-03-23 12:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/sidebar.php
DEBUG - 2020-03-23 12:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/footer.php
DEBUG - 2020-03-23 12:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\layout/default.php
DEBUG - 2020-03-23 12:35:35 --> Total execution time: 0.0933
DEBUG - 2020-03-23 07:35:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 07:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 07:35:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 07:35:35 --> File loaded: D:\shipan7.2\htdocs\xplore\application\views\err404.php
DEBUG - 2020-03-23 07:35:35 --> Total execution time: 0.0454
DEBUG - 2020-03-23 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:06:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:06:38 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:06:38 --> Total execution time: 0.4763
DEBUG - 2020-03-23 11:07:17 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:07:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:07:17 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:07:17 --> Total execution time: 0.1646
DEBUG - 2020-03-23 11:07:22 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:07:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:07:22 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:07:22 --> Total execution time: 0.0585
DEBUG - 2020-03-23 11:07:23 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:07:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:07:23 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:07:23 --> Total execution time: 0.0541
DEBUG - 2020-03-23 11:07:26 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:07:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:07:26 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:07:26 --> Total execution time: 0.0649
DEBUG - 2020-03-23 11:07:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:07:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:07:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:07:46 --> Total execution time: 0.1282
DEBUG - 2020-03-23 11:07:49 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:07:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:07:49 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:07:49 --> Total execution time: 0.0807
DEBUG - 2020-03-23 11:07:59 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:07:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:07:59 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:07:59 --> Total execution time: 0.0969
DEBUG - 2020-03-23 11:08:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:08:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:08:02 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:08:02 --> Total execution time: 0.0607
DEBUG - 2020-03-23 11:08:10 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:08:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:08:10 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:08:10 --> Total execution time: 0.0596
DEBUG - 2020-03-23 11:08:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:08:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:08:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:08:19 --> Total execution time: 0.0855
DEBUG - 2020-03-23 11:08:33 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:08:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:08:33 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:08:33 --> Total execution time: 0.1402
DEBUG - 2020-03-23 11:08:35 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:08:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:08:35 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:08:36 --> Total execution time: 0.0721
DEBUG - 2020-03-23 11:08:46 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:08:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:08:46 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:08:46 --> Total execution time: 0.1410
DEBUG - 2020-03-23 11:08:58 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:08:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:08:58 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:08:58 --> Total execution time: 0.0638
DEBUG - 2020-03-23 11:09:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:09:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:09:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:09:13 --> Total execution time: 0.1226
DEBUG - 2020-03-23 11:09:16 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:09:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:09:16 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:09:16 --> Total execution time: 0.1236
DEBUG - 2020-03-23 11:09:19 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:09:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:09:19 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:09:19 --> Total execution time: 0.1214
DEBUG - 2020-03-23 11:09:24 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:09:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:09:24 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:09:24 --> Total execution time: 0.0709
DEBUG - 2020-03-23 11:09:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:09:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:09:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:09:30 --> Total execution time: 0.1003
DEBUG - 2020-03-23 11:09:40 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:09:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:09:40 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:09:40 --> Total execution time: 0.1121
DEBUG - 2020-03-23 11:09:50 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:09:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:09:50 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:09:50 --> Total execution time: 0.0874
DEBUG - 2020-03-23 11:10:02 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:10:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:10:03 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:10:03 --> Total execution time: 0.0670
DEBUG - 2020-03-23 11:10:13 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:10:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:10:13 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:10:14 --> Total execution time: 0.1302
DEBUG - 2020-03-23 11:10:15 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:10:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:10:15 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:10:15 --> Total execution time: 0.0769
DEBUG - 2020-03-23 11:13:20 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:13:20 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:13:21 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-23 16:13:21 --> Severity: Notice --> Undefined property: ContentController::$user D:\shipan7.2\htdocs\xplore\application\controllers\api\ContentController.php 98
ERROR - 2020-03-23 16:13:21 --> Severity: error --> Exception: Call to a member function duplicate_check() on null D:\shipan7.2\htdocs\xplore\application\controllers\api\ContentController.php 98
DEBUG - 2020-03-23 11:13:30 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:13:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:13:30 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-23 16:13:30 --> Query error: Unknown column 'question_id' in 'where clause' - Invalid query: SELECT *
FROM `question`
WHERE `question_id` = '1'
DEBUG - 2020-03-23 11:13:39 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:13:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:13:39 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:13:39 --> Total execution time: 0.0622
DEBUG - 2020-03-23 11:13:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:13:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:13:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:13:45 --> Total execution time: 0.0462
DEBUG - 2020-03-23 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:34:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:34:32 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
ERROR - 2020-03-23 16:34:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0, 1, 2, 3, 4, 5) VALUES (1, 1, 1, 1, 1, 1)' at line 1 - Invalid query: INSERT INTO `recently_learn` (0, 1, 2, 3, 4, 5) VALUES (1, 1, 1, 1, 1, 1)
DEBUG - 2020-03-23 11:35:00 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:35:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:35:00 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 11:35:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:35:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:35:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:35:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:35:45 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 11:36:34 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:36:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:36:34 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 11:36:44 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:36:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:36:44 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:36:44 --> Total execution time: 0.1868
DEBUG - 2020-03-23 11:36:55 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:36:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:36:55 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:36:55 --> Total execution time: 0.0883
DEBUG - 2020-03-23 11:47:52 --> UTF-8 Support Enabled
DEBUG - 2020-03-23 11:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-03-23 16:47:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/jwt.php
DEBUG - 2020-03-23 16:47:52 --> Config file loaded: D:\shipan7.2\htdocs\xplore\application\config/rest.php
DEBUG - 2020-03-23 16:47:52 --> Total execution time: 0.1806
